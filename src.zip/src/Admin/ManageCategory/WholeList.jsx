import React from 'react'
import {Table,Checkbox,Button} from '@material-ui/core'
import {Link} from 'react-router-dom'
import useStyles from './styles'

export default function WholeList() {
    const classes=useStyles();
    return (
        <div >
            <table id="t01" style={{ width:'100%' }}>
                <tr>
                    <th>
                     <Checkbox style={{color:'white'}}/>
                    </th>
                    <th>شماره</th>
                    <th>نام دسته بندی</th>
                    <th>ویرایش</th>
                </tr>
                <tr>
                <td>
                     <Checkbox style={{color:'white'}}/>
                    </td>
                    <td>شماره</td>
                    <td>نام دسته بندی</td>
                    <td>  <Link to="/admin/editWhole"><Button className={classes.editButton}>ss</Button></Link>  </td>

                </tr>
            </table>
             
        </div>
    )
}
