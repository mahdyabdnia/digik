import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import { Grid, Button } from '@material-ui/core';


export default function EditWhole() {
    const classes=useStyles();
    return (
        <div className={classes.container}>
            
                <Typography variant="h6" color="initial">ویرایش دسته بندی</Typography>
                <Grid item container className={classes.row}>
                    <Typography variant="h6" color="initial">نام دسته بندی</Typography>
                <input type="text" className={classes.input} />
                <Grid item container className={classes.buttons}>
                    <Grid item container className={classes.buttonsGrid}><Button className={ classes.btn }>
                      ثبت و تایید ویرایش
                    </Button></Grid>
                    <Grid item container className={classes.buttonsGrid}><Button className={ classes.btn2 }>
                      انصراف
                    </Button></Grid>
                    
                </Grid>


            </Grid>
            
        </div>
    )
}
