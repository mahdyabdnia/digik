import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import Grid from '@material-ui/core/Grid'
import { Button } from '@material-ui/core';

export default function Whole() {
    const classes=useStyles();
    return (
        <div className={classes.container}>
         <Typography variant="h6" color="initial">افزودن دسته بندی کلی</Typography>
        <Grid container className={classes.row}>              
        <Typography variant="h6" color="initial">نام دسته بندی کلی</Typography>
        <input type="text" className={classes.input} placeholder="نام یک دسته بندی کلی را وارد کنید " />
        <Grid item container direction="row" className={classes.buttons}>
          <Grid item container className={classes.buttonsGrid}><Button variant="contained"   className={classes.btn}>ثبت دسته بندی</Button></Grid>
          <Grid item container className={classes.buttonsGrid}><Button variant="contained"  className={classes.btn2}> ثبت و افزودن دسته بندی چدید</Button></Grid>
          <Grid item container className={classes.buttonsGrid}><Button variant="contained" color="secondary"  className={classes.btn3}> انصراف </Button></Grid>
        </Grid>
        </Grid>
        </div>
    )
}
