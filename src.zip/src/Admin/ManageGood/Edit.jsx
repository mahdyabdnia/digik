import React,{useState,useEffect} from 'react'
import {Table,Checkbox,Button} from '@material-ui/core'
import './style.css'
import useStyles  from './styles';
import {Link} from 'react-router-dom'


export default function Edit() {
    const classes=useStyles();
    const [checkAll, setcheckAll] = useState(false);
    const [state,setState]=useState({check1:false,check2:false,check3:false})
    const handleAll=(value)=>{
        setcheckAll(!checkAll);
        setState((prevState)=>{
            const newState={...prevState};
            for(const inputState in newState){
               newState[inputState]=!checkAll;
            }
            return(newState);

        })
        
    }
    const handleCheck=(event)=>{
        setState({...state,[event.target.name]:event.target.checked})
    }

   useEffect(() => {
       let allCheck=true;
       for(const inputName in state){
           if(state[inputName]===false){
               allCheck=false;
           }
       }
       if(allCheck){
           setcheckAll(true);
       }
       else{
           setcheckAll(false);
       }

   }, [state]);
    return (
        <div>
            <table id="t01" style={{ width:"100%" }}>
              
                    <tr>
                        
                    <th>
                    <Checkbox checked={checkAll} name="checkAll" style={{color:'white'}} onChange={()=>handleAll(true)}      />
                </th>
                    <th>
                      شماره 
                </th>

                <th>
                     نام کالا    
                </th>

                <th>
                   توضیحات    
                </th>

                <th>
                   عملیات    
                </th>
                    </tr>
                
                

              
                    <tr>
                        <td> <Checkbox checked={state.check1} onChange={handleCheck} name="check1" /></td>
                    <td>1</td>
                    <td>1</td>
                    <td>1</td>
                    <td><Link to="editpage"><button  className={classes.editButton}>ویرایش</button></Link></td>
                    </tr>
                    <tr>
                        <td> <Checkbox checked={state.check2} onChange={handleCheck} name="check2" /></td>
                    <td>1</td>
                    <td>1</td>
                    <td>1</td>
                    <td><Link to="editpage"><button className={classes.editButton}>ویرایش</button></Link></td>
                    </tr>
                   

            </table>

            <Button variant="contained" color="secondary" style={{ marginRight:'40px',marginTop:'40px' }}>حدف </Button>
        </div>
    )
}

