import React,{useEffect} from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import classnames from 'classnames'
import Button from '@material-ui/core/Button'
import $ from 'jquery'
import './style.css'




export default function EditPage() {
    const addOption=()=>{
     $(document).ready(function(){
         $('.add').click(function(){
             $('.options').append(' <input type="text" placeholder="لطفا ویژگی کالا را وارد کنید " style="direction:rtl;text-align:right;display:block;width:100%;border-radius:5px;min-height:40px;margin-top:10px " />').addClass("inputtext");
         })
     })
    }

    const addSeller=()=>{
        $(document).ready(function(){
            $('.addSeller').click(function(){
                $('.sellers').append(' <input type="text" placeholder="لطفا ویژگی کالا را وارد کنید " style="direction:rtl;text-align:right;display:block;width:100%;border-radius:5px;min-height:40px;margin-top:10px " />').addClass("inputtext");
            })
        })
    }
    useEffect(() => {
        addOption();
        addSeller();
    }, []);
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <Typography variant="h5" color="initial">ویرایش کالا</Typography>
          <div className={classes.row}>
              
              <Typography variant="h6" color="initial">نام کالا</Typography>
              <input type="text" placeholder="لطفا نام کالا را وارد کنید " className={classes.input}/>

              <Typography variant="h6" color="initial"> انتخاب دسته بندی کلی</Typography>
              <select className={classes.input2}>
                  <option disabled selected>یک دسته بندی را انتخاب کنید </option>
                  <option>دسته بندی یک </option>
                  <option>دسته بندی یک </option>
                  <option>دسته بندی یک </option>
              </select>

              <Typography variant="h6" color="initial">انتخاب دسته بندی میانی</Typography>
              <select className={classes.input2}>
                  <option disabled selected>یک دسته بندی را انتخاب کنید </option>
                  <option>دسته بندی یک </option>
                  <option>دسته بندی یک </option>
                  <option>دسته بندی یک </option>
              </select>

              <Typography variant="h6" color="initial">انتخاب دسته بندی جزئی</Typography>
              <select className={classes.input2}>
                  <option disabled selected>یک دسته بندی را انتخاب کنید </option>
                  <option>دسته بندی یک </option>
                  <option>دسته بندی یک </option>
                  <option>دسته بندی یک </option>
              </select>

              <Typography variant="h6" color="initial">افزودن ویژگی ها </Typography>
              <div className={classnames('options')}>
              <input type="text" placeholder="لطفا ویژگی کالا را وارد کنید " className={classes.input}/>
              </div>
         <Button variant="text" style={{color:'#60eafc'}} className={classnames('add')}>
           + افزودن ویژگی جدید
         </Button>

            <Typography variant="h6" color="initial">افزودن نام فروشنده </Typography>
            <div className={classnames('sellers')}>
            <input type="text" placeholder="لطفا نام فروشنده را وارد کنید " className={classes.input} />
            </div>

            <Button variant="text" style={{color:'#60eafc'}}className={classnames('addSeller')}>
           + افزودن فروشنده جدید
         </Button>

         <Typography variant="h6" color="initial">   قیمت کالا</Typography>
         <input type="text" className={classes.input} placeholder="لطفا قیمت کالا را وارد کنید "/>
          
          <Typography variant="h6" color="initial">آپلود تصاویر </Typography>
          <input type="file"/>
          <Typography variant="h6" color="initial">توضیحات</Typography>
          <textarea style={{resize:'none'}} className={classes.input}></textarea>
         <button style={{display:'block',borderRadius:"5px",backgroundColor:'#407a79',height:"40px",color:'white',width:'20%',margin:'auto',marginTop:'10px'}}>اتمام و  ثبت کالا </button>
              
          </div>
        </div>
    )
}
