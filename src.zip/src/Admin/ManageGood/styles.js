import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({

    container:{
        width:'90%',
        margin:"auto",
        paddingTop:'10px'
    },
    row:{
        width:'60%',
        marginTop:'10px',
        direction:"rtl",
        textAlign:'right',
        margin:'auto'
    },
    input:{
        textAlign:'right',
        direction:"right",
        display:'block',
        width:'100%',
        borderRadius:'5px',
        minHeight:'40px'
    },
    input2:{
        textAlign:'right',
        direction:"right",
        display:'block',
        width:'663.467px',
        borderRadius:'5px',
        minHeight:'40px'
    },
    editButton:{
        outline:'none',
        border:'none',
        backgroundColor:'inherit'
    }
    
 });

export default useStyles;
