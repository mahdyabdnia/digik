import React from 'react'
import { Checkbox } from '@material-ui/core'
import useStyles from './styles'
import {Link} from 'react-router-dom'
export default function MinorList() {
 const classes=useStyles();
    return (
        <div>
            <table id="t01">

            <tr>
                 <th><Checkbox style={{color:'white'}}/></th>
                 <th> دسته بندی جزئی</th>
                 <th>دسته بندی میانی</th>
                 <th>دسته بندی کلی </th>
                
                 <th>عملیات</th>
            </tr>

            <tr>
           <td><Checkbox/></td>
           <td>1</td>
           <td>2</td>
           <td>3</td>
     <td><Link to="/admin/editMinor"><button className={classes.editButton}>ss</button></Link></td>



             </tr>
                    

            </table>
            
        </div>
    )
}
