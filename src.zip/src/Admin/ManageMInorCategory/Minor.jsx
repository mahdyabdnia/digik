import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import { Grid ,Button} from '@material-ui/core';


export default function Minor() {
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <Typography variant="h6" color="initial"> افزودن دسته بندی جزئی  </Typography>
            <div className={classes.row}>
                <Typography variant="h6" color="initial">دسته بندی کلی</Typography>
                <select className={classes.input}>
                    <option selected disabled> طفا یک دسته بندی را انتخاب کنید </option>
                    <option>2</option>
                </select>
                <Typography variant="h6" color="initial">دسته بندی کلی</Typography>
                <select className={classes.input}>
                    <option selected disabled> طفا یک دسته بندی را انتخاب کنید </option>
                    <option>2</option>
                </select>
                <Typography variant="h6" color="initial">دسته بندی چزئی</Typography>
                <input className={classes.input} type="text" placeholder="لطفا نام دسته بندی جزئی را وارد کنید "/>
                <Grid item container className={classes.buttons}>
                 <Grid item container className={classes.buttonsGrid}>
                <Button variant="contained" className={classes.btn}>تایید </Button>
                 </Grid>
                 <Grid item container className={classes.buttonsGrid}>
                <Button variant="contained" className={classes.btn2}> تایید و ادامه  </Button>
                 </Grid>
                 <Grid item container className={classes.buttonsGrid}>
                <Button variant="contained" className={classes.btn3}>  انصراف  </Button>
                 </Grid>

                </Grid>
                
            </div>
            
        </div>
    )
}
