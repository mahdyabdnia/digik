import {makeStyles} from '@material-ui/core'
 const useStyles=makeStyles({
  ul:{
      listStyleType:'none',
      paddingTop:'10px',
      paddingBottom:'10px'
  },
  

});
export default useStyles;