import React,{useEffect} from 'react'
import useStyles from './styles'
import './style.css'
import $ from 'jquery'
import {Link } from 'react-router-dom'

export default function AdminNav() {
    const drop=()=>{
        $(document).ready(function(){
        $('ul li   ').hover(function() {
                $( this).children('ul' ).stop(true).slideToggle(500);
              })
            
        });
    }
    
    const classes=useStyles();
    useEffect(() => {
        drop();
        
    }, []);
    return (
        <div style={{ backgroundColor:"#3295a8",paddingTop:"0px" ,height:'auto',minHeight:'600px',position:'sticky'}}>
            <ul className={classes.ul}>
                <li>
                    <a>مدیریت کالاها</a>
                    <ul>
                        <li>
                            <Link to="/admin/add" style={{textDecoration:"none",color:'black'}}>  افزودن کالا  </Link>
                              </li>
                        <li>  <Link to="/admin/edit" style={{textDecoration:"none",color:'black'}}>ویرایش کالا</Link> </li>
                      
                    </ul>
                </li>

                <li>
                <a>مدیریت دسته بندی</a>
                <ul>
                    <li>
                        <a>مدیریت دسته بندی کلی</a>
                        <ul>
                           <li> <Link to="/admin/addWholeCategory" style={{textDecoration:"none",color:'black'}}>افزودن دسته بندی کلی</Link></li>
                           <li> <Link style={{textDecoration:"none",color:'black'}} to="/admin/editWholeCategory">ویرایش دسته بندی کلی</Link></li>

                        </ul>
                    </li>
                    <li>
                        <a>  مدیریت دسته میانی  </a>
                        <ul>
                            <li><Link to="/admin/addMiddleCategory" style={{ textDecoration:'none',color:'black' }} >افزودن دسته بندی میانی</Link></li>
                          <li><Link to="/admin/editMiddleCategory" style={{ textDecoration:'none',color:'black' }}>ویرایش دسته بندی میانی</Link></li>  
                        </ul>
                    </li>
                    <li>
                        <a> مدیریت دسته بندی جزئی  </a>
                        <ul>
                        <li><Link to="/admin/addMinorCategory" style={{ textDecoration:'none',color:'black' }} >افزودن دسته بندی  جزئی</Link></li>
                          <li><Link to="/admin/editMinorCategory" style={{ textDecoration:'none',color:'black' }}>ویرایش دسته بندی جزئی</Link></li>  
                        
                        </ul>
                    </li>
                </ul>

                </li>
                
                
            </ul>
        </div>
    )
}
