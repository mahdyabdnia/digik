import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import { Grid,Button } from '@material-ui/core';


export default function EditMiddle() {
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <Typography variant="h6" color="initial">ویرایش دسته بندی میانی</Typography>
        <div className={classes.row}>
           <Typography variant="h6" color="initial">دسته بندی کلی</Typography>
           <select className={classes.input}>
               <option selected>1</option>
               <option>1</option>
               <option>1</option>
           </select>
           <Typography variant="h6" color="initial">دسته بندی میانی</Typography>
           <input className={classes.input} type="text" value="دسته بندی میانی" />
           <div className={classes.buttons}>
               <div className={classes.buttonsGrid}>
                   <Button className={classes.btn}>تایید ویرایش</Button>
               </div>
               <div className={classes.buttonsGrid}>
                   <Button className={classes.btn2}> انصراف و عدم تایید  </Button>
               </div>
           </div>

        </div>
            
        </div>
    )
}
