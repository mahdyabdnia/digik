import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'



export default function Middle() {
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <Typography variant="h6" color="initial">افزودن دسته بندی میانی</Typography>
            <div className={classes.row}>
            <Typography variant="h6" color="initial">نام دسته بندی کلی</Typography>
            <select className={classes.input}>
                <option disabled selected>لطفا  یک دسته بندی کلی را وارد کنید</option>
             <div><input type="text" placeholder="جستجو"/></div>   
                <option>1</option><option>1</option><option>1</option><option>1</option>
                <option>1</option>
            </select>
             <Typography variant="h6" color="initial">نام دسته بندی میانی</Typography>
             <input type="text" className={classes.input} placeholder="لطفا نام یک دسته بندی میانی را وارد نمایید "/>

             <Grid container item className={classes.buttons}>
               <Grid item container className={classes.buttonsGrid}> <Button variant="contained" className={classes.btn}>
                 تایید و افزودن
               </Button> </Grid>
               <Grid item container className={classes.buttonsGrid}> <Button variant="contained" className={classes.btn2}>
                 تایید و افزودن
               </Button> </Grid>

               <Grid item container className={classes.buttonsGrid}> <Button variant="contained" className={classes.btn3}>
                 تایید و افزودن
               </Button> </Grid>
             </Grid>



            </div>
            
        </div>
    )
}
