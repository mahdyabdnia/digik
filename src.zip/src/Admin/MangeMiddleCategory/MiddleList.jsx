import React from 'react'
import {Checkbox} from '@material-ui/core'
import {Link} from 'react-router-dom'
import useStyles from './styles'
import './style.css'

export default function MiddleList() {
    const classes=useStyles();
    return (
        <div>
        <table id="t01">
            <tr>
                <th><Checkbox style={{ color:"white" }}
                   /></th>
                <th>ردیف </th>
                <th> نام دسته بندی کلی</th>
                <th>نام دسته بندی میانی</th>
                <th>عملیات</th>
            </tr>
            <tr>
            <td><Checkbox/></td>
            <td>1</td>
            <td>نام دسته بندی کلی</td>
            <td> نام دسته بندی میانی</td>
            <td><Link to="/admin/editMiddle"><button  className={classes.editButton}>ss</button></Link></td>

            </tr>
        </table>
        </div>
    )
}
