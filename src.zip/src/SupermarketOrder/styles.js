import { makeStyles } from "@material-ui/core";
const useStyles=makeStyles({
container:{
    display:'flex',
    flexDirection:'column',
    direction:'rtl',
    backgroundColor:'white'
},
supriseBox:{
    display:'flex',
    flexDirection:'column',
    backgroundColor:'#89c03e'
},
header:{
    color:'white',
    textAlign:'center',
   
},
headerImg:{
    backgroundImage:'../files/cd854864.png'
},
supriseCarouselBox:{
    display:'flex',
    flexDirection:'row',

},
sHead:{
    display:'flex',
    flexDirection:'column',
    width:'15%',
    justifyContent:'center',
    paddingRight:'30px',
    paddingBottom:'40px'
},
sImg:{
    width:'70%',
    height:'70%'
},
sImg2:{
    width:'60%',
    height:'60%'
},
carouselBox:{
    width:'85%'
},
toEnd:{
    display:'flex',
    flexDirection:'column',
    borderRadius:'10px',
    border:'1px solid #e3e3e5',
    width:'98%',
    margin:'15px auto 15px auto',
    
    backgroundColor:'white'
},
endHeader:{
    display:'flex',
    alignItems: 'center',
    borderBottom:'5px solid red',
    width:'240px',
   
    overflowX:'visible'
},
endImg:{
    display:'block',
    width:'25px',
    height:'25px',
    marginLeft:'5px',
    marginRight:'10px'
},
endCarousel:{
    width:'100%',
    height:'441px',
    backgroundColor:'white',
    marginTop:'20px'
},
all:{
    display:'flex',
    flexDirection:'column',
    direction:'rtl'
},
sortBox:{
    display:'flex',
    flexDirection:'row',
    marginTop:'20px',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginRight:'20px'
},
sortItems:{
    display:'flex',
    flexDirection:'row',
  
},
sortItem:{
    margin:'0px 20px 0px 0px',
    color:'#94989d'
},
goods:{
    display:'flex',
    flexDirection:'row',
    flexWrap:'wrap',
    
}
})

export default useStyles;