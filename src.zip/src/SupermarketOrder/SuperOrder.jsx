import React,{useEffect} from 'react'
import useStyles from './styles'
import Carousel from 'react-elastic-carousel'
import GoodBox from './GoodBox/GoodBox'
import GoodBoxTwo from './GoodBoxTwo/GoodBoxTwo'
import GoodBoxThree from './GoodBoxThree/GoodBoxThree'
import classnames from 'classnames'
import SortIcon from '@material-ui/icons/Sort';
export default function SuperOrder() {
    useEffect(() => {
        var item=document.getElementsByClassName('sortItem');
        var i;
        for(i=0;i<item.length;i++){
            item[i].addEventListener('click',function(){
                var it=document.getElementsByClassName('sortItem');
                var j;
             for(j=0;j<it.length;j++){
                 it[j].classList.remove('selectedSort');
                 it[j].classList.add('sortItem');
             }
             this.classList.add('selectedSort')
            })
        }
    }, []);
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <div className={classes.supriseBox}>
             <div className={classes.headerImg}><h1 className={classes.header}>شگفت انگیز سوپر مارکتی</h1></div>   
                <div className={classes.supriseCarouselBox}>
                 <div className={classes.sHead}>
                     <img src="images/suprise2.svg" alt="" className={classes.sImg2}/>
                     <img src="images/super.png" alt="" className={classes.sImg}/>
                 </div>
                 <div className={classes.carouselBox}>
                     <Carousel itemsToScroll={5} itemsToShow={5}>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                         <GoodBox/>
                     </Carousel>
                 </div>
                </div>
            </div>

            <div className={classes.toEnd}>
                <div className={classes.endHeader}>
                    <img src="images/clock.jpg" className={classes.endImg}/>
                    <h3>شگفت انگیز های روبه اتمام</h3>
                </div>
                <div className={classes.endCarousel}>
                    <Carousel itemsToScroll={5} itemsToShow={5}>
                        <GoodBoxTwo/>
                        <GoodBoxTwo/> 
                         <GoodBoxTwo/>  
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                    </Carousel>
                </div>
            </div>

            <div className={classes.all}>
                <h3 style={{ marginRight:'20px',marginTop:'10px' }}>همه شگفت انگیزها</h3>
                <div className={classes.sortBox}>
                    <span style={{ marginLeft:'10px' }}><SortIcon/></span>
                    <span>مرتب سازی براساس:</span>
                    <span className={classes.sortsItems}>
                        <span className={classnames(classes.sortItem,'sortItem','selectedSort')}>پرفروش ترین</span> 
                        <span className={classnames(classes.sortItem,'sortItem',)}>پرفروش ترین</span> 
                        <span className={classnames(classes.sortItem,'sortItem',)}>پرفروش ترین</span>
                      
                    </span>
                </div>
                <div className={classes.goods}>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                </div>
            </div>
            
        </div>
    )
}
