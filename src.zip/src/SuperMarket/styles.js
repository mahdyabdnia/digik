import {makeStyles } from '@material-ui/core'
const useStyles=makeStyles({
container:{ 
    padding:'20px 20px 0px 20px',
    backgroundColor:'#f1f1f1',
    display:'flex',
    flexDirection:'column',
    direction:'rtl',
    maxHeight:'50000px',
  
    height:'auto',marginBottom:'20px',
    overflow:'visibility'

    
},
head:{
    height:'45px',
    width:'100%',
  
},
row:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:'10px'

},
left:{
width:'80.5%',


},

right:{
    width:'18%',
  
}
});

export default useStyles;