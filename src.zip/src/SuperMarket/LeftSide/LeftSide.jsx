import React,{useEffect,useState,useRef} from 'react'
import useStyles from './styles'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import classnames from 'classnames';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import CardGood from '../../components/Category/CardGood/CardGood';

import Typography from '@material-ui/core/Typography'

import './style.css'
import { Button } from '@material-ui/core';

import Carousel from 'react-elastic-carousel';

export default function LeftSide(props) {
    const classes=useStyles();
    const [gIndex, setGIndex] = useState(0)
    const goods=[{src:'images/laptop (1).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (2).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (3).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (4).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (5).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (6).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (7).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (8).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (9).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (10).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},

  
  ];
  const ad=[{id:1,src:'images/ad (1).jpg'},{id:2,src:'images/ad (2).jpg'},{id:3,src:'images/ad (3).jpg'},{id:4,src:'images/ad (4).jpg'},
  {id:5,src:'images/ad (5).jpg'},{id:6,src:'images/ad (6).jpg'},{id:7,src:'images/ad (7).jpg'},{id:8,src:'images/ad (8).jpg'},
  {id:9,src:'images/ad (9).jpg'},{id:10,src:'images/ad (10).jpg'},
]

  const surpriseGood=[
  {id:0,src:'images/sup1.jpg',price:'25000',name:'نان لواش 100 گرمی سبوس'},
  {id:1,src:'images/sup2.jpg',price:'25000',name:'نان لواش 100 گرمی سبوس'},
  {id:2,src:'images/sup3.jpg',price:'25000',name:'میگو یک کیلویی گوشت پروتوئین'},
  {id:3,src:'images/sup4.jpg',price:'25000',name:'روغن یک کیلویی غنچه '},
  {id:4,src:'images/sup5.jpg',price:'25000',name:' زیتون شیشه ای یک کیلویی بیژن'},

]
let car1 = useRef()
let car2 = useRef()

const carouselGoods=[
    {id:0,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '}, {id:1,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
     {id:2,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:3,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
    {id:4,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:5,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
    {id:6,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:7,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
    {id:8,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:9,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
    {id:10,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:12,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
    {id:13,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:14,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
    {id:15,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:16,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},
    {id:17,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},{id:18,src:'images/banana.jpg',price:'35000',name:'موز یک کیلیویی درجه یک '},

]


const showArticle=()=>{
    var ad=document.getElementsByClassName('closer')[0];
    ad.addEventListener('click',function(){
        var parent=document.getElementsByClassName('article')[0];
        var exp=document.getElementsByClassName('exp')[0];
        var ch=this.childNodes[0];
        if(parent.style.maxHeight==="380px"){
           
            parent.style.maxHeight="900px";
            parent.style.minHeight="900px";
            ch.innerHTML="بستن";
            exp.style.transform="rotate(180deg)"
        }
        else{
       
            parent.style.maxHeight="380px"; 
            parent.style.minHeight="380px";
            ch.innerHTML="نمایش بیشتر";
            exp.style.transform="rotate(360deg)"
        }
    })
}
  const point=()=>{
 var sups=document.getElementsByClassName('supLi');
 var i;
  for(i=0;i<sups.length;i++){
      sups[i].addEventListener('click',function(){
       
      })

  }
  }
 

 
  var slideIndexV2=1;
  function plusSlides(n) {
    showSlidesV2(slideIndexV2 += n);
  }
  
  function currentSlide(n) {
    showSlidesV2(slideIndexV2 = n);
  }

  function showSlidesV2(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    if (n > slides.length) {slideIndexV2 = 1}    
    if (n < 1) {slideIndexV2 = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndexV2-1].style.display = "block";  
    dots[slideIndexV2-1].className += " active";
  }
 

  
 
 useEffect(() => {
    var goodIndex=0;
     const showBorder=setInterval(function(){
        var i;
        var good=document.getElementsByClassName("supLi");
        goodIndex++;
        for(i=0;i<good.length;i++){
            good[i].className=good[i].className.replace("hBorder","");
        }
        if(goodIndex>good.length){goodIndex=1}
      
        
        good[goodIndex-1].className+="hBorder";
        setGIndex(goodIndex-1);
         
     },2000)
     return () => {
         clearInterval(showBorder);
     }
 }, [])
 useEffect(() => {
    var slideIndex = 0;
    const showSlide=setInterval(function(){
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";  
        }
        slideIndex++;
        if (slideIndex > slides.length) {slideIndex = 1}    
        for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }
        if(typeof(slideIndex)!=="undefined"){
        slides[slideIndex-1].style.display = "block";  }
        dots[slideIndex-1].className += " active";

    },5000)
     return () => {
         clearInterval(showSlide)
     }
 }, [])

  useEffect(() => {
    
      point();
   
 
  


showArticle();
showSlidesV2(slideIndexV2);





  




  }, []);


   
    return (
        <div className={classes.container}>
            <div className="slideshow-container">
            <div class="mySlides ">
             <img className="img" src="images/slider.jpg" />

            </div>

            <div class="mySlides ">
             <img className="img" src="images/slider1.jpg" />

            </div>

            <div class="mySlides ">
             <img className="img" src="images/slider2.jpg" />

            </div>

            <a className="prev" onClick={()=>{plusSlides(1)}}> &#10095; </a>
<a className="next" onClick={()=>{plusSlides(-1)}}> &#10094; </a>
            <div className="dotBox">
  <span className="dot" onClick={()=>{currentSlide(1)}}></span> 
  <span className="dot" onClick={()=>{currentSlide(2)}}></span> 
  <span className="dot" onClick={()=>{currentSlide(3)}}></span>
   
</div>

            </div>
            <div  className={classes.supriseSuper}>
                <div className={classes.supHead}>
                  
                        <img  className={classes.supImg} src="images/suprise.svg"/>
                   
                    <a className={classes.showAll}>
                   نمایش همه 
                    </a>
                </div>

                <div className={classes.supBody}>
                 {surpriseGood.map((item,index)=>{
                     return(<> 
                      {gIndex===index &&
                        <div className={classes.rightSup}>
                        <img src={item.src} className={classes.rightSupImg} />
                        
                        <div className={classes.rightSupTitle}>
                            <div className={classes.rightSupTitleUp}>
                                <Typography variant="h6" color="initial">  {item.name}  </Typography>
                            </div>
                            <div className={classes.rightSupTitleDown}>
                                <span style={{ display:'flex' }}>
                                    <span style={{ borderRadius:'15px',backgroundColor:'red',color:'white',padding:'3px 5px',fontSize:'15px',marginRight:'10px' }}>
                                        16%</span>
                                        <span style={{ textDecoration:'black',textDecorationLine:'line-through' }}> {item.price}</span>
                                </span>

                                 <h3 variant="h6" color="initial"> {item.price} تومان </h3>
                                <button className={classes.btn}>افزودن به سبد خرید</button>
                            </div>
                        </div>
                     </div>

                      }

                      {gIndex!==index &&
                      <></>


                      }
                     
                     </>

                     )
                 })}
               

                       




                   






        <div className={classes.leftSup}>

             <div className={classes.supUl}>
             {surpriseGood.map(item=>{
                 return(<div className={classnames(classes.supLi,'supLi','hBorder')}> 
                 <img src={item.src} className={classes.supLiImg}/>
                 <Typography variant="body1" color="initial">  {item.name} </Typography>
                 </div>)
             })}
            


                 

                
                
               
             </div>

     </div>
                </div>
            </div>

            <div className={classes.types}>
                <div className={classes.type}>
                    <img src="images/hhd.jpg" alt="" className={classes.typeImg} />
                
                
                </div>

                <div className={classes.type}>
                    <img src="images/hhd.jpg" alt="" className={classes.typeImg} />
                
                
                </div>

                <div className={classes.type}>
                    <img src="images/hhd.jpg" alt="" className={classes.typeImg} />
                
                
                </div>

                <div className={classes.type}>
                    <img src="images/hhd.jpg" alt="" className={classes.typeImg} />
                
                
                </div>
                


            </div>

            <div className={classes.carousel}>

                <div className={classes.carouselHeader}>
                    <div className={classes.carouselHeaderRight}>
                        <Typography variant="h6" color="initial">پرفروش ترین ها </Typography>
                    </div>
                    <div className={classes.carouselHeaderLeft}>
                        
                         <Typography variant="h6" color="textSecondary">نمایش همه </Typography> 
                    
                    </div>
                </div>

                <div className={classnames(classes.carouselBody,'carouselBody')}>
                    <Carousel itemsToShow={5} itemsToScroll={4} showArrows={false} ref={ref=>{car1=ref}}>
                {carouselGoods.map((item)=>{
                    return(
                        <div className={classnames(classes.carouselItem,'carouselItem')}>
                      <img src={item.src} className={classes.carouselImg} />
                       <div className={classes.carouselItemTitle}>
                           <Typography variant="body1" color="textSecondary"> {item.name} </Typography>
                           </div> 

                          <div className={classes.carouselItemBody}>
                              <span>{item.price} تومان</span>
                              <Button variant="contained" color="secondary" size="medium" style={{ fontSize:'25px',height:'40px',width:'60px' }}>+</Button>
                              </div> 
                  
                  </div>
                    )
                })}
           
                    </Carousel>
                    <a  className={classes.leftNav} onClick={()=>{car1.slidePrev()}}><ChevronLeftIcon/></a>
                    <a  className={classes.rightNav} onClick={()=>{car1.slideNext()}}><ChevronRightIcon/></a>
                    
 

               

                </div>
            </div>

            <div className={classes.carousel}>

<div className={classes.carouselHeader}>
    <div className={classes.carouselHeaderRight}>
        <Typography variant="h6" color="initial">پرفروش ترین ها </Typography>
    </div>
    <div className={classes.carouselHeaderLeft}>
        
         <Typography variant="h6" color="textSecondary">نمایش همه </Typography> 
    
    </div>
</div>

<div className={classnames(classes.carouselBody,'carouselBody')}>
    <Carousel itemsToShow={5} itemsToScroll={4} showArrows={false} ref={ref=>{car2=ref}}>
{carouselGoods.map((item)=>{
    return(
        <div className={classnames(classes.carouselItem,'carouselItem')}>
      <img src={item.src} className={classes.carouselImg} />
       <div className={classes.carouselItemTitle}>
           <Typography variant="body1" color="textSecondary"> {item.name} </Typography>
           </div> 

          <div className={classes.carouselItemBody}>
              <span>{item.price} تومان</span>
              <Button variant="contained" color="secondary" size="medium" style={{ fontSize:'25px',height:'40px',width:'60px' }}>+</Button>
              </div> 
  
  </div>
    )
})}

    </Carousel>
    


    <a  className={classes.leftNav} onClick={()=>{car2.slidePrev()}}><ChevronLeftIcon/></a>
                    <a  className={classes.rightNav} onClick={()=>{car2.slideNext()}}><ChevronRightIcon/></a>

</div>
</div>

<div className={classes.adpalacement}>
{ad.map((item)=>{
    return(<a className={classes.adpalacementLink}>
        <img src={item.src} className={classes.adpalacementImg} />
    </a>)
})}
</div>



<div className={classnames(classes.article,'article')}>
<h1 className={classes.hOne}>کالاهای سوپر مارکتی</h1>
<article  className={classes.articleTag}>
<h1 className={classes.hOne}>درباره سوپر مارکتی آنلاین دیجی تالی</h1>
<p className={classes.paragraph}>
سوپر مارکت آنلاین دیجی کالا با فروش آنلاین اقلام مواد غذایی موارد نیاز مصرفی خانواده‌ها از جمله انواع محصولات خوراکی و غیر خوراکی را فراهم کرده است تا با چند کلیک وعده‌های خوشمزه‌ی غذایی خود را در سریع‌ترین حالت ممکن در خانه آماده کنند. انتخاب از محصولات فروشگاه اینترنتی خوراکی دیجی کالا با فروش ویژه، شما را در سریع‌ترین زمان ممکن به تنوع وسیعی از اجناس سوپری متصل می‌کند. با این روش شما یک هایپر همیشه در دسترس دارید که می‌توانید انواع محصولات FMCG یا تند مصرف را تنها در چند دقیقه داخل سبد خرید خود انداخته و بدون اینکه از خانه بیرون بروید با خیال آسوده خرید کنید. دسته بندی کالاهای سوپرمارکتی دیجی کالا به شما کمک می‌کند تا سریع‌تر و راحت‌تر کالای مورد نیاز خود را پیدا کنید. دسته‌ی کالاهای اساسی و خوار و بار شامل نان، برنج، روغن، شکر، حبوبات و سویا، ماکارونی، رب و غیره است. در این دسته شما به راحتی تمام اقلام اساسی مورد نیاز برای پخت غذا و دسر را خواهید یافت. همچنین شما در سوپرمارکت دیجی کالا لبنیات و مواد پروتئینی تازه از جمله گوشت گاو و گوساله، گوشت مرغ، تخم‌مرغ، ماهی، میگو و غیره را می‌توانید خریداری کنید. فروشگاه اینترنتی خوراکی دیجی کالا با ایجاد بخش کالاهای خوراکی صبحانه که شامل انواع خوراکی‌ها برای وعده‌ی صبحانه است کار مصرف‌کنندگان به ویژه کارمندان را راحت کرده است. این گروه شامل محصولاتی مثل مربا، حلوا شکری، ارده و کنجد، غلات صبحانه، شکلات صبحانه، عسل، کره بادام زمینی و نان تازه است.
همچنین برای خرید میوه و سبزیجات تازه و انواع تنقلات مثل بیسکوییت و ویفر، شکلات، تافی و آبنبات، چیپس و پاپ کورن و غیره می‌توانید از دسته‌بندی‌های هر کدام اقدام به خرید از سوپرماکت دیجی کالا کنید.
انواع نودل‌ها، کنسرو و فرآورده‌های منجمد و یخچالی، تن ماهی و کمپوت از سوپرماکت آنلاین دیجی کالا قابل خریداری است. تجهیزات سوپرمارکت دیجی کالا شرایط نگهداری و ارسال انواع فرآورده‌ی منجمد را بر اساس مصرف محصول فراهم کرده است. همچنین در دسته‌ی نوشیدنی انواع قهوه فوری و هات چاکلت، چای، نوشابه، ماءالشعیر، دمنوش، عرقیات و گلاب برای خرید در دسترس شماست. دسته‌بندی خشکبار و شیرینی سوپرمارکت اینترنتی دیجی کالا شبیه یک دکه خواربار فروشی‌ست که می‌توانید در آن هر نوع خشکبار و آجیل، شیرینی و خرما را برای پذیرایی از مهمان خریداری کنید. همچنین بخش کالاهای غیرخوراکی سوپرمارکت شامل انواع ملزومات خانه، لوازم بهداشتی، مواد شوینده، محصولات سلولزی و غیره است.
</p>
</article>
<article className={classes.articleTag}>
<h1 className={classes.hOne}>مزایای خرید اینترنتی از سوپرماکت دیجی کالا </h1>
<p className={classes.paragraph}>
در فروشگاه اینترنتی مواد غذایی دیجی کالا بخشی به نام شگفت‌انگیزهای سوپرمارکتی وجود دارد که شامل انواع محصولات سوپر مارکتی منتخب با تخفیف ویژه است. شما می‌توانید هر روز تعدادی از پیشنهادهای شگفت‌انگیز و فروش ویژه محصولات سوپرمارکتی را در این صفحه مشاهده کنید. در این قسمت سایت به طور متداوم کالاهای گوناگون و در عین حال اساسی را با تخفیف به فروش می‌رساند. به طور کلی محصولات و خوراکی‌ها در سوپرمارکت دیجی کالا با تخفیف به فروش می‌رسند و برای اولین سبد خرید خود می‌توانید از کد ویژه‌ای که در بخش بالای سایت قرار دارد استفاده کنید.

</p>
</article>
<article className={classes.articleTag}>
<h1 className={classes.hOne}>مزایای خرید اینترنتی از سوپرماکت دیجی کالا </h1>
<p className={classes.paragraph}>
در فروشگاه اینترنتی مواد غذایی دیجی کالا بخشی به نام شگفت‌انگیزهای سوپرمارکتی وجود دارد که شامل انواع محصولات سوپر مارکتی منتخب با تخفیف ویژه است. شما می‌توانید هر روز تعدادی از پیشنهادهای شگفت‌انگیز و فروش ویژه محصولات سوپرمارکتی را در این صفحه مشاهده کنید. در این قسمت سایت به طور متداوم کالاهای گوناگون و در عین حال اساسی را با تخفیف به فروش می‌رساند. به طور کلی محصولات و خوراکی‌ها در سوپرمارکت دیجی کالا با تخفیف به فروش می‌رسند و برای اولین سبد خرید خود می‌توانید از کد ویژه‌ای که در بخش بالای سایت قرار دارد استفاده کنید.

</p>
</article>
<article className={classes.articleTag}>
<h1 className={classes.hOne}>مزایای خرید اینترنتی از سوپرماکت دیجی کالا </h1>
<p className={classes.paragraph}>
در فروشگاه اینترنتی مواد غذایی دیجی کالا بخشی به نام شگفت‌انگیزهای سوپرمارکتی وجود دارد که شامل انواع محصولات سوپر مارکتی منتخب با تخفیف ویژه است. شما می‌توانید هر روز تعدادی از پیشنهادهای شگفت‌انگیز و فروش ویژه محصولات سوپرمارکتی را در این صفحه مشاهده کنید. در این قسمت سایت به طور متداوم کالاهای گوناگون و در عین حال اساسی را با تخفیف به فروش می‌رساند. به طور کلی محصولات و خوراکی‌ها در سوپرمارکت دیجی کالا با تخفیف به فروش می‌رسند و برای اولین سبد خرید خود می‌توانید از کد ویژه‌ای که در بخش بالای سایت قرار دارد استفاده کنید.

</p>
</article>


<span className={classnames(classes.closer,'closer')}>
  <span> نمایش بیشتر </span>
   <ExpandMoreIcon className="exp"/>
</span>

</div>

<br/>
<br/>
<br/>
<div style={{ height:'400px',width:'100%' }}>

</div>




        </div>
    )
}
