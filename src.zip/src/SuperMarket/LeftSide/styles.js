import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({
    container:{
        display:'flex',
        flexDirection:'column',
        width:'auto',
        height:'auto' ,
         direction:'rtl',
        maxHeight:'2409px',
        borderRadius:'5px',
        padding:'20px 20px 20px 0px',
        
        textAlign:'right'
     },
     supriseSuper:{
         display:'flex',
         flexDirection:"column",
         height:'450px',
         marginTop:'20px',
         width:'100%',
         backgroundColor:"white"
     },
     supHead:{
         display:'flex',
         flexDirection:'row',
         justifyContent:'space-between',
         height:'50px',
         alignItems:'center',
         borderTop:'3px #6bb927 solid',
         paddingLeft:'30px',
         paddingRight:'50px'

     },
     showAll:{
         color:'#7b7c7f',
         fontSize:'20px',
         textDecoration:'none',
         '&:hover':{
             textDecoration:'none',
             color:'#7b7c7f'
         },
         cursor:'pointer'
     },
     supImg:{
         display:'block',
         height:'50px',
         width:'250px',
         marginTop:'-5px',
         
     }, 
     divImg:{
         display:'inline-block',
        height:'50px',
        width:'250px',
        marginTop:0
     },
     supBody:{
         display:'flex',
         flexDirection:'row',
         height:'330px',
         padding:'10px 30px 30px 30px'

     },
     rightSup:{
      width:'65%',
      paddingRight:'40px',
      display:'flex',

     },
     rightSupImg:{
        display:'block',
        width:'270px',
        height:'250px',
        margin:'auto 0px'
     },
     rightSupTitle:{
display:'flex',
flexDirection:'column',
justifyContent:'space-between',
width:'100%',
paddingLeft:'40px'

     },
     rightSupTitleUp:{
        display:'flex',
        flexDirection:'column',
        direction:'rtl',
        height:'40%'
        
             },
    rightSupTitleDown:{
                display:'flex',
                flexDirection:'column',
                direction:'ltr',
                textAlign:'left',
                height:'40%'
                
                     },
                     btn:{
                        display:'inline',width:'auto',padding:'13px 20px',
                        backgroundColor:'#ef394e',
                        color:'white',
                        borderRadius:'5px',
                        outline:'none',
                        border:'none',
                        fontSize:'18px',
                        width:'50%',
                        cursor:'pointer'

                     },
     
     leftSup:{
width:'35%',
display:'flex',
flexDirection:'column',
borderRight:'2px solid black',
paddingLeft:'25px'
     }
     ,
     supUl:{
         display:'flex',
         flexDirection:'column',
         paddingRight:'20px',
         overflow:'hidden',
         flexWrap:'no-wrap',
         width:'100%',
         height:'100%',
       

     },
     supLi:{
         display:'flex',
         flexDirection:'row',
         width:'99%',
         height:'20%',
         alignItems:'center',
         cursor:'pointer',
         

     },

     supLiImg:{
         display:'block',
         width:'40px',
         height:'40px'
     },
     thImg:{
         display:'block',
         height:'40px',
         width:'40px',
     },
     types:{
         display:'flex',
         flexDirection:'row',
         padding:'20px 0px 10px 0px' ,
         justifyContent:'space-around',
         flexWrap:'nowrap'
     },
     type:{
         display:'inline',
         borderRadius:'5px',
         flex:'1',
         height:'100%',
         width:'auto',
         backgroundColor:'#f1f1f1'
     },
     typeImg:{
         display:'block',
         width:'',
         height:'212px',
         width:'284px',
         borderRadius:'5px'
     },
     carousel:{
         display:'flex',
        flexDirection:'column',
        width:'100%',
        height:'415px',
        direction:'rtl',
        backgroundColor:'white',
        marginTop:'10px',
        borderRadius:'10px'
        
        },
        
        carouselHeader:{
            height:'55px',
            
            display:'flex',
            flexDirection:'row',
            padding:'0px 20px',
            alignItems:'center'


        },
        carouselHeaderRight:{
         width:'10%',
         borderBottom:'1px solid  #f5959c',
         cursor:'pointer'
        },
        carouselHeaderLeft:{
       width:'90%',
       borderBottom:'1px solid #ebebeb',
       textAlign:'left'
        },
        carouselBody:{
            height:'100%',
            width:'100%',
            position:'relative',
            direction:'rtl',
           
            overflow:'hidden',
            float:'right',
            marginTop:'5px'
        },

        rightNav:{
        position :'absolute',
         padding:'32px 12px' ,
         borderTop:'3px solid #f9f9f9',
         borderLeft:'3px solid #f9f9f9',
         borderBottom:'3px solid #f9f9f9',
         right:'0px',
         top:'30%',
         cursor:'pointer',
         zIndex:'1000 !important',
         borderBottomLeftRadius:'5px',
         borderTopLeftRadius:'5px',
         '&:disabled':{
             cursor:'not-allowed',
             
         },
         '&:hover':{
             boxShadow:'0px 0px 5px 5px #f1f1f1'
         }
        },
        leftNav:{
        position:'absolute',
        zIndex:'12000 !important',
         padding:'32px 12px',
         borderTop:'3px solid #f9f9f9',
         borderRight:'3px solid #f9f9f9',
         borderBottom:'3px solid #f9f9f9',
         left:'0px ',
         top:'30%',
         cursor:'pointer',
         borderBottomRightRadius:'5px',
         borderTopRightRadius:'5px',
        
         '&:disabled':{
             cursor:'not-allowed'
         },
         '&:hover':{
             boxShadow:'0px 0px 5px 5px #f1f1f1'
         }
        },

        carouselInner:{
            transition: '1s ease all',
            float:'right',marginRight:'8px',
            marginLeft:'8px',
            marginTop:'8px',
            paddingRight:'30px',
            display:'flex',
            overflow:'visible',
         
            
            flexWrap:'nowrap'
        },
        carouselItem:{
          
            width:'220px',
            height:'327px',
            textAlign:'right',
            '&:hover':{
                boxShadow:'0 0 5px rgba(188, 247, 198, 1)'
            },
            marginRight:'3px',
            marginLeft:'3px'
           
            },
            carouselItemTitle:{
             direction:'rtl',
            textAlign:'right'  ,
        padding:'0px 10px' ,
    height:'50px',marginTop:'30px'       ,
    cursor:'pointer' 
 },
 carouselItemBody:{
 display:'flex',
cursor:'pointer',
 direction:'ltr',
 justifyContent:'space-between',
 alignItems:'center',
 padding:'0px 10px'
 },
            
        carouselArrow:{
            cursor:'pointer',
            position:'absolute',
            top:'50%',
            padding: '30px 20px',
            marginTop: '-60px',
            fontWeight: 'bold',
            fontSize: '18px',
            transition: '0.6s ease',
            borderRadius: '0 3px 3px 0',
            userSelect: 'none',
            '&:hover':{
                backgroundColor:'#e6e6e6'
            }
        },
        carouselArrowNext:{
            right:'0%',
            borderRadius:'3px 0 0 3px',
            textDecoration:'none',

            boxShadow:'0 0 15px #e6e6e6',
            color:"black",
            fontSize:'25px'
        },
        carouselArrowPrev:{
            left:'0%',
            borderRadius:'3px 0 0 3px',
            textDecoration:'none',
            boxShadow:'0 0 15px #e6e6e6',
            color:"black",
            fontSize:'25px'
        },
        carouselImg:{
            display:'block',
            width:'170px',
            height:'170px',
            margin:"auto",
            cursor:'pointer'
        },
        adpalacement:{
            display:'flex',
            flexDirection:'row',
            direction:'rtl',
            flexWrap:'wrap'
        },
        adpalacementLink:{
            marginLeft:'20px',
            marginTop:'20px',
            display:'block',
            width:'370px',
            height:'170px',
            cursor:'pointer'
            
        },
        adpalacementImg:{
            display:'block',
            borderRadius:'10px',
            width:'100%',
            height:'100%'
        },
        article:{
            border:'1px solid #dddddd',
            padding:'20px 30px',
            backgroundColor:'white',
            marginTop:'50px',
            maxHeight:'380px',
            height:"auto",
            minHeight:"380px",
            overflowY:'hidden',
            
            marginBottom:'60px',
            position:'relative'
           
        },
        hOne:{
            color:'#9e9e9e',
            fontSize:'18px'
        },
        paragraph:{
            color:'#9e9e9e',
            lineHeight:1.3

        },
        closer:{
            width:"100%",
            position:'absolute',
            zIndex:'20',
            display:'flex',
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'white',
            bottom:'0%',
            height:'70px',
            right:'0%',
            cursor:'pointer',
            opacity:'0.5'
        },
        articleTag:{
            marginTop:'40px'
        }
        
     


});
export default useStyles;