import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({
container:{
   display:'flex',
   flexDirection:'column',
   width:'100%',
   height:'auto' ,
   maxHeight:'2409px',
   borderRadius:'5px',
   padding:'20px 20px 20px 0px',
   backgroundColor:'white',
   textAlign:'right' 
},
h6hed:{
    fontSize:'16px !important'
},
btmborder:{
  borderBottom:'1px solid #f3f3f3'  ,
  paddingBottom:'10px'
  
},
center:{
    display:'flex',
    alignItems:'center'
},
unlist:{
    display:'flex',
    flexDirection:'column',
    listStyleType:'none',
    paddingRight:'0px ',
   
    height:'auto',
    overflowY:'hidden'
  

},
unlistN:{
    display:'flex',
    flexDirection:'column',
    listStyleType:'none',
    paddingRight:'0px ',
    maxHeight:'158px',
    height:'auto',
    overflowY:'hidden'
  

},
unlistItem:{
    display:'flex',
    flexDirection:'row',
    lineHeight:'10px',
    fontSize:'17px'
},
unlistItemt:{
    display:'flex',
    flexDirection:'row',
    lineHeight:'10px',
    borderBottom:'1px solid #f6f6f6',
    paddingBottom:'15px',
    marginBottom:'0px !important',
    marginTop:'-5px !important'
},
unlistitemLink:{
    '&:hover':{
        color:'#177dcb',
        textDecoration:'none'
    },
    fontSize:'17px',
    color:'#696969',
    textDecoration:'none',
    cursor:'pointer'
},
unlistitemLinkt:{
   opacity:'0.5',
    fontSize:'15px',
    color:'#696969',
    textDecoration:'none',
    cursor:'pointer'
},
unLink:{
    textDecoration:'none',
    fontSize:'16px',
    fontWeight:'normal',
    color:'black',
   
}
});
export default useStyles;