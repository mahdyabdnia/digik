import React,{useEffect,useState} from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import classnames from 'classnames'
import {Link } from 'react-router-dom'
import { isTemplateElement } from '@babel/types'
export default function RightSide() {
    const classes=useStyles();
  const types=[{id:1,name:'کالاهای اساسی و خوار وبار',subType:[{sid:1,sname:'نان '},{sid:2,sname:'برنج '},{sid:3,sname:'روغن'},
  {sid:4,sname:'قند و نبات '},{sid:5,sname:'شکر '},{sid:6,sname:'سس '},{sid:6,sname:'دسر '},{sid:8,sname:'ماکارونی '},
]},
{id:2,name:'لبنیات',subType:[{sid:1,sname:'شیر '},{sid:2,sname:'کره'},{sid:3,sname:'دوغ'},
  {sid:4,sname:'ماست '},{sid:5,sname:'کشک '},{sid:6,sname:'خامه'},{sid:6,sname:'دسر آماده  '},{sid:8,sname:'پنیر '},
]},
{id:3,name:'محصولات پروتوئینی',subType:[{sid:1,sname:'گوشت گاو و شتر و گوساله'},{sid:2,sname:'گوشت مرغ'},{sid:3,sname:'تخم مرغ '},
  {sid:4,sname:'سوسیس'},{sid:5,sname:'کالباس '},{sid:6,sname:'گوشت گوسفند '},{sid:6,sname:'گوشت پرندگان'},{sid:8,sname:'خاویار'},
]},
{id:4,name:'صبحانه ',subType:[{sid:1,sname:'حلوا شکری '},{sid:2,sname:'مربا  '},{sid:3,sname:'ارده '},
  {sid:4,sname:'غلات صبحانه  '},{sid:5,sname:'شکلات صبحانه  '},{sid:6,sname:'عسل '},{sid:6,sname:'کره بادام زمینی '}
]},
{id:5,name:'نوشیدنی',subType:[{sid:1,sname:'قهوه '},{sid:2,sname:'چای'},{sid:3,sname:'شربت و آبمیوه '},
  {sid:4,sname:'آب و آب معدنی'},{sid:5,sname:'نوشابه  '},{sid:6,sname:'ماء الشغیر'},{sid:6,sname:'دمنوش '},{sid:8,sname:'عرقیات و گلاب '},
]},
{id:6,name:'خشک بار و شیرینی',subType:[{sid:1,sname:'خشکبار و آجیل '},{sid:2,sname:'شیرینی '},{sid:3,sname:'خرما'},
  
]},

]


    
    useEffect(() => {
        increaseHeight();
        
    }, []);
    const increaseHeight=()=>{
        var pluse=document.getElementsByClassName('pluseHeight');
        var i;
        for(i=0;i<pluse.length;i++){
          pluse[i].addEventListener('click',function(){
              var father=this.previousSibling.firstChild;
              
              
                if(father.style.maxHeight==="158px"){
                  father.style.maxHeight = father.scrollHeight + "px";
                  this.firstChild.innerHTML="- موارد کمتر"

                }
                else{
                  father.style.maxHeight="158px"
                  this.firstChild.innerHTML="+ موارد بیشتر"
                }     
                  

               
              
             

          });
        }
    }
   
   
    return (
        <div className={classes.container}>
            <div className={classnames(classes.btmborder)} >
            <Typography variant="h6" color="initial" className={classes.h6hed}>دسته بندی های کالا های سوپر مارکتی </Typography>
            </div>

            <div className={classes.btmborder}>
             
               
              {types.map((item)=>{
                return(<ul className={classes.unlist}>
                   <Link className={classes.unLink}>{item.name}</Link>
                   {item.subType.length<=5 &&
                  <li>  <ul className={classes.unlistN}>
                      {item.subType.map((itm)=>{
                        return(<li className={classes.unlistItem}>
                          <Link href="" className={classes.unlistitemLink}> {itm.sname}</Link>
                        </li>)
                      })}
                    </ul></li>
                   }
                  {item.subType.length>5 &&
                  <>
                  <li><ul className={classes.unlistN}>
                    {item.subType.map((itm)=>{
                      return(<li className={classes.unlistItem}>
                        <Link href="" className={classes.unlistitemLink}> {itm.sname}</Link>
                      </li>)
                    })}
                    
                    </ul></li>

                    <li className={classnames(classes.unlistItemt,'pluseHeight')}>
                   <Link href="" className={classes.unlistitemLinkt}>+ موارد بیشتر</Link>
                 </li>


                  </>
                  }
                </ul>)
              })}
                

                
            </div>

            
        </div>
    )
}



