import React from 'react'
import Head from './Head/Head';
import LeftSide from './LeftSide/LeftSide';
import RightSide from './RightSide/RightSide';
import useStyles from './styles'
export default function SuperMarket() {
    const classes=useStyles();
    return (
        <div className={classes.container} >
            <Head/>
            <div className={classes.row}>
                <div className={classes.right}>
                    <RightSide/>
                
                </div>
                <div className={classes.left}>
                    <LeftSide/>  
                </div>
            </div>
        </div>
    )
}
