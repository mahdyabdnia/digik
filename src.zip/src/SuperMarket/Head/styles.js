import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({
container:{
    height:'45px',
    width:'100%',
    display:'flex',
    flexDirection:'row',
    alignItems:'center',
    borderRadius:'5px',
    border:'1px solid #fbfbfb',
    backgroundColor:'white'
    
},
sLink:{
     color:'#42b10b',
     backgroundColor:'#ebf6e5'   ,
     height:'45px',
     display:'flex',
     alignItems:'center',
     padding:'0px 30px',
     fontWeight:'bold',
     borderTopRightRadius:'5px',
     borderBottomRightRadius:"5px"
},
ulHead:{
    display:'inline-flex',
    flexDirection:'row',
    listStyleType:'none',
    alignItems:'center',
    paddingRight:'0px'

},
liHead:{
    display:'inline-flex',
    flexDirection:'row',
    fontSize:'17px',
    color:'#7f8288',
    cursor:'pointer'

}
});

export default useStyles;