 import React from 'react'
 import useStyles from './styles'
 export default function Head() {
     const classes=useStyles();
     return (
         <div className={classes.container}>
             <a className={classes.sLink}>سوپر مارکت </a>
             <ul className={classes.ulHead}>

                 <li className={classes.liHead}> شگفت انگیز سوپر مارکتی </li>
                 <li className={classes.liHead}> محصولات پروتوئینی </li>
                 
                 <li className={classes.liHead}> شگفت انگیز سوپر مارکتی </li>
                 <li className={classes.liHead}> محصولات پروتوئینی </li>
                 
                 
                 <li className={classes.liHead}> شگفت انگیز سوپر مارکتی </li>
                 <li className={classes.liHead}> محصولات پروتوئینی </li>
                 
                 
                 <li className={classes.liHead}> شگفت انگیز سوپر مارکتی </li>
                 <li className={classes.liHead}> محصولات پروتوئینی </li>
                 
                 
             </ul>
             
         </div>
     )
 }
 