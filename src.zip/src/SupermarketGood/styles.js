import { makeStyles } from "@material-ui/core";
const useStyles=makeStyles({
    container:{
        display:'flex',
        flexDirection:'column',
       
       
        
       height:'max-content',
        direction:'rtl',
       
    },
    head:{
     backgroundColor:"#39ae00",
     height:'auto',
     display:'flex',
     flexDirection:'column',
     
     height:'auto',
     minHeight:'190px'
    
    },
    row:{
        display:'flex',
        flexDirection:'row',
        position:'relative',
        justifyContent:'space-between',
        minHeight:'1000px',
        maxHeight:'1000px'

    },
   adBox:{
       marginTop:'50px',
    

       display:'flex',
       flexDirection:'row',
       justifyContent:'space-around',
       marginBottom:'50px',
    
   },
   img:{
       display:'inline-flex',
       width:'363px',
       height:'251px'
   },
  articleBox:{
       display:'flex',
       border:'#dfdfdf 1px solid ',
     
       backgroundColor:'white',
       flexDirection:'column',
       width:'95%',
       margin:'0px auto 50px auto',
       padding:'20px',
       maxHeight:'290px',
       overflow:'hidden',
       position:'relative',
       zIndex:'1 !important'
   },
   artHead:{
       margin:'20px 0px '
   },
   artP:{
       lineHeight:'2'
   },
   exp:{
       position:'absolute',
       display:'flex',
       justifyContent:'center',
       alignItems: 'center',
       bottom:'10px',
       opacity:'0.5',
       height:'70px',
       width:'100%',
       zIndex:'1000000 !important'
   }
});

export default useStyles;