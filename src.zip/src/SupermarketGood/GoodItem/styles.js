import { makeStyles } from "@material-ui/core";
const useStyles=makeStyles({
container:{
    display:'flex',
    flexDirection:'column',
    border:'1px solid #edebeb',
    width:'300px',
    height:'423px',
    paddingTop:'40px',
    postion:'relative'
    
},
imgBox:{
    display:'flex',
    width:'300px',
    height:'190px'
},
img:{
    display:'block',
    margin:'auto',
    width:'190px',
    height:'190px'
},
titleBox:{
    display:'flex',
    flexDirection:'column',
    padding:'10px 20px'
},
sendBox:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems: 'center',
    marginTop:'20px'
},
ship:{
    display:'flex',
    alignItems: 'center',
},
shopBox:{
   marginTop:'50px',
   display:'none',
   flexDirection:'row',
   borderTop:'1px solid #edebeb',
   height:'50px',
   alignItems: 'center',
}
});

export default useStyles;