import React,{useEffect} from 'react'
import useStyles from './styles'
import { Typography } from '@material-ui/core';
import LocalShippingOutlinedIcon from '@material-ui/icons/LocalShippingOutlined';
import StoreIcon from '@material-ui/icons/Store';
import classnames from 'classnames'
export default function GoodItem() {
    useEffect(() => {
    var shopBox=document.getElementsByTagName('shopBox');
    var i;
    for(i=0;i<shopBox.length;i++){
        shopBox[i].addEventListener('hover',function(){
            this.style.display="flex"
        })
    }
    }, []);
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <div className={classes.imgBox}>
                <img src="images/sup2.jpg" alt=""  className={classes.img}/>
            </div>
            <div className={classes.titleBox}>
                <Typography variant="body1" color="textSecondary">نان لواش سه نان مجموعه 8 عددی</Typography>
                <div className={classes.sendBox}>
                    <span className={classes.ship}><LocalShippingOutlinedIcon style={{ transform:'scaleX(-1)',color:'#84c44c' }}/><span style={{   color:'#7b7e84',fontSize:'14px'  }}>ارسال سریع سوپر مارکتی</span></span>
                    <span></span>
                </div>
                <div className={classes.sendBox}>
                    <span style={{ color:'white',padding:'10px 25px',backgroundColor:'#ef394e',borderRadius:'5px',fontStyle:'bold' }}>+</span>
                    <span>11 000 تومان</span>
                </div>

                <div className={classnames(classes.shopBox,'shopBox')}><StoreIcon/> <Typography variant='body1' style={{ marginRight:'10px' }} color="textSecondary">  فروشنده :</Typography>  <Typography variant='body1' style={{ marginRight:'10px' }} color="textSecondary">دیجی کالا</Typography> </div>
            </div>
            
        </div>
    )
}
