import React,{useEffect} from 'react'
import useStyles from './styles'
import Head from './Head/Head'
import {Typography} from '@material-ui/core'
import Right from './Right/Right'
import Left from './Left/Left'
import {ExpandMoreRounded} from '@material-ui/icons'
import classnames from 'classnames'
export default function SupermarketGood() {
    useEffect(() => {
        var expand=document.getElementsByClassName('expand');
        var i;
        for(i=0;i<expand.length;i++){
            expand[i].addEventListener('click',function(){
                var parent=this.parentNode;
                var firstChild=this.firstChild;
                var lastChild=this.lastChild;
                if(parent.style.maxHeight==='290px'){
                    parent.style.maxHeight=' 900px';
                    parent.style.minHeight=' 900px';
                    firstChild.innerHtml="نمایش بیشتر";
                    lastChild.style.transform="rotate(180deg)"

                }
                else{
                    parent.style.maxHeight='290px';
                    parent.style.minHeight='290px';
                    
                    firstChild.innerHtml="بستن";
                    lastChild.style.transform="rotate(360deg)"
                }
            })
        }
        
    }, []);
    useEffect(() => {
        window.onload=function(){
            
            window.scrollTo(0,0);
            document.documentElement.scrollTop=0;
            document.documentElement.scrollTo(0,0)
        }
        return () => {
            
        }
    }, [])
    const classes=useStyles()
    return (
        <div className={classes.container}>
           <div className={classes.head}>
           <Head/>
          <div style={{ paddingRight:'80px',paddingLeft:'20px',marginTop:'20px',display:'flex',alignItems: 'center', }}>
          <div style={{ borderLeft:'1px white solid',width:'240px' }}>
          <img src="images/superHead.png" style={{width:'184px',height:'34px'}}/> 
          </div>
          <Typography variant="h6" style={{ color:'white',marginRight:'20px' }}>ارسال سریع سه ساعته کالاها در تهران و کرج </Typography>
         
              </div> 
              <p style={{ color:'white',marginRight:'300px' }}>فروشگاه اینترنتی دیچی کالا / کالاهای سوپر مارکتی / کالاهای اساسی خوارو بار</p>
           </div>

           <div className={classes.row}>
               <Right/>
               
                
              
             <Left/>
           </div>

           <div className={classes.adBox}>
               <img className={classes.img} src="images/superAd.jpg" alt="" />
               <img className={classes.img} src="images/superAd.jpg" alt="" />
               <img className={classes.img} src="images/superAd.jpg" alt="" />
               <img className={classes.img} src="images/superAd.jpg" alt="" />
           </div>

           <div className={classnames(classes.articleBox,'articleBox')}>
          <Typography variant="h6" className={classes.artHead}>نان</Typography> 
          <Typography variant="body1" color="textSecondary" className={classes.artP} >نان یکی از اعضای ثابت و جدانشدنی سفره‌‌های مردم در سراسر جهان است و تمام مناطق جهان نان مخصوص خودشان را دارند. در ایران نیز تنوع نان بسیار زیاد است و در هر نقطه‌ای می‌توانید نان سنتی و محلی همان منطقه را پیدا کنید که طرز تهیه‌ی منحصربه‌فرد و در نتیجه مزه و عطر و بوی خاص خودش را دارد. اغلب نان‌ها از آرد گندم تهیه می‌شوند که برای تهیه‌ی کیک و شیرینی هم کاربردی است، هرچند نان جو و نان ذرت که با آرد جو و ذرت تهیه می‌شوند هم در دسترس هستند
          <br/>
نان و پنیر یک صبحانه‌ی ساده و در عین حال خوشمزه است و بیشتر ما خاطره‌ای از لقمه‌ی نان بربری و سنگگ داغ با پنیر که گاهی با چیزهایی مانند گردو، خرما یا هندوانه و گوجه و خیار و ... خورده می‌شد یا نان خشک تلیت شده در آب دوغ خیار شب‌های تابستان داریم، اما این روزها با پیشرفت تکنولوژی و نانوایی‌های مکانیزه و کارخانه‌ها مصرف نان بسته‌بندی هم در کنار نان‌های سنتی افزایش زیادی داشته است و مردم از بسیاری از این نان‌ها استفاده می‌کنند و این روزها نان تست با نوتلا و خانه صبحانه‌ی محبوب خیلی از کودکان به‌حساب می‌آید. علاوه بر این انواع محصولاتی مانند خمیر تاکو و خمیر پیراشکی به بازار آمده‌اند که برای پخت فوری بعضی غذاها استفاده می‌شوند و در چند دقیقه می‌توانید انواع تاکو و پیراشکی‌ را آماده کرده و در تابه سرخ کنید.

</Typography>
<Typography variant="h6" color="textSecondary" className={classes.artHead}>انواع نان</Typography>
<Typography variant="body1" color="textSecondary" className={classes.artP} >اگر بخواهیم لیستی از انواع نان درست کنیم، لیست بلند بالایی خواهید شد اما تعدادی از نان‌های مشهوری که به‌صورت سنتی یا بسته‌بندی در ایران موجود هستند را در ادامه لیست می‌کنیم:
•    نان بربری
•    نان سنگگ
•    نان لواش
•    نان ساندویچی که با نام نان فانتزی هم شناخته می‌شود.
•    نان بولکی 
•    نان تست
•    نان جو 
•    نان سوخاری
•    نان خشک
•    نان پیتا
•    نان گاتا
•    نان برونسی
•    نان همبرگر 
•    نان هات داگ</Typography>

<Typography variant="h6" className={classes.artHead} >نان</Typography> 
          <Typography variant="body1" color="textSecondary" className={classes.artP} >نان یکی از اعضای ثابت و جدانشدنی سفره‌‌های مردم در سراسر جهان است و تمام مناطق جهان نان مخصوص خودشان را دارند. در ایران نیز تنوع نان بسیار زیاد است و در هر نقطه‌ای می‌توانید نان سنتی و محلی همان منطقه را پیدا کنید که طرز تهیه‌ی منحصربه‌فرد و در نتیجه مزه و عطر و بوی خاص خودش را دارد. اغلب نان‌ها از آرد گندم تهیه می‌شوند که برای تهیه‌ی کیک و شیرینی هم کاربردی است، هرچند نان جو و نان ذرت که با آرد جو و ذرت تهیه می‌شوند هم در دسترس هستند
          <br/>
نان و پنیر یک صبحانه‌ی ساده و در عین حال خوشمزه است و بیشتر ما خاطره‌ای از لقمه‌ی نان بربری و سنگگ داغ با پنیر که گاهی با چیزهایی مانند گردو، خرما یا هندوانه و گوجه و خیار و ... خورده می‌شد یا نان خشک تلیت شده در آب دوغ خیار شب‌های تابستان داریم، اما این روزها با پیشرفت تکنولوژی و نانوایی‌های مکانیزه و کارخانه‌ها مصرف نان بسته‌بندی هم در کنار نان‌های سنتی افزایش زیادی داشته است و مردم از بسیاری از این نان‌ها استفاده می‌کنند و این روزها نان تست با نوتلا و خانه صبحانه‌ی محبوب خیلی از کودکان به‌حساب می‌آید. علاوه بر این انواع محصولاتی مانند خمیر تاکو و خمیر پیراشکی به بازار آمده‌اند که برای پخت فوری بعضی غذاها استفاده می‌شوند و در چند دقیقه می‌توانید انواع تاکو و پیراشکی‌ را آماده کرده و در تابه سرخ کنید.

</Typography>
<Typography variant="h6" className={classes.artHead}>نان</Typography> 
          <Typography variant="body1" color="textSecondary" className={classes.artP} >نان یکی از اعضای ثابت و جدانشدنی سفره‌‌های مردم در سراسر جهان است و تمام مناطق جهان نان مخصوص خودشان را دارند. در ایران نیز تنوع نان بسیار زیاد است و در هر نقطه‌ای می‌توانید نان سنتی و محلی همان منطقه را پیدا کنید که طرز تهیه‌ی منحصربه‌فرد و در نتیجه مزه و عطر و بوی خاص خودش را دارد. اغلب نان‌ها از آرد گندم تهیه می‌شوند که برای تهیه‌ی کیک و شیرینی هم کاربردی است، هرچند نان جو و نان ذرت که با آرد جو و ذرت تهیه می‌شوند هم در دسترس هستند
          <br/>
نان و پنیر یک صبحانه‌ی ساده و در عین حال خوشمزه است و بیشتر ما خاطره‌ای از لقمه‌ی نان بربری و سنگگ داغ با پنیر که گاهی با چیزهایی مانند گردو، خرما یا هندوانه و گوجه و خیار و ... خورده می‌شد یا نان خشک تلیت شده در آب دوغ خیار شب‌های تابستان داریم، اما این روزها با پیشرفت تکنولوژی و نانوایی‌های مکانیزه و کارخانه‌ها مصرف نان بسته‌بندی هم در کنار نان‌های سنتی افزایش زیادی داشته است و مردم از بسیاری از این نان‌ها استفاده می‌کنند و این روزها نان تست با نوتلا و خانه صبحانه‌ی محبوب خیلی از کودکان به‌حساب می‌آید. علاوه بر این انواع محصولاتی مانند خمیر تاکو و خمیر پیراشکی به بازار آمده‌اند که برای پخت فوری بعضی غذاها استفاده می‌شوند و در چند دقیقه می‌توانید انواع تاکو و پیراشکی‌ را آماده کرده و در تابه سرخ کنید.

</Typography>
<span className={classnames(classes.exp,'expand')}><sapn>نمایش بیشتر</sapn><span><ExpandMoreRounded/></span></span>

          </div>

           
            
        </div>
    )
}
