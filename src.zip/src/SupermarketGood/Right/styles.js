import { makeStyles } from "@material-ui/core";
const useStyles=makeStyles({
    right:{
        display:'flex',
        flexDirection:'column',
        position:'absolute',
        width:'18%',
        right:'10px',
        top:'-50px',
        zIndex:'10',
       
        
    },
    infoSend:{
backgroundColor:'white',
height:'80px',
borderRadius:'10px',
position:'relative'
    },
    categories:{
        marginTop:'10px',
        borderRadius:'10px',
        display:'flex',
        flexDirection:'column',
        padding:'10px',
        backgroundColor:'white'
    },
    listHead:{
        display:'flex',
        alignItems:'center',
        color:'#5d5d5d',
        fontWeight:'normal',
        marginTop:'10px'
    },
    leftArrow:{
        color:'#999999',
        fontSize:'18px',
        marginLeft:'10px'
    },
    ulList:{
        padding:'0px',
        margin:'0px 10px 20px 0px'
    },
    UlLink:{
        display:'flex',
        alignItems:'center',
        color:'#5d5d5d',
        fontWeight:'normal',
        marginTop:'10px' 
    },
    listItem:{
        marginRight:'30px !important'
    },
    searchBar:{
        display:'flex',
        flexDirection:'column',
        backgroundColor:'white',
        borderRadius:'10px',
        marginTop:'10px',
      
        padding:'10px 10px 5px 10px'
        
    },
    searchBox:{
        display:'flex',
        flexDirection:'row',
        alignItems:'center',
        backgroundColor:'#f1f1f1',
        width:'95%',
        margin:' 10px auto',
        height:'35px',
        borderRadius:'5px',
        paddingRight:'10px',
        
    },
    
    searchInput:{
        outline:'none',
        border:'none',
        backgroundColor:'#f1f1f1',
        margin:'auto',
        display:'block',
    '&:focus':{
        outline:'none',
        border:'none',
        backgroundColor:'#f1f1f1'
    }
    },
    brandBar:{
        display:'flex',
        flexDirection:'column',
        marginTop:'10px',
        backgroundColor:'white',
        borderRadius:'5px',
        padding:'10px',
        
        overflowY:'hidden',
        marginBottom:'10px'


    },
    acc:{
        display:'flex',
        flexDirection:'row',
        alignItems: 'center',
        justifyContent:'space-between',
        marginBottom:'10px'

    },
    checkList:{
        display:'flex',
        padding:'0px',
        listStyleType:'none',
        flexDirection:'column'
    },
    checkItem:{
        display:'flex',
        flexDirection:'row',
        margin:'5px 5px',
        justifyContent:'space-between',
        alignItems: 'center',
        fontSize:'15px'
    },
    checkBox:{
        borderRadius:'5px',
        width:'30px'
    },
    brandBox:{
        display:'block'
    },
    switchBox:{
        display:'flex',
        backgroundColor:'white',
        borderRadius:'5px',
        marginTop:'10px',
        alignItems: 'center',
        justifyContent:'flex-start',
        paddingRight:'10px'

    }
   
})

export default useStyles;