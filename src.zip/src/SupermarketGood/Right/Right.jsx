import React,{useEffect,useState} from 'react'
import useStyles from './styles'
import { Typography,Divider } from '@material-ui/core';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import DoubleArrowIcon from '@material-ui/icons/DoubleArrow';
import { SearchOutlined } from '@material-ui/icons';
import classnames from 'classnames'
import { Switch } from '@material-ui/core';
import './style.css'
export default function Right() {
    const [checkA, setCheckA] = useState(false)
    const classes=useStyles();
    useEffect(() => {
        var input=document.getElementsByClassName('searchInput')[0];
        input.addEventListener('click',function(){
            var parent=this.parentNode;
           parent.classList.add('searchBoxF');
          
           
        })
        return () => {
            
        }
    }, [])
    useEffect(() => {
    var acc=document.getElementsByClassName('acc')[0];
    acc.addEventListener('click',function(){
        var panel=document.getElementsByClassName('brandBox')[0];
        var expand=document.getElementsByClassName('expand')[0];
        if(panel.style.display==="block"){
            panel.style.display="none";
            expand.style.transform="rotate(360deg)"
            expand.style.transition="0.5s"
        }
        else{
            panel.style.display="block";
            expand.style.transform="rotate(180deg)"
            expand.style.transition="0.5s"
        }
      
    })
    }, []);
    return (
        <div className={classes.right}>
                   <div className={classes.infoSend}>
                       <h4 style={{ fontWeight:'normal',marginRight:'10px ',margin:'10px 10px 0px 0px' }}>ارسال رایگان اولین سفارش</h4>
                       <h4 style={{ fontWeight:'normal',marginRight:'10px',color:'#9a9ea3',margin:'10px 10px 0px 0px' }}>سفارش بالای 300هزار تومان</h4>

                   </div>

                   <div className={classes.categories}>
                       <Typography variant="h6">دسته بندی نتایج</Typography>
                       <Divider orientation="horizontal"/>
                      <span className={classes.listHead}><ChevronLeftIcon className={classes.leftArrow}/><Typography variant="body2">کالاهای سوپر مارکتی</Typography></span>
                      <ul className={classes.ulList}>
                          <a className={classes.listHead}><ExpandMoreIcon className={classes.leftArrow}/><Typography variant="body2">کالاهای اساسی و خوار وبار</Typography></a>
                          <li className={classnames(classes.listHead,classes.listItem)}><Typography variant="body2">نان</Typography></li>
                          <li className={classnames(classes.listHead,classes.listItem)}><Typography variant="body2">نان</Typography></li>
                          <li className={classnames(classes.listHead,classes.listItem)}><Typography variant="body2">نان</Typography></li>
                          <li className={classnames(classes.listHead,classes.listItem)}><Typography variant="body2">نان</Typography></li>
                          <li className={classnames(classes.listHead,classes.listItem)}><Typography variant="body2">نان</Typography></li>
                          <li className={classnames(classes.listHead,classes.listItem)}><Typography variant="body2">نان</Typography></li>
                          <li className={classnames(classes.listHead,classes.listItem)}><Typography variant="body2">نان</Typography></li>
                      </ul>
                      <Divider orientation="horizontal"/>

                      <span style={{justifyContent:'center',display:'flex',alignItems: 'center',color:'#5d5d5d',margin:'10px 0px' }}> مشاهده همه دسته بندی ها<DoubleArrowIcon style={{transform:'rotate(90deg)',fontSize:'10px',marginRight:'10px'}}/></span>
                   </div>

                   <div className={classes.searchBar}>
                       <Typography variant="h6" style={{ marginBottom:'5px' }}>جستجو در نتایج :</Typography>
                       <Divider orientation="horizontal"/>
                       <span className={classnames(classes.searchBox,'searchBox')}><SearchOutlined/><input type="text" className={classnames(classes.searchInput,'searchInput')}/></span>
                   </div>

                   <div className={classnames(classes.brandBar,'brand')}>
                       <span className={classnames(classes.acc,'acc')}>
                           
                           <Typography variant="body1">برند</Typography>
                           <ExpandMoreIcon className="expand"/>
                       </span>
                       <div className={classnames(classes.brnadBox,'brandBox')}>
                       <Divider orientation="horizontal"/>
                       <ul className={classes.checkList}>
                           <li className={classes.checkItem}>
                              <span><input type="checkbox" className={classes.checkBox}/> <span>سه نان</span></span>
                              <span style={{ color:'#ababab' }}>cenan</span>
                           </li>
                           <li className={classes.checkItem}>
                              <span><input type="checkbox" className={classes.checkBox}/> <span>سه نان</span></span>
                              <span style={{ color:'#ababab' }}>cenan</span>
                           </li>
                           <li className={classes.checkItem}>
                              <span><input type="checkbox" className={classes.checkBox}/> <span>سه نان</span></span>
                              <span style={{ color:'#ababab' }}>cenan</span>
                           </li>
                           
                       </ul>
                       </div>
                   </div>

                   <div className={classes.switchBox}>
                       <span><Switch checked={checkA}/></span>
                       <span>فقط کالاهای دیجی پلاس</span>
                   </div>
                   <div className={classes.switchBox}>
                       <span><Switch checked={checkA}/></span>
                       <span>  فقط کالاهای موجود</span>
                   </div>
                   <div className={classes.switchBox}>
                       <span><Switch checked={checkA}/></span>
                       <span>امکان ارسال فوری</span>
                   </div>


                   </div>
    )
}
