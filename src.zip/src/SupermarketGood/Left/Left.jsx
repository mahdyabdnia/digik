import React,{useEffect} from 'react'
import useStyles from './styles'
import SortIcon from '@material-ui/icons/Sort';
import GoodItem from '../GoodItem/GoodItem'
import classnames from 'classnames'
import './style.css'
import { DockTwoTone } from '@material-ui/icons';
export default function Left() {
    useEffect(() => {
        var numItem=document.getElementsByClassName('numIt');
        var i;
        for(i=0;i<numItem.length;i++){
            numItem[i].addEventListener('click',function(){
                var j;
                var allIt=document.getElementsByClassName('numIt');
                for(j=0;j<allIt.length;j++){
                    allIt[j].classList.remove('numSe');
                    allIt[j].classList.add('num');

                }
                this.classList.add('numSe')
            })
          
        }
        return () => {
            
        }
    }, [])
    const classes=useStyles();
    return (
        <div className={classes.left}>
            <div className={classes.sortBox}>
                <span><SortIcon/></span>
                <span style={{ marginRight:'10px' }}>مرتب سازی براساس</span>
            </div>

            <div className={classes.itemBox}>
                <GoodItem/>
                <GoodItem/><GoodItem/><GoodItem/><GoodItem/><GoodItem/><GoodItem/>
            </div>
            <div className={classes.sortPage}>
                <span className={classnames('numIt','numSe')}>
                2
                </span>
                <span className={classnames('num','numIt')}>
                2
                </span>
                <span className={classnames('num','numIt')}>
                2
                </span>
                <span className={classnames('num','numIt')}>
                2
                </span>
            </div>
        </div>
    ) 
}
