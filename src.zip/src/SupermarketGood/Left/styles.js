import { makeStyles } from "@material-ui/core";

const useStyles=makeStyles({

    left:{
        display:'flex',
        flexDirection:'column',
        position: 'absolute',
        width:'79.5%',
        left:'10px',
        top:'-20px',
        backgroundColor:'white'
    },
    sortBox:{
        display:'flex',
        flexDirection:'row',
        alignItems: 'center',
        padding:'10px 20px',
        borderBottom:'1px #edebeb solid',
        
    },
    itemBox:{
        display:'flex',
        flexDirection:'row',
        flexWrap:'wrap',
        borderBottom:'1px solid #f2f2f2'
    },
    sortPage:{
        display:'flex',
        flexDirection:'row',
        justifyContent:'center',
        alignItems: 'center',
        height:'50px',
        position:'relative'
    }
});

export default useStyles;