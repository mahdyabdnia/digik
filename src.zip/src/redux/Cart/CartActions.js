import {CART} from './CartTypes'
export const addToCart=()=>{
    return{
        type:CART
    }
}