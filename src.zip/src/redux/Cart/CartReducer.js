import {CART} from './CartTypes'
const intilaState={
    cartnum:0
}

const CartReducer=(state=intilaState,action)=>{
switch (action.type) {
    case CART:return{
        ...state,cartnum:state.cartnum+1
    }
        
       

    default:
        return state;
}
}

export default CartReducer;