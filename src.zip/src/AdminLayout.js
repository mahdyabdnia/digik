import React from 'react'
import AdminNav from './Admin/AdminNav/AdminNav'



export default function AdminLayout(props) {
   
    return (
        <div dir="rtl" style={{ display:'flex',flexDirection:'row' }}>
            <div style={{ width:"20%",marginTop:'-15px' }}><AdminNav/></div>
            <div style={{ width:"80%" }}>

                {props.children} 
            </div>
            
        </div>
    )
}
