import {makeStyles }from '@material-ui/core'
const useStyles =makeStyles({
  
    contianer:{
display:'flex',
flexDirection:'column'
    },
    searchBar:{
     marginTop:'10px',
     display:'flex',
     flexDirection:'column',
     backgroundColor:'white',
     border:'1px solid #eaeaea ',
     borderRadius:'5px'
    }, 
    searchInput:{
        border:'none',
        height:'38px',
        width:'85%',
        textAlign:'center',
        color:'#b8b8b8',
        backgroundColor:'#f8f8f8'
    },
   searchBlock:{
       alignItems:'center',
       margin: '10px auto 10px auto',
       borderRadius:'5px',
       backgroundColor:'#f8f8f8',
       width:'90%'
   }
    ,
  
    brandBar:{
    borderRadius:'5px',
    marginTop:'10px',
    backgroundColor:'white',
    height:'auto',
    minHeight:'40px',
    maxHeight:'430px',
    width:'100%',
    display:'flex',
    flexDirection:'column',
    direction:'rtl',
    transition:'3s'

    },
brandHeader:{
    display:'flex',
    flexDirection:'row',
    height:'40px',
    alignItems:'center',
    justifyContent:'space-between',
    padding:'0px 10px',
    borderBottom:'1px solid #ebebeb',
    cursor:'pointer'
    
},
brandBody:{
display:'none',
flexDirection:'column',
height:'auto',
minHeight:'0px',
maxHeight:'390px',


},

brandSearch:{
    display:'block',
    height:'38px',
    border:'none',
    outline:'none',
    width:'100%',
    '&:focus':{
        outline:'none'
    }


},
brandSearchBar:{
borderRadius:'5px',
border:'solid 1px #1fc7db',
margin:'10px auto 10px auto',
width:'90%',
height:'content',
paddingLeft:'5px',
display:'flex',
alignItems:'center',

},
brands:{
    overflowY:'scroll',
    overflowX:'hidden',
    height:'100%',
    display:'flex',
    flexDirection:'column'
   
},
brand:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between',
    padding:'10px 10px'
}
,
    
    filterCategory:{
     
        backgroundColor:'white',
        borderRadius:'5px',
        
        display:'flex',
        flexDirection:'column',
        
        height:'auto',
        marginBottom:'20px',
        padding:'10px'
  
  
       
      },

      filtersUl:{
          listStyleType:'none',
          padding:'0px'
      },
      filtersLink:{
     color:'black',
     textDecoration:'none',
     '&:hover':{
         color:'#00bfd6',
         textDecoration:'none'
     }
      },

      filtersSpan:{
    display:'flex',
    alignItems:'center',
    fontSize:'15px'
      },
      iconf:{
        fontSize:'20px'
      },
      filterLi:{
          cursor:'pointer',
     marginRight:'40px',
     color:'#898989 ',
     '&:hover':{
        color:'#00bfd6',
        textDecoration:'none'
    }
      },

      middleItems:{
        display:'flex',
        flexDirection:'row',
        flexWrap:'wrap',
        backgroundColor:'white'
    },
    brandSlider:{
        display:'flex ',
        
        
        flexDirection:'column',

    } 
    ,
    brandList:{
        display:'flex',
        flexDirection:'column',
        maxHeight:'350px',
        height:'auto',
        overflowY:'scroll'
    },
    brandListItem:{
        display:'flex',
        flexDirection:'row',
        flexWrap:'wrap',
        height:'45px !important'
    },
    brandDiv1:{
     width:'50%',
     display:'flex',
        flexDirection:'row'
    },
    brandDiv2:{
        width:'50%',
        
       },
    digiPluse:{
        border:'1px #eaeaea solid',
        borderRadius:'5px',
        display:'flex',
        backgroundColor:'white',
        marginTop:'10px',
        height:'10%'
    },
    hcontainer:{
        width:'96%',
        margin:'auto',
        height:'auto',
        minHeight:'205px',
        marginTop:'20px',
        backgroundColor:'white',
        padding:'10px 20px 20px 20px ',
        borderRadius:'10px',
        direction:'rtl',
        display:'flex',
        flexDirection:'column',

    },
    catDiv:{
        display:'flex',
        flexDirection:'row',
        flexWrap:'wrap'
        
        
    },
    catBox:{
        display:'flex',
        flexDirection:'column',
        justifyContent:'center',
        padding:'10px 5px 10px 5px ',
        margin:'10px 10px 0 0',
        textAlign:'center',
        height:'150px',
        width:'165px',
        backgroundColor:'#f0f0f1',
        borderRadius:'10px',
        cursor:'pointer'
    },
    catBox2:{
        display:'flex',
        flexDirection:'column',
        justifyContent:'center',
        padding:'10px 5px 10px 5px ',
        margin:'10px -20px 0 0',
        textAlign:'center',
        height:'150px',
        width:'165px',
        backgroundColor:'#f0f0f1',
        borderRadius:'10px',
        cursor:'pointer'
    },
    catBox3:{
        display:'flex',
        flexDirection:'column',
        justifyContent:'center',
        padding:'10px 5px 10px 5px ',
        margin:'10px 10px 0 0',
        textAlign:'center',
        height:'130px',
        width:'160px',
        backgroundColor:'#f0f0f1',
        borderRadius:'10px',
        cursor:'pointer'
    },
    catBoxImg:{
        display:'flex',
        margin:'auto',
        width:'60px',
        height:'60px',
    },
    sortBox:{
        width:'100%',
        height:'50px',
        backgroundColor:'white',
        display:'flex',
        flexDirection:'row',
        alignItems:'center',
        paddingRight:'10px'
    },
    sortIcon:{
        opacity:'0.2'
    },
    sortLink:{
        borderRadius:'6px',
        backgroundColor:'#00bfd6',
        color:'white',
        marginRight:'20px',
        padding:'2px 5px',
        cursor:'pointer'
    }, 
    sortLinkTwo:{
        borderRadius:'6px',
        backgroundColor:'white',
        color:'#637586',
        marginRight:'5px',
        marginLeft:'5px',
        padding:'2px 10px',
        cursor:'pointer',
        '&:hover':{
            backgroundColor:'#f0f0f1'
        }
    },
    sellersBar:{
        borderRadius:'5px',
        width:'100%',
        backgroundColor:'white',
        marginTop:'20px',
        height:'auto',
        minHeight:'40px',
        display:'flex',
        flexDirection:'column',
        direction:'rtl',
        transition:'3s'
         


    },
    sellersHeader:{
        display:'flex',
        flexDirection:'row',
        borderBottom:'1px solid #f0f0f1',
      
        padding:'0px 10px',
        justifyContent:'space-between',
        height:'40px',
        alignItems:'center',
        cursor:'pointer'
    },
    sellersBody:{
        display:'none',
       height:'auto',
       minHeight:'0px',
       flexDirection:'column',
       padding: '0px 10px',

},
sellers:{
    display:'flex',
    flexDirection:'row',
    padding:'10px 0px',
    alignItems:'center'

},
sort:{
    display:'flex',
    flexDirection:'row',
    direction:'rtl',
    justifyContent:'center',
    alignItems: 'center',
},


});

export default useStyles;