import React,{useEffect} from 'react'
import useStyles from './styles'
import {Grid,Typography,Divider, Drawer}from '@material-ui/core'
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import Link from '@material-ui/core/Link';
import CategoryCard from '../CategoryCard/CategoryCard'
import $ from 'jquery'
import SortIcon from '@material-ui/icons/Sort';
import classnames from 'classnames'
import DoubleArrowIcon from '@material-ui/icons/DoubleArrow';
export default function FilterTwoLeft() {
  const mouseOver=()=>{
    $(document).ready(function(){
    $('.card ').mouseenter(function(){
    $(this).children('.cardSeller').stop(true).css('visibility','visible');
    });
    });
        }

    useEffect(() => {
    var item=document.getElementsByClassName('sortItems');
    var i;
    for(i=0;i<item.length;i++){
      item[i].addEventListener('click',function(){
       var it=document.getElementsByClassName('sortItems');
       var j;
       for(j=0;j<it.length;j++){
         it[j].classList.remove('sortLink');
         it[j].classList.add('sortLinkTwo');
       }
       
       this.classList.add('sortLink');
       this.classList.remove('sortLinkTwo')
      })
    }
    }, []);   
    useEffect(() => {
      var item=document.getElementsByClassName('page');
      var i;
      for(i=0;i<item.length;i++){
        item[i].addEventListener('click',function(){
         var it=document.getElementsByClassName('page');
         var j;
         for(j=0;j<it.length;j++){
          it[j].classList.add('pageNumber');
           it[j].classList.remove('pageActive');
           
         }
         
         this.classList.add('pageActive');
         this.classList.remove('pageNumber')
        })
      }
      }, []);  
    
        const mouseLeaver=()=>{
          $(document).ready(function(){
          $('.card ').mouseleave(function(){
            $(this).children('.cardSeller').stop(true).css('visibility','hidden');
          });
          });
              }

              useEffect(() => {
                mouseOver();
                mouseLeaver();
              }, []);
    const classes=useStyles();
    return (
        <React.Fragment>
           <Grid item  style={{ marginBottom:'10px' }}>
           <Breadcrumbs dir="rtl" aria-label="breadcrumb">
      <Link color="inherit" href="/" >
       فروشگاه اینترنتی دی جی کالا
      </Link>
      <Link color="inherit" href="/getting-started/installation/" >
        کالای دیجیتال
      </Link>
     
    </Breadcrumbs>
           </Grid>


 
            <div className={classes.sortBox}>
             <span><SortIcon/></span>
             <span>مرتب سازی براساس:</span>
             <span className={classnames('sortLink','sortItems')}>پربازدید ترین</span>
             <span className={classnames('sortLinkTwo','sortItems')}>  محبوب ترین  </span>
             <span className={classnames('sortLinkTwo','sortItems')}>  پر فروش ترین </span>
             <span className={classnames('sortLinkTwo','sortItems')}>  ارزان ترین </span>
             <span className={classnames('sortLinkTwo','sortItems')}>  گران ترین  </span>
             <span className={classnames('sortLinkTwo','sortItems')}>  جدید ترین  </span>

            </div>
           <Grid item container className={classes.middleItems}> 
           
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/> <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           </Grid>
           <div className={classnames(classes.sortBox,classes.sort)} style={{ marginBottom:"10px",borderTop:"1px solid #efefef" }}>
             <span><DoubleArrowIcon style={{fontSize:'15px',opacity:'0.4'}}/></span>
             <line style={{  }} className="line"></line>
             <span className={classnames('pageActive','page')}>1</span>
             <span className={classnames('pageNumber','page')}>2</span>
             <span className={classnames('pageNumber','page')}>3</span>
             <span className={classnames('pageNumber','page')}>4</span>
             <line style={{  }} className="line"></line>
             <span><DoubleArrowIcon style={{transform:'scaleX(-1)',fontSize:'15px',opacity:'0.4'}}/></span>

            </div>
           </React.Fragment>
    )
}
