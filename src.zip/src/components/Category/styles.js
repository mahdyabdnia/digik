import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({

    container:{
        
       width:"auto",
        backgroundColor:'#ebebeb',
       
    },
    top:{
        marginTop:'20px',
        backgroundColor:'white',
        height:'205px',
     
        borderRadius:'5px',
        display:'flex',
        flexDirection:'column',
        flexWrap:'wrap'


    },
    middle:{
        marginTop:'20px',
        
        display:'flex',
        flexDirection:'row-reverse',
        flex:'1',

    }, 
    middleSpace:{
        width:'1%'
    }
    ,
    middleRight:{
     width:"18%",
     height:'auto',
   position:'sticky',
     display:'flex',
     flexDirection:'column'
    },
   
    middleLeft:{
    width:"79%"
    },
   
});
export default useStyles;