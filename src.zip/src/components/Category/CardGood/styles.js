import {makeStyles} from '@material-ui/core'

const useStyles=makeStyles({

    container:{
        padding:'5px 15px 16px',
        height:'306px',
        width:'192px',
        display:'flex',
        flexDirection:'column',
        margin:'auto 5px',

        '&:hover':{
            boxShadow:'0 0 10px rgba(188, 247, 198, 1)'
        },

    },
    divImg:{
        height:'50%'
    },
    img:{
        display:'block',
        width:'170px',
        height:'170px',
        margin:'auto'
    }
    ,
    divPrice:{
        height:'25%',
        direction:'ltr',
        textAlign:'left',
        display:'flex',
        flexDirection:'row',
        alignItems:'center'
    },
    divName:{
        height:'25%',
        direction:'rtl',
        textAlign:'right',
        display:'flex',
        flexDirection:'row',
        alignItems:'center'

    },
    name:{
        color:'#535353'
    }







});

export default useStyles;