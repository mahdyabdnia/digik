import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'

 
export default function CardGood({src,name,price}) {
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <div className={classes.divImg}>
                <img src={src} alt=""  className={classes.img} />
            </div>
            <div className={classes.divName}>
                <Typography variant="body1" className={classes.name}>{name}</Typography>
            </div>
            <div className={classes.divPrice}>
             <Typography variant="body1" color="initial">{price}</Typography>
            </div>
            
        </div>
    )
}
