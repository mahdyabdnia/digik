import React from 'react'
import useStyles from './styles'
import {Grid,Typography,Divider,List,ListItem,ListItemText} from '@material-ui/core'
import {Link } from 'react-router-dom'
export default function FilterOneRight({tab,set}) {

   const setTab=(ta)=>{
      set(ta);
   }  
  
    const classes=useStyles();
    return (
        <div className={classes.containerl}>
          <Typography variant="body1" color="initial" className={classes.hSix}> دسته بندی  کالاها</Typography>
          <Divider  orientation="horizontal" style={{ width:'96%',margin:'auto' }}/>
         
          <div className={classes.catList}>
          <ul className={classes.catUl}>
             <Link to="/categorytwo"  className={classes.catLink}>موبایل</Link>
             <li className={classes.catListItem}>گوشی موبایل</li>
          </ul>
          <ul className={classes.catUl}>
             <a className={classes.catLink}> تبلت و کتاب خوان </a>
             <li className={classes.catListItem}>  تبلت   </li>
             <li className={classes.catListItem}>  کتاب خوان و کاغذ دیجیتالی  </li>
             <li className={classes.catListItem}>  ردیاب ماهواره ای   </li>
          </ul>
          <ul className={classes.catUl}>
             <a className={classes.catLink}> تبلت و کتاب خوان </a>
             <li className={classes.catListItem}>  تبلت   </li>
             <li className={classes.catListItem}>  کتاب خوان و کاغذ دیجیتالی  </li>
             <li className={classes.catListItem}>  ردیاب ماهواره ای   </li>
          </ul>

          <ul className={classes.catUl}>
             <a className={classes.catLink}> تبلت و کتاب خوان </a>
             <li className={classes.catListItem}>  تبلت   </li>
             <li className={classes.catListItem}>  کتاب خوان و کاغذ دیجیتالی  </li>
             <li className={classes.catListItem}>  ردیاب ماهواره ای   </li>
          </ul>

          </div>

        </div>
     

    )
}

