import React,{useEffect,useState,useRef} from 'react'
import {Grid,Typography,Divider,List,ListItem,ListItemText,Tab,Tabs,Button, Link} from '@material-ui/core'
import useStyles from './styles';
import ImageGallery from 'react-image-gallery'
import Carousel from 'react-elastic-carousel';
import './style.css'
import CardGood from '../CardGood/CardGood'
import $ from 'jquery'

import  classnames  from 'classnames';
 
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight'


export default function FilterOneLeft() {
  const TABS=[{val:0,lable:'تلویزیون'},{val:1,lable:'رادیو'},{val:2,lable:'لپ تاپ'},{val:3,lable:'کامپیوتر'},{val:4,lable:'گوشی کامپیوتر'},]
  const [value, setValue] =React.useState(TABS[1].val);
  const tt=TABS[0].val
  const handleChange=(event,newValue)=>{
    setValue(newValue);
    console.log(value);
  }

  let car1 = useRef()
  let  car2= useRef()
  let  car3= useRef()
  
  var slideIndexV2=1;
  function plusSlides(n) {
    showSlidesV2(slideIndexV2 += n);
  }
  
  function currentSlide(n) {
    showSlidesV2(slideIndexV2 = n);
  }

  function showSlidesV2(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    if (n > slides.length) {slideIndexV2 = 1}    
    if (n < 1) {slideIndexV2 = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndexV2-1].style.display = "block";  
    dots[slideIndexV2-1].className += " active";
  }

  useEffect(() => {
    showSlidesV2(slideIndexV2);
  }, []);
  useEffect(() => {
    var slideIndex = 0;
    const showSlide=setInterval(function(){
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";  
        }
        slideIndex++;
        if (slideIndex > slides.length) {slideIndex = 1}    
        for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }
        if(typeof(slideIndex)!=="undefined"){
        slides[slideIndex-1].style.display = "block";  }
        dots[slideIndex-1].className += " active";

    },5000)
     return () => {
         clearInterval(showSlide)
     }
 }, [])

  const over=()=>{
   $(document).ready(function(){
     $('.rec-arrow').mouseleave(function(){
       $(this).css({backgroundColor:'white !important',color:'black !important'})
     })
   })
  }
  
 
   
  const sgodd=[
    {id:0,src:'images/s1.jpg',price:'25000',name:'لپ تاپ 14 اینچی ایسوس مدل VivoBook R465EP-EB219  '},
    {id:1,src:'images/s2.jpg',price:'25000',name:'باتری قلمی و نیم قلمی کملیون مدل Plus Alkaline مجموعه 12 عددی '},
    {id:2,src:'images/s3.jpg',price:'25000',name:'هدفون بی سیم کینگ استار مدل KBH30'},
    {id:3,src:'images/s4.jpg',price:'25000',name:'چندراهی برق کلومن پلاس مدل KS-3 '},
    {id:4,src:'images/s5.jpg',price:'25000',name:' لپ تاپ 14 اینچی لنوو مدل IdeaPad 5 14ALC05 - A'},
  
  ]
    const classes=useStyles();
    const goods=[{src:'images/laptop (1).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (2).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (3).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (4).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (5).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (6).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (7).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (8).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (9).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},
    {src:'images/laptop (10).jpg',name:'لپ تاپ 15 اینچی ایسر مدل ideapad-320', price:'12,000,000 تومان'},

  
  ]
    const images = [
        {
          original: 'images/tt.jpg',
         
        },
        {
          original: 'images/tt.jpg',
          
        },
        {
          original: 'images/tt.jpg',
         
        },
      ];
      const [gindex, setgindex] = useState(0)
      useEffect(() => {
        var goodIndex=0;
        const showborder=setInterval(function(){
          var i;
          var good=document.getElementsByClassName('tabsitems');
          goodIndex++;
          if(goodIndex>good.length){goodIndex=1}
          setgindex(goodIndex-1); 
        },8000)
        
        return () => {
         clearInterval(showborder);
        }
      }, [])

    return (
      <Grid container className={classes.container2}>
          <Grid item container className={classes.bannerGrid}>
           <div className={classnames('mySlides')}>
             <img src="images/bannerGrid.jpg" className={classnames(classes.imgG)} alt="" />
           </div>
           <div className={classnames('mySlides')}>
             <img src="images/bannerGrid2.jpg" className={classnames(classes.imgG)} alt="" />
             </div>
             <div className={classnames('mySlides')}>
             <img src="images/bannerGrid3.jpg" className={classnames(classes.imgG)} alt="" />
           </div>
           
           <a className="prev" onClick={()=>{plusSlides(-1)}}> &#10095; </a>
<a className="next" onClick={()=>{plusSlides(1)}}> &#10094; </a>
            <div className="dotBox">
  <span className="dot" onClick={()=>{currentSlide(1)}}></span> 
  <span className="dot" onClick={()=>{currentSlide(2)}}></span> 
  <span className="dot" onClick={()=>{currentSlide(3)}}></span>
         </div>
          </Grid>

          <div className={classes.sliderTab}>

            <div className={classes.sliderHead}> 
            <img src="images/offer.svg" alt="" className={classes.offerLogo}/>
            <Link className={classes.p}> نمایش همه</Link>
            
            
            
             
            </div>
            <div className={classes.sliderBody}> 
            {sgodd.map((item,index)=>{
              return(<>
              {gindex===index &&
              <div className={classes.sliderTabItems}>
              <div ><img src={item.src} className={classes.itemsImage}/></div>
              <div style={{ display:'flex',flexDirection:'column',width:'100%' }}>
                <div style={{ display:'flex',flexDirection:"column",height:'70%' }}><Typography variant="h6" color="initial">{item.name}  </Typography>
                <ul style={{ listStyleType:'disc' }}>
                  <li>دو سیم کارته </li>
                  <li>دوربین 15 مگا پیکسل</li>
                </ul></div>
                <div style={{ display:'flex',flexDirection:"column",height:'30%',direction:'ltr',marginLeft:'40px'  }}>
                 <div><span style={{ backgroundColor:'#fb3449',color:'white',borderRadius:'20px',padding:'3px 8px 3px 8px' }}>15%</span> 
                 <span style={{ textDecoration:'line-through',opacity:'0.5',marginLeft:'10px' }}>150000</span></div>
                  <Typography variant="h6" color="initial">{item.price} تومان</Typography>
              <Button variant="contained" style={{ backgroundColor:'#fb3449',color:'white',display:'block',width:'200px',height:'67px' }}>افزودن به سبد خرید</Button>
                </div>
                
              </div>
               </div>
              
              }
              {gindex!==index &&
              <></>
              }
              
              
              
              
              </>)
            })}
            
            <div className={classes.sliderTabs}>

              {sgodd.map((item)=>{
                return( <div className={classnames(classes.tabsitems,'tabsitems')}>
                  <img src={item.src} alt=""  className={classes.tabsImage}/>
                  <span> {item.name}  </span>
                </div>)
              })}
           
            
            
            
             </div>

            
            
            </div>
          </div> 

         
          <div className={classes.banerTime}>
               <div className={classes.banerItem}>
                 <img src="images/brr.jpg" className={classes.banerImg} />
               </div>
               <div className={classes.banerItem}>
                 <img src="images/brrr.jpg" className={classes.banerImg} />
               </div>
               <div className={classes.banerItem}>
                 <img src="images/brrrr.jpg" className={classes.banerImg} />
               </div>
               <div className={classes.banerItem}>
                 <img src="images/brr.jpg" className={classes.banerImg} />
               </div>


             </div>
            

             <div className={classes.carousel}>
              <div className={classes.carouselHeader}>
               <div className={classes.carouselHeaderRight}> 
                <Typography variant="h6" color="initial">لپتاپ های زیر 16 میلیون</Typography>
               </div>
               <div className={classes.break}></div>
               <div className={classes.carouselHeaderLeft}>
                 <Link className={classes.carouselHeaderLeftLink}> <Typography variant="h6" color="initial">مشاهده همه </Typography>   </Link>
               </div>

              </div>

              <div className={classes.carouselBody}>
              <Carousel itemsToShow={5} ref={ref=>{car1=ref}} showArrows={false}>
               {goods.map((item)=>{
                 return(<CardGood src={item.src} price={item.price} name={item.name}/>)
               })}






              </Carousel>
              <span className={classes.leftArrow} onClick={()=>{car1.slidePrev()}}><ChevronLeftIcon className={classes.icon}/></span>
              <span className={classes.rightArrow} onClick={()=>{car1.slideNext()}}><ChevronRightIcon className={classes.icon}/></span>

              </div>








            </div>


            <div className={classes.carousel}>
              <div className={classes.carouselHeader}>
               <div className={classes.carouselHeaderRight}> 
                <Typography variant="h6" color="initial">   لپ تاپ های مالتی مدیا  </Typography>
               </div>
               <div className={classes.break}></div>
               <div className={classes.carouselHeaderLeft}>
                 <Link className={classes.carouselHeaderLeftLink}> <Typography variant="h6" color="initial">مشاهده همه </Typography>   </Link>
               </div>

              </div>

              <div className={classes.carouselBody}>
              <Carousel itemsToShow={5} showArrows={false} ref={ref=>{car2=ref}}>
               {goods.map((item)=>{
                 return(<CardGood src={item.src} price={item.price} name={item.name}/>)
               })}


              </Carousel>
              <span className={classes.leftArrow} onClick={()=>{car2.slidePrev()}}><ChevronLeftIcon className={classes.icon}/></span>
              <span className={classes.rightArrow} onClick={()=>{car2.slideNext()}}><ChevronRightIcon className={classes.icon}/></span>

              </div>

            </div> 

          <Grid item container style={{ marginTop:'20px' }} spacing={2}>
           <Grid item xs={6}><img src="images/tt.jpg"className={classes.imgBrand}  />  </Grid>
           <Grid item xs={6}><img src="images/tt.jpg"className={classes.imgBrand}  />  </Grid>
           <Grid item xs={6}><img src="images/tt.jpg"className={classes.imgBrand}  />  </Grid>
           <Grid item xs={6}><img src="images/tt.jpg"className={classes.imgBrand}  />  </Grid>

          </Grid>

          <div style={{ marginBottom:"40px" }} className={classes.carousel}>
              <div className={classes.carouselHeader}>
               <div className={classes.carouselHeaderRight}> 
                <Typography variant="h6" color="initial">   لپ تاپ های مالتی مدیا  </Typography>
               </div>
               <div className={classes.break}></div>
               <div className={classes.carouselHeaderLeft}>
                 <Link className={classes.carouselHeaderLeftLink}> <Typography variant="h6" color="initial">مشاهده همه </Typography>   </Link>
               </div>

              </div>

              <div className={classes.carouselBody}>
              <Carousel itemsToShow={5} showArrows={false} ref={ref=>{car3=ref}}>
               {goods.map((item)=>{
                 return(<CardGood src={item.src} price={item.price} name={item.name}/>)
               })}


              </Carousel>

              <span className={classes.leftArrow} onClick={()=>{car3.slidePrev()}}><ChevronLeftIcon className={classes.icon}/></span>
              <span className={classes.rightArrow} onClick={()=>{car3.slideNext()}}><ChevronRightIcon className={classes.icon}/></span>


              </div>

            </div> 
         

        
      </Grid> 
    )
}



