import {makeStyles } from '@material-ui/core'
const useStyles=makeStyles({
  container:{
      display:'flex',
      flexDirection:'column',
      backgroundColor:'white',
      borderRadius:'5px'

  },  

  container2:{
      display:'flex',
      flexDirection:'column'
  },
  bannerGrid:{
width:'100%',
height:'329px',
position:'relative',
display:'flex'
  },

  innerListItem:{
display:'flex',
flexDirection:'column'
  },
  innerGrid:{
      textAlign:'right'
  },
  
  tabs:{
    backgroundColor:'white',
    height:'308px',
    marginTop:'10px',
    display:'flex',
    flexDirection:'row-reverse',
    flexWrap:'wrap',
    borderTop:'red solid 3px'
  },
  innerTabs:{

    width:'98%',
    padding:'auto',
    display:'flex',
    flexDirection:'row-reverse'
  },
  tab1:{
    flexGrow:'2',
    width:'auto',
    alignItems:'center'
    
  },
  tab1Tab:{
display:'flex',
flexDirection:'column'
  },
  tab2:{
    flexGrow:'6',
    width:'auto'
  },
  slider1:{
    height:'auto',
    width:'100%',
    backgroundColor:'white',
    borderRadius:'1px solid #eaeaea',
    marginTop:'10px',
    
  }
  ,
  imgBrand:{
    maxWidth:'100%',
    maxHeight:'100%',
    borderRadius:'20px'
  }
  ,
  sliderTab:{
    width:'100%',
    height:'400px',
    backgroundColor:'white',
    marginTop:'20px',
    display:'flex',
    flexDirection:'column',
    borderTop:'2px solid #ef394e'
  },
  sliderHead:{
    height:"12.5%",
    display:'flex',
    flexDirection:'row',
    direction:'rtl',
    justifyContent:'space-between'
  },
  p:{
    display:'inline',
    textDecoration:'none',
    opacity:'0.5',
    color:'black',
    marginTop:'20px',
    marginLeft:'40px',
    cursor:'pointer'
    ,
    '&:hover':{
      textDecoration:'none'
    }
  },
  offerLogo:{
    marginRight:"80px"
  }
  ,
  sliderBody:{
    height:'87.5%',
    display:'flex',
    flexDirection:'row',
    direction:'rtl',
    paddingRight:'80px',
    paddingLeft:'40px',
    paddingBottom:'40px'

  },
  sliderTabs:{
    width:'35%',
    borderRight:'1px solid #f9f9f9',
    display:'flex',
    flexDirection:'column',

  },
  tabsitems:{
  height:'20%',
  display:'flex',
  flexDirection:'row',
  direction:'rtl',
 cursor:'pointer',
  alignItems:"center"

  },
  tabsImage:{
    display:'block',
  width:'40px',
  height:'40px',
  marginRight:'20px'
  },
  
  sliderTabItems:{
    width:'65%',
    display:'flex',
    flexDirection:'row'
  },
  itemsImage:{
    display:'block',
    margin:'auto',
    width:'276px',
    height:'250px',
    marginTop:'40px'
  },
  banerTime:{
display:'flex',
flexDirection:'row',
marginTop:'20px'
  },
  banerItem:{ 
  width:'23.5%',
  margin:'auto'
  },
  banerImg:{
   borderRadius:'16px',
   width:'100%',
   height:'100%',
   cursor:'pointer'
  }

  ,
  carousel:{
    width:'100%',
    height:'420px',
    borderRadius:'10px',
    backgroundColor:'white',
    display:'flex',
    flexDirection:'column',
    marginTop:'20px',
    paddingBottom:'10px'

  },
  carouselHeader:{
    display:'flex',
    flexDirection:'row',
    padding:'0px 30px',
    direction:'rtl',
    height:'55px',
    
    

  },
  carouselBody:{
    height:'321px',
    display:'flex',
    
    justifyContent:'center',
    padding:'20px 0px',
    position:'relative',
    zIndex:'1'
  }
  ,
  icon:{
  fontWeight:'bold',
  fontSize:'30px'
  },
  rightArrow:{
    position:'absolute',
    padding:'30px 12px',
    right:'0px',
    top:'35%',
    borderLeft:'1px solid #b2b2b2',
    borderBottom:'1px solid #b2b2b2',
    borderTop:'1px solid #b2b2b2',
    zIndex:'10000',
    borderTopLeftRadius:'5px',
    borderBottomLeftRadius:'5px',
    backgroundColor:'white'
  },
  leftArrow:{
  position:'absolute',
  padding:'30px 12px',
  left:'0px',
  top:'35%',
  borderRight:'1px solid #b2b2b2',
    borderBottom:'1px solid #b2b2b2',
    borderTop:'1px solid #b2b2b2',
  zIndex:'10000',
  borderTopRightRadius:'5px',
  borderBottomRightRadius:'5px',
  backgroundColor:'white'
  },
  carouselHeaderRight:{
    width:'20%',
    borderBottom:'2px solid #f16b74 ',
    textAlign:'right',
    display:'flex',
    alignItems:'center',
    justifyContent:'space-around'
  },
  break:{
    width:'2%'
  }
  ,
  carouselHeaderLeft:{
    width:'78%',
    
    borderBottom:'2px solid #aeb0af',
    textAlign:'left',
    display:'flex',
    alignItems:'center',
    direction:'ltr',
    justifySelf:'left'
  },
  carouselHeaderLeftLink:{
    textAlign:'left',
    color:'#ababab',
    textDecoration:'none',
    cursor:'pointer',

    '&:hover':{
      color:'#009ee6',
      textDecoration:'none'
    }
  },
  containerl:{
    display:'flex',
    flexDirection:'column',
    borderRadius:'5px',
    backgroundColor:'white',
    height:'auto',
    direction:'rtl',
    textAlign:'right',
    paddingBottom:'40px',
   


  },
  hSix:{
   
    margin: '10px 10px 10px auto',
  },
  catList:{
    display:'flex',
    flexDirection:'column',
    direction:'rtl',
    textAlign:'right',
    paddingRight:'20px',
    paddingLeft:'20px'

  },
  catUl:{
    borderBottom:'1px solid #ededed',
    display:'flex',
    flexDirection:'column',
    justifyContent:'flex-start',
    listStyleType:'none',
    paddingRight:'0px !important',
    
    paddingBottom:'10px',
    marginBottom:'-10px'
  },
  catLink:{
    cursor:'pointer',
    fontSize:'16px',
    textDecoration:'none',
    color:'black',
    '&:hover':{
      textDecoration:'none',
      color:'black',

    }  
  },
  catListItem:{  
  cursor:'pointer',
  color:'#7e7e7e',
  fontSize:'15px',
  lineHeight:'5px',
  '&:hover':{
    textDecoration:'none',
    color:'#18a5f4'
  }

  },

  imgG:{
width:'1200px',
marginLeft:"auto",
marginRight:'auto',
display:'block',
borderRadius:'21px',
height:'329px'
  },
  bannerGridImg:{
    width:'100%',
    height:'100%',
    borderRadius:'25px',
    display:'block',
    margin:'auto'
  },
  

  


});

export default useStyles;