import React,{useEffect} from 'react'
import useStyles from './styles'
import {Grid,Typography,Divider}from '@material-ui/core'
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import Link from '@material-ui/core/Link';
import CategoryCard from '../CategoryCard/CategoryCard'
import $ from 'jquery'
import SortIcon from '@material-ui/icons/Sort';
export default function FilterTwoLeft() {
  const mouseOver=()=>{
    $(document).ready(function(){
    $('.card ').mouseenter(function(){
    $(this).children('.cardSeller').stop(true).css('visibility','visible');
    });
    });
        }
    
        const mouseLeaver=()=>{
          $(document).ready(function(){
          $('.card ').mouseleave(function(){
            $(this).children('.cardSeller').stop(true).css('visibility','hidden');
          });
          });
              }

              useEffect(() => {
                mouseOver();
                mouseLeaver();
              }, []);
    const classes=useStyles();
    return (
        <React.Fragment>
           <Grid item  style={{ marginBottom:'10px' }}>
           <Breadcrumbs dir="rtl" aria-label="breadcrumb">
      <Link color="inherit" href="/" >
       فروشگاه اینترنتی دی جی کالا
      </Link>
      <Link color="inherit" href="/getting-started/installation/" >
        کالای دیجیتال
      </Link>
     
    </Breadcrumbs>
           </Grid>



            <div className={classes.sortBox}>
             <span><SortIcon/></span>
             <span>مرتب سازی براساس:</span>
             <span className={classes.sortLink}>پربازدید ترین</span>
             <span className={classes.sortLinkTwo}>  محبوب ترین  </span>
             <span className={classes.sortLinkTwo}>  پر فروش ترین </span>
             <span className={classes.sortLinkTwo}>  ارزان ترین </span>
             <span className={classes.sortLinkTwo}>  گران ترین  </span>
             <span className={classes.sortLinkTwo}>  جدید ترین  </span>

            </div>
           <Grid item container className={classes.middleItems}> 
           
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/> <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           <CategoryCard/>
           <CategoryCard/>
           
           </Grid>
           <div className={classes.sortBox} style={{ marginBottom:"10px",borderTop:"1px solid #efefef" }}>
             

            </div>
           </React.Fragment>
    )
}
