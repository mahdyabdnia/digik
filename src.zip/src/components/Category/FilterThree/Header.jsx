import React,{useState} from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'

export default function Header() {
    const hedcat=[{name:'گوشی موبایل',src:'images/item5th.jpg'},{name:'گوشی موبایل',src:'images/item5th.jpg'},
    {name:'گوشی موبایل',src:'images/item5th.jpg'},{name:'گوشی موبایل',src:'images/item5th.jpg'},
    {name:'گوشی موبایل',src:'images/item5th.jpg'},{name:'گوشی موبایل',src:'images/item5th.jpg'},
    {name:'گوشی موبایل',src:'images/item5th.jpg'},{name:'گوشی موبایل',src:'images/item5th.jpg'},
    {name:'گوشی موبایل',src:'images/item5th.jpg'},{name:'گوشی موبایل',src:'images/item5th.jpg'},
    {name:'گوشی موبایل',src:'images/item5th.jpg'},{name:'گوشی موبایل',src:'images/item5th.jpg'},
   
   ]
    const classes=useStyles();
    const [state, setstate] = useState(false)
    return (
        <div  className={classes.hcontainer}>
            <Typography variant="h6" color="initial">دسته بندی ها</Typography>
            <div className={classes.catDiv}>
                {state===false && hedcat.length >=7 &&
                <>
                {hedcat.map((item,index)=>{
                    return(<>
                    
                   {index<=6 && <div className={classes.catBox}>
                        <img src={item.src} alt=""  className={classes.catBoxImg}/>
                        <Typography variant="body1"> {item.name} </Typography>
                    </div> }</>)
                })}
                <div className={classes.catBox2} onClick={()=>{setstate(true)}}>
                        <Typography variant="h6" color="initial">+</Typography>
                        <Typography variant="body1"> دسته بندی های دیگر </Typography>
                    </div>
                </>
                }

           {state===false && hedcat.length <=7 &&
                <>
                {hedcat.map((item,index)=>{
                    return(<>
                    
                   {index<=6 && <div className={classes.catBox}>
                        <img src={item.src} alt=""  className={classes.catBoxImg}/>
                        <Typography variant="body1"> {item.name} </Typography>
                    </div> }</>)
                })}
                
                </>
                }

{state===true && 
                <>
                {hedcat.map((item,index)=>{
                    return(
                    
                  <div className={classes.catBox3}>
                        <img src={item.src} alt=""  className={classes.catBoxImg}/>
                        <Typography variant="body1"> {item.name} </Typography>
                    </div> )
                })}
                
                </>
                }
            </div>

            
        </div>
    )
}
