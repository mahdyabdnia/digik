import React,{useEffect,useState} from 'react'
import {Grid,Typography,Divider, TextField,Icon,IconButton,Checkbox,List,ListItem,ListItemText,Switch} from '@material-ui/core'
import useStyles from './styles'
import SearchIcon from '@material-ui/icons/Search';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import $ from 'jquery'
import classnames from 'classnames';
import './style.css'
import Accordion from 'react-collapsy'
import 'react-collapsy/lib/index.css';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowLeftIcon from '@material-ui/icons/KeyboardArrowLeft';
import { SearchOutlined } from '@material-ui/icons';

export default function FilterTwoRight() {
    const [text, setText] = useState();
    const [state, setState] = useState({
        checkedA: true,
        checkedB: true,
    });

    const [switched, setSwitch] = useState({
        switchedA:true,
        switchedB:true,
    });
    const handleSwitch=(event)=>{
        setSwitch({...switched,[event.target.name]:event.target.checked});

    }
    const [search,setSearch]=useState();
    const [icon,setIcon]=useState(false);
    const placeholder="نام محصول یا برند مورد نظر را وارد کنید ";

    const handleText=(e)=>{
        setText(e.target.value);
    }
    const handleSearch=(e)=>{
        setSearch(e.target.value);
    }
    
    const hanleCheck=(event)=>{
        setState({ ...state, [event.target.name]: event.target.checked });
    }
    const dropbrand=()=>{
        $(document).ready(function(){
         $('.hiddenHeader').click(function(){
           
                $('.hiddenBody').css({display:'flex',minHeight:'auto',transition:'1s'});
                $('.arrow').css({transform:'rotate(180deg)',transition:'1s'});
                      
           
            
         })
        });
    }
    const upbrand=()=>{
        $(document).ready(function(){
         $('.hiddenHeader').dblclick(function(){
             
            
                $('.hiddenBody').css({display:'none',minHeight:'0px',transition:'1s'});
                $('.arrow').css({transform:'rotate(360deg)',transition:'1s'});
            
            
         })
        });
    }
    
    
  
   
    useEffect(() => {
        dropbrand();
        upbrand();
    }, []);
    const classes=useStyles();
    return (
        <Grid container className={classes.container}>
        <Grid item container className={classes.filterCategory} >
        <div>
          <Typography variant="body1" style={{ marginRight:'10px',fontSize:'18px',marginBottom:'10px' }}> دسته بندی نتایج</Typography>
        </div>
        <Divider orientation="horizontal"/>
        <ul className={classes.filtersUl}>
        <span className={classes.filtersSpan}><KeyboardArrowLeftIcon className={classes.iconf}/><a href="" className={classes.filtersLink}> کالای دیجیتال</a></span> 
       <li className={classes.filtersSpan}><KeyboardArrowDownIcon className={classes.iconf}/> موبایل</li>
       <li className={ classnames(classes.filtersLink,classes.filtersSpan,classes.filterLi)}>
     گوشی موبایل
       </li>
       <li className={ classnames(classes.filtersLink,classes.filtersSpan,classes.filterLi)}>
     لوازم جانبی موبایل
       </li>

        </ul>
      
       </Grid>

       <Grid item container className={classes.searchBar}>
           
              <Grid item >   <Typography variant="body1" color="initial" style={{ marginRight:'10px',marginTop:'10px',marginBottom:'10px' }}>جستجو در نتایج</Typography></Grid>
              <Divider orientation="horizontal" />
              <Grid item  container direction="row" className={classes.searchBlock} > 
              <Icon>
                  <SearchIcon style={{opacity:'0.5'}}/>
              </Icon>
           <input value={text} placeholder={placeholder} onChange={handleText} className={classnames(classes.searchInput,"searchInput") }/>
            
            
            </Grid>
           

       </Grid>

       <div className={classnames(classes.brandBar,'brandBar')} >  
       <div className={classnames(classes.brandHeader,'hiddenHeader')}>
           <span>برند</span>
           <span><KeyboardArrowDownIcon className={classnames('arrow')}/></span>
           
           </div>
      <div className={classnames(classes.brandBody,'hiddenBody')}>
           <div className={classes.brandSearchBar}>
               <span><SearchOutlined/></span>
               <input type="text" placeholder="جستجوی نام برند"  className={classes.brandSearch}/>
           </div>

           <Divider orientation="horizontal" />

           <div className={classes.brands}>
               <div className={classes.brand}>
               <div style={{ display:'flex', alignItems:'center'}}>
                   <input type="checkbox" />
                   <span style={{ marginRight:'10px' }}>شیائومی</span>
                    </div>
               <div> <span style={{ color:'#adadad' }}>xiaomi</span> </div>
               </div>

               
          
        
          </div>
          
          </div>
           
             </div>



             <div className={classnames(classes.sellersBar,'sellersBar')}>
             <div className={classnames(classes.sellersHeader,'hiddenHeader1')}>
                 <span >فروشنده</span>
                 <span><KeyboardArrowDownIcon/></span>
             </div>
             <div className={classnames(classes.sellersBody,'hiddenBody1')}>
                <div className={classes.sellers}>
                    <input type="checkbox"/>
                    <span style={{ marginRight:'10px' }}>ایران موبایل</span>
                </div>

             </div>



             </div>

       <Grid item container className={classes.digiPluse} alignItems="center">
           <Switch name="switchedA" onChange={handleSwitch} checked={switched.switchedA}  color="primary"/>
           <Typography variant="body1">فقط کالاهای دیجی پلاس</Typography> 





       </Grid>


       <Grid item container className={classes.digiPluse} alignItems="center">
           <Switch name="switchedB" onChange={handleSwitch} checked={switched.switchedB}  color="primary"/>
           <Typography variant="body1">  فقط کالاهای موجود  </Typography> 





       </Grid>

       <div className={classnames(classes.sellersBar,'sellersBar')}>
             <div className={classnames(classes.sellersHeader,'hiddenHeader1')}>
                 <span >فروشنده</span>
                 <span><KeyboardArrowDownIcon/></span>
             </div>
             <div className={classnames(classes.sellersBody,'hiddenBody1')}>
                <div className={classes.sellers}>
                    <input type="checkbox"/>
                    <span style={{ marginRight:'10px' }}>ایران موبایل</span>
                </div>

             </div>



             </div>

      



       </Grid>
    )
}
