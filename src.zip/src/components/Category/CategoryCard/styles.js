import {makeStyles } from '@material-ui/core'
const useStyles=makeStyles({
card:{
    display:'flex',
    flexDirection:'column',
    height:'430px',
    width:'300px',
    border:'solid 0.1px #ededed',
    '&:hover':{
        boxShadow:'0 0 20px rgba(188, 247, 198, 1)'
    }

},
cardMedia:{
    flexGrow:'4'
},
cardImg:{
    maxWidth:'60%',
    maxHeight:'60%',
    display:'block',
    margin:'auto'

},
cardDetail:{
    flexGrow:'3.5',
    display:'flex',
    flexDirection:'column'
},

cardTextItem:{
flex:1,
},
text1:{
paddingRight:'15px !important'
},
cardSeller:{
    flexGrow:'1.5',
    display:'flex',
    visibility:'hidden',
    flexDirection:'row',
    paddingRight:'10px',
    alignItems:'center'
},
sellerName:{
    color:"#363333",
    fontSize:'20px'
},

storeicon:{
fontSize:'25px !important',
color:'#363333'
},
text3:{
    textAlign:'left',
    paddingLeft:'20px'
}


});

export default useStyles;