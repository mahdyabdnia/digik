import React,{useEffect} from 'react'
import {Grid,Typography} from '@material-ui/core'
import useStyles from './styles'
import StoreIcon from '@material-ui/icons/Store';
import classnames from 'classnames'
import $ from 'jquery'
export default function CategoryCard() {
    const classes=useStyles();
  

   

   
    
    return (
      <Grid container className={classnames(classes.card,"card")} >
           <Grid item container className={classes.cardMedia}>
           <img src={'images/pish.jpg'} className={classes.cardImg} />
           </Grid>
           <Grid item container className={classes.cardDetail}>
               
             <Grid item className={classes.cardTextItem}>
             <Typography variant="body2" color="inherit" className={classes.text1}>گوشی سامسونگ glaxy s5</Typography>
             </Grid>
              <Grid item className={classes.cardTextItem}>
                
              </Grid>
              <Grid item dir="rtl" className={classes.cardTextItem}>
                <Typography  variant="h5" color="initial" className={classes.text3}> 29,500 تومان</Typography>
                  </Grid>           
           </Grid>
         <Grid item container  className={classnames(classes.cardSeller,'cardSeller')}>
             <StoreIcon className={classes.storeicon} />
             <Typography   className={classes.sellerName}>فروشنده : ایران موبایل</Typography>
         </Grid>

      </Grid>
    )
}
