import React from 'react'
import useStyles from './styles'
import {Grid,Typography,Divider}from '@material-ui/core'
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import Link from '@material-ui/core/Link';
import CategoryCard from './CategoryCard/CategoryCard';
import {TreeView,TreeItem} from '@material-ui/lab'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import FilterOneRight from './FilterOne/FilterOneRight'
import FilterOneLeft from './FilterOne/FilterOneLeft'
import FilterTwoRight from './FilterTwo/FilterTwoRight'
import FilterTwoLeft from './FilterTwo/FilterTwoLeft';
import Header from './FilterTwo/Header';


export default function CategoryPage3() { 
    const classes=useStyles();
    const TAB1=1;
    const TAB2=2;
    const [tab, setTab] = React.useState(TAB1);

  
    return (
       <Grid container className={classes.container}>
           
       

       <Grid item container className={classes.middle}>
       <Grid item container className={classes.middleSpace}>
           
            </Grid>
      <Grid item container className={classes.middleRight} dir="rtl">
    


<FilterTwoRight tab={TAB2} set={setTab}/>




      


        </Grid>




      <Grid item container className={classes.middleSpace}> </Grid>



       <Grid item container className={classes.middleLeft} dir="rtl">




<FilterTwoLeft/>


       </Grid>
       <Grid item container className={classes.middleSpace}> </Grid>
      </Grid>

       </Grid>
    )
}