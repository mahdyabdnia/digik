import { makeStyles } from "@material-ui/core";
const useStyles=makeStyles({
    container:{
        height:"220px",
        display:'flex',
        flexDirection:'row',
        paddingTop:'20px',
        paddingRight:'20px'
    },
    img:{
        width:'140px',
        height:'140px',
        display:'block',
        marginTop:'0px',
        marginLeft:'auto',
        marginRight:'auto'
    },
    imgBox:{
    width:'194px',
    height:'140px',
    marginTop:'0px',

    },
    imgCe:{
         height:'100%',
         width:'194px',
    },
    box:{
        width:'100%',
        display:'flex',
        flexDirection:'column',
        direction:'rtl',
        paddingRight:'20px',
    

    },
    name:{
        fontSize:'20px',
        color:'black',
        fontWeight:'normal'
    },
    circle:{
        border:'1px black solid',
        
        width:'10px !important',
        height:'10px !important',
        display:'inline-block',
    },
    iconBox:{
        display:'flex',
        flexDirection:'row',
        justifyContent:'flex-start',
        alignItems:'center'
    },
    iconBtn:{
     cursor:'pointer',
     margin:'0px 5px'
    },
    iconTitle:{
        color:'#7f8288',
        fontSize:'14px',
        marginRight:'10px'
    },
    icon:{
        fontSize:'20px',
        color:'#7f8288',
        
    },
    line:{
        height:'10px',
        backcgroundColor:'#7f8288',
        width:'1px',
        border:'1px solid #e3e3e3',
        margin:'0px 10px'
    },
    local:{
        transform:'scaleX(-1)',
    color:'red !important',

    },
    addContainer:{
        width:'96px',
        height:'38px',
        border:'1px solid #e3e3e3',
        borderRadius:'10px',
        display:'flex',
        flexDirection:'row',
        direction:'rtl',
        marginLeft:'30px'
    },
    fi:{
        color:'#14adc7',
        fontSize:'20px',
        width:'32px',
        height:'38px',
        display:'flex',
        alignItems:'center',
        justifyContent:'center',
        cursor:'pointer'
    },
    price:{
        marginLeft:'20px'
    },
    link:{
        textDecoration:'none',
        display:'flex',
        alignItems: 'center',
        justifyContent:'center'
    }

});

export default useStyles;