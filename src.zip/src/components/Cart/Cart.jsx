import React,{useState} from 'react'
import {Tab,Tabs,Grid,Divider, Typography,Button,Icon } from '@material-ui/core'
import useStyles from './styles'
import classnames from 'classnames'
import MeetingRoomOutlinedIcon from '@material-ui/icons/MeetingRoomOutlined';
import VerifiedUserOutlinedIcon from '@material-ui/icons/VerifiedUserOutlined';
import StoreMallDirectoryOutlinedIcon from '@material-ui/icons/StoreMallDirectoryOutlined';
import LocalShippingOutlinedIcon from '@material-ui/icons/LocalShippingOutlined';
import StorefrontOutlinedIcon from '@material-ui/icons/StorefrontOutlined';
import DeleteOutlineOutlinedIcon from '@material-ui/icons/DeleteOutlineOutlined';
import PlaylistAddOutlinedIcon from '@material-ui/icons/PlaylistAddOutlined';
import CheckCircleOutlinedIcon from '@material-ui/icons/CheckCircleOutlined';
import CardCart from './CardCart'

export default function 
() {  

    const classes=useStyles();
     const Tab1=0;
     const Tab2=1;
     const [value, setvalue] = useState(Tab1);
     const [empty, setempty] = useState(1);
    const  handleChange=(event,newValue)=>{
         setvalue(newValue);

     }
    return (
        <div className={classes.container}>
       <Grid item container direction="column" style={{ margin:'auto',width:'90%' }}>
           
       <Tabs value={value}
                onChange={handleChange}
                indicatorColor="secondary"
    textColor="secondary"
                >
                    <Tab label="سبد خرید"/>
                    <Tab label="لیست خرید بعدی"/>

                    



                </Tabs>
<Divider orientation="horizontal" />
       </Grid>

                 <div className={classes.row}>

                 <div className={classes.cart}>
                     {value===Tab1 &&
                     <>
                     {empty===0 &&
                     <Grid item container direction="column" >
                     <img src="images/cart.jpg" className={classes.img} />
                     <Typography variant="h6" color="initial" className={classes.block}>سبد خرید شما خالی است </Typography>
                     <Typography variant="body2" color="textSecondary" className={classes.block}>می توانید برای خرید به یکی از دو لینک زیر مراجعه کنید  </Typography>
                     <Button className={classes.block} onClick={()=>{setempty(1)}}>پر شدن لیست خرید </Button>
                   </Grid>
                     }
                     {empty!==0 &&
                 
                     <>
                     <CardCart/>
                     <Divider orientation="horizontal" /> 
                     <CardCart/>
                     </>
                     
                     } 
                   

                     
                     
                     
                     </>
                     }

                    {value===Tab2 &&
                     <Grid item container direction="column" >
                     <img src="images/list.jpg" className={classes.img} />
                     <Typography variant="h6" color="initial" className={classes.block}> لیست خرید بعدی شما خالی است   </Typography>
                     <p className={classes.parag}>شما می توانید محصولاتی را که انتخاب کرده اید <br/>
                     و فعلا قصد خرید آن ها را ندارید به لیست خرید بعدی خود اضافه کرده <br/>
                     و در مراجعه بعدی اقدام به خرید کنید  </p>
                   </Grid>
                     
                     
                     
                     
                     }

               
            
            
            
            
</div>

     {value===Tab2 &&
     <div className={classes.lg} >
       <span style={{ width:'10%',paddingRight:'20px' }}><img src="images/enter.jpg" alt="" style={{ width:'80%' }} /></span>
       <span style={{ width:'90%',textAlign:'right',paddingLeft:'10px' }}> <Typography variant="body1" className={classes.block} color="initial">ورود به حساب کاربری</Typography>
      <Typography variant="body2" color="textSecondary" className={classes.parag}>    برای مشاهده محصولاتی که بیشتر افزوده اید به حساب کاربری خود وارد شوید </Typography>
    </span>
     
     </div>
     
     }

     { value===Tab1 &&
        <div className={classes.userLogin}>
        <Grid item container direction="column" style={{ width:'90%',margin:"auto",marginTop:"20px" }}>

        <Grid item container direction="row" className={classes.blocker}>
        <div style={{ width:"50%",textAlign:'right' }} >
        <Typography variant="body1" color="textSecondary">قیمت کالا ها </Typography>
        </div>
        <div style={{ width:"50%",textAlign:'left' }}>
        <Typography variant="body1" color="textSecondary">258000 تومان</Typography>
        </div>
        </Grid>
        <Grid item container direction="row" className={classes.blocker}>
        <div style={{ width:"50%",textAlign:'right' }}>
        <Typography variant="body1" color="textSecondary">تخفیف کالاها </Typography>
        </div>
        <div style={{ width:"50%",textAlign:'left' }}>
        <Typography variant="body1" color="secondary">69000 تومان</Typography>
        </div>
        </Grid>
        <Divider orientation="horizontal" />
        <Grid item container direction="row" className={classes.blocker}>
        <div style={{ width:"50%",textAlign:'right' }}>
        <Typography variant="body1" color="initial">جمع سبد خرید </Typography>
        </div>
        <div style={{ width:"50%",textAlign:'left' }}>
        <Typography variant="body1" color="initial">280000تومان</Typography>
        </div>
        </Grid>

        <Grid item container direction="column" className={classes.blocker}>
        <Typography variant="caption" color="textSecondary">هزینه‌ی ارسال در ادامه بر اساس آدرس، زمان و نحوه‌ی ارسال انتخابی شما‌ محاسبه و به این مبلغ اضافه خواهد شد</Typography>
        <Button variant="contained" color="secondary" style={{ marginTop:'10px',marginBottom:"10px",marginLeft:"auto",marginRight:"auto",width:"90%" }}>
          ادامه فرآیند خرید 
        </Button>
        </Grid>
        

        <Divider orientation="horizontal" />
        <Grid item container direction="row" className={classes.blocker}>
        <div style={{ width:"50%",textAlign:'right' }}>
        <Typography variant="body1" color="textSecondary">  امتیاز دی چی کلاب</Typography>
        </div>
        <div style={{ width:"50%",textAlign:'left' }}>

        <Typography variant="body1" color="textSecondary"> 19 امتیاز </Typography>
        </div>
            </Grid> 
        </Grid>
       
        
        </div>
     }


   

                 </div>
            
        </div>
    )
}
