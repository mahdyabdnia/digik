import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({

 container:{ 
    
    paddingTop:"40px",
    
     display:'flex',
     flexDirection:'column',
     direction:"rtl",
     backgroundColor:'#f5f5f5'
 },
 row:{
    width:'90%',
    margin:"auto",
     display:'flex',
     flexDirection:'row',
     marginTop:"10px",
     paddingBottom:"60px"
 }
 ,
 cart:{
     width:'73%',
     direction:'rtl',
    minHeight:"329px",
    height:"auto",
     border:'solid #ebebeb 1px',
     backgroundColor:"white",
     borderRadius:"10px"
 },
 userLogin:{
     width:'23%',
     marginRight:'15px',
     height:"320px",
     borderRadius:"10px",
     
     backgroundColor:'white',
     display:'block',
     flexDirection:"column"
 },
 lg:{
    display:'flex',flexDirection:'row',direction:'rtl',justifyContent:'flex-start',padding:'10px 0px',height:'96px ',
    width:'23%',
    borderRadius:"10px",
     
    backgroundColor:'white',
    marginRight:'10px'
    
 },
 img:{ 
     display:'block',
     margin:"auto",
     maxWidth:"15% !important",
     maxHeight:"15% !important",
     marginTop:'60px !important'

 },
 img2:{
     display:'block',
     margin:"auto",
     maxWidth:"140px !important",
     maxHeight:"140px !important",
    

 },
 block:{
     margin:"auto"
 },
 parag:{
     margin:'auto',
     textAlign:'right',
     opacity:"0.5"
 },
 imgBox:{
     width:'20%'
 },
 detailBox:{
     width:"80%",
     
 },
 cartBox:{
     marginTop:'40px'
 },
 text:{
     textAlign:"right",
 },
 iconDiv:{
     display: 'flex',
     flexDirection:"row",
     marginTop:'5px',
     marginBottom:"5px"
 },
 addBar:{
     display:'flex',
     flexDirection:'row',
     alignItems: 'center',
     height:'40px'
 },
 tt:{
    
 },
 blocker:{
    margin:'10px auto 10px auto'
 }

});


export default useStyles;