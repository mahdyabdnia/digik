
import React,{useState} from 'react'
import {Tab,Tabs,Grid,Divider, Typography,Button,Icon } from '@material-ui/core'
import {Link} from 'react-router-dom'
import classnames from 'classnames'
import MeetingRoomOutlinedIcon from '@material-ui/icons/MeetingRoomOutlined';
import VerifiedUserOutlinedIcon from '@material-ui/icons/VerifiedUserOutlined';
import StoreMallDirectoryOutlinedIcon from '@material-ui/icons/StoreMallDirectoryOutlined';
import LocalShippingOutlinedIcon from '@material-ui/icons/LocalShippingOutlined';
import StorefrontOutlinedIcon from '@material-ui/icons/StorefrontOutlined';
import DeleteOutlineOutlinedIcon from '@material-ui/icons/DeleteOutlineOutlined';
import PlaylistAddOutlinedIcon from '@material-ui/icons/PlaylistAddOutlined';
import CheckCircleOutlinedIcon from '@material-ui/icons/CheckCircleOutlined';
import EventNoteOutlinedIcon from '@material-ui/icons/EventNoteOutlined';
import useStyles from './style';
import AddOrMinus from './AddOrMinus';
export default function CardCart() { 
    const classes=useStyles();
    return (
       <div className={classes.container}>
         <div className={classes.imgCe}>
           <div className={classes.imgBox}>
             <img src="images/laptop (7).jpg" alt="" className={classes.img} />
           </div>
            </div>
         <div className={classes.box}>
           <h1 className={classes.name}>لپ تاپ 15 اینچ ایسوس</h1>
            <div classnames={classes.iconBox}><VerifiedUserOutlinedIcon className={classes.icon}/><span className={classes.iconTitle}>گارانتی حفاظت و سلامت ایمنی کالا </span></div>
            <div classnames={classes.iconBox}><StoreMallDirectoryOutlinedIcon className={classes.icon}/><span className={classes.iconTitle}>فروشگاه </span></div>
            <div classnames={classes.iconBox}><img src='images/store.jpg' /><span className={classes.iconTitle}>موجود در انبار دی جی کالا </span>
            <line className={classes.line}></line>
            <LocalShippingOutlinedIcon className={classnames(classes.icon,classes.local)}/>
            <span className={classes.iconTitle}>ارسال توسط دیجی کالا</span>
            </div>
          <div style={{ display:'flex',alignItems:'center',direction:'rtl',justifyContent:'space-between' }}>
            <span style={{ display:'flex' }}>
            <AddOrMinus/>
          <span className={classnames(classes.iconBox,classes.iconBtn)}><DeleteOutlineOutlinedIcon className={classes.icon}/><span className={classes.iconTitle}>حذف</span></span>
         <Link to="/login" className={classes.link}> <span className={classnames(classes.iconBox,classes.iconBtn)}><EventNoteOutlinedIcon className={classes.icon}/><span className={classes.iconTitle}>ذخیره در لیست خرید بعدی</span></span> </Link>
         
            </span>
         
          <span className={classes.price}>25000 تومان</span>
            </div>  
         </div>
       </div> 
    )
}
