import React,{useState,useEffect} from 'react'
import useStyles from './style'
import classnames from 'classnames';
export default function AddOrMinus() {
    const classes=useStyles();
    const [num, setNum] = useState(1);
    const add=()=>{
        setNum(num+1);
    }
    const minus=()=>{
        var d=document.getElementsByClassName('mi');
        var i;
        for(i=0;i<d.length;i++){
            d[i].addEventListener('click',function(){
                if(num===1){
                    setNum(num);
                    this.style.color="#e1e1e3"
                }
                else{
                    setNum(num-1);
                this.style.color="#14adc7"                }
            })
        }
        
    }
    useEffect(() => {
        minus()
       
        
    }, []);
    return (
        <div className={classes.addContainer}>
            <span className={classes.fi} onClick={add}>+</span>
            <span className={classes.fi}>{num}</span>
            <span className={classnames(classes.fi,'mi')} onClick={minus}>-</span>
        </div>
    )
}
