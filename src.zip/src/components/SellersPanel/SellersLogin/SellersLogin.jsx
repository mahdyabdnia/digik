import React,{useEffect} from 'react'
import useStyles from './styles'
import {Icon,IconButton, Typography} from '@material-ui/core'
import EmailOutlinedIcon from '@material-ui/icons/EmailOutlined';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import VisibilityOutlinedIcon from '@material-ui/icons/VisibilityOutlined';
import RemoveRedEyeOutlinedIcon from '@material-ui/icons/RemoveRedEyeOutlined';
import classnames from 'classnames'
export default function SellersLogin() {
    const changePasswordShow=()=>{
    var x=document.getElementsByClassName('pass');
    if(x.type==="password"){
        x.type = "text";
    }
    else{
        x.type="password";
    }
    }

    useEffect(() => {
       changePasswordShow();
    }, []);
const classes=useStyles();
    return (
        <div className={classes.continaer}>
          <div className={classes.div1}>
          <a>
              <img className={classes.logo} src="/images/logo.svg"/>
          </a>

         <Typography variant="h5" color="initial">به مرکز فروشندگان دی جی کالا  <br/>خوش آمدید !</Typography>

         <img src="/images/center.svg" className={classes.center} />

         <p className={classes.caption}>Copyright © 2006 - 2020 Digikala.com</p>
          
          
          
          
          </div> 
          <div className={classes.div2}>
              
          <div className={classes.divForm}>
              
              <div className={classes.divInput}>
               <span style={{ borderRight:'1px solid #e9ebef',display:'flex',alignItems:'center' }}>
                <Icon style={{ color:'#e9ebef',padding:'0px 10px' }}><EmailOutlinedIcon/></Icon>
               </span>
               <input type="email" className={classes.inputWithIcon} placeholder="ایمیل خود را وارد کنید " />

              </div>

              <div className={classes.divInput}>
               <span style={{ borderRight:'1px solid #e9ebef',display:'flex',alignItems:'center' }}>
                <Icon style={{ color:'#e9ebef',padding:'0px 10px' }}><LockOutlinedIcon
                /></Icon>
               </span>
               <input type="password" className={classnames(classes.inputWithIcon,'pass')} placeholder=" کلمه عبور خود را وارد نمایید  "  />
               <span style={{ borderRight:'1px solid #e9ebef',display:'flex',alignItems:'center' }}>
               <IconButton className={classes.iconButton} style={{ color:'#e9ebef',padding:'0px 10px' }} onClick={changePasswordShow}>
                   <RemoveRedEyeOutlinedIcon/>
               </IconButton>
               </span>



              </div>
               <div className={classes.rememberMe}>
               <input type="checkbox" name="remember" className={classes.checkbox}/>
              <label for="remember" className={classes.label}>مرا به خاطر بسپار</label>
               </div>

               <input type="submit" value="ورود" className={classes.submit}/>
               <div className={classes.forgeted}>
                   <div style={{ borderBottom:'2px dotted #62d1eb',display:'inline-block' }}>
                       
                   <Typography className={classes.txt1} variant="body1" color="initial">رمز عبور خود را فراموش کرده ام</Typography>
                       </div> 
                
                 </div>
                 <div className={classes.dontsign}> 
                  <Typography variant="body1">هنوز ثبت نام نکرده اید ؟</Typography>
                  <span style={{ borderBottom:'2px dotted #62d1eb', }}>
                  <Typography className={classes.txt1} variant="body1" color="initial"> همین حالا ثبت نام کنید   </Typography>
                  </span>
                  
                     </div>


                   
             




         



          </div>
          
          
          
          
          
          <div className={classes.foot}>

          <ul  className={classes.footer}>
                     <li className={classes.li}>ثبت رسید سفارش</li>
                     <li className={classes.li}>ثبت رسید سفارش</li>
                     <li className={classes.li}> مرکز آموزش فروشندگان</li>
                     <li className={classes.li}>مراحل ثبت نام </li>
                     <li className={classes.li}>فروشگاه اینترنتی دیجی کالا</li>
 

                     </ul>
          </div>
         
             
          
          
          </div> 
        </div>
    )
}
