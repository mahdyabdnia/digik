import {makeStyles, Container} from '@material-ui/core'
const useStyles =makeStyles({
continaer:{
    display:'flex',
    flexDirection:'row',
    direction:"rtl",
    overflowX:'hidden'
   
},
divForm :{
    margin:'auto',
    paddingTop:'200px',
    width:'465px'
},
divInput:{
    border:'1px solid #e9ebef',
    borderRadius:'10px',
    display:'flex',
    direction:'ltr',
    flexDirection:'row',
    height:"50px",marginTop:20,
},
iconButton:{
    '&:focus':{
        backgroundColor:'inherit'
    }
}
,
div1:{
    width:'31%',
    backgroundColor:'#f5f7fa',
    borderBottomLeftRadius:'100px',
    textAlign:'center'
},
logo:{
display:'block',
width:'60%',
height:'auto',
margin:'40px auto'
},
center:{
marginTop:'60px',
marginRight:'-165px'
},
caption:{
marginTop:'80px',
fontSize:'12px'
},
div2:{
    width:"69%",
    margin:'auto'
},
inputWithIcon:{
    outline:'none',
    width:'100%',
    border:'none',
    borderRadius:'10px',
    paddingLeft:20
},
rememberMe:{
    display:'flex',
    justifyContent:'space-around',
    padding:'40px 160px'
},
checkbox:{
    borderRadius:'10px',
    color:'#57cfb1',
    backgroundColor:"#57cfb1",
    '&:active':{
        color:'#57cfb1',
    backgroundColor:"#57cfb1",
    }
},
label:{
    opacity:'0.6',
    fontSize:"19px"
},
submit:{
   
    backgroundColor:"#57cfb1",
    width:'205px',
    height:'50px',
    
    display:'block',
    margin:'auto',
    borderRadius:'8px',
    border:"solid 1px",
    color:'#fff'
},
forgeted:{
    textAlign:'center',
    padding:'40px 0',
    
    
},

dontsign:{
    textAlign:'center',
    padding:'22px 0px 50px 0',
    display:'flex',
    justifyContent:'center'
    
    
},
txt1:{
    color:'#62d1eb',
    fontWeight:'bold'
   
},
footer:{
    display:'inline-block',
    listStyleType:'none',
   
    margin:'auto'
},
foot:{
    display:'flex',
    justifyContent:'center',
    position:'relative',
    bottom:'0',
}
,
li:{
    display:'inline-block',
    fontSize:'14px',
    opacity:'0.5'
}
});
export default useStyles;