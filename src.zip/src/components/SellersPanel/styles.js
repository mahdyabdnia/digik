import { makeStyles } from "@material-ui/core";
import { CenterFocusStrong } from "@material-ui/icons";
const useStyles=makeStyles({
toolBar:{
    display:'flex',
    flexDirection:'row',
    maxWidth:'60%',
    margin:'auto',
    maxHeight:'60px'
},
appBar:{
    height:'110px',
 
    width:'100%'
},
leftBar:{
    width:'80%'
},
rightBar:{
    width:"20%",
    direction:"rtl"
},
btn1:{
    backgroundColor:"#ef5661",
    borderRadius:'22px',
    color:'white',
   fontWeight:'bold',
  marginRight:'20px',
  height:'44px'
  
},
btn2:{
    
    borderRadius:'22px',
    color:'#ef5661',
    outlineColor:'#ef5661',
    outlineStyle:'solid',
    outlineWidth:'2px',
    marginRight:'20px',
    height:'44px'
  
   
},
btn3:{'&:focus':{
    backgroundColor:'inherit'
},
    '&:hover':{
        backgroundColor:'inherit'
    },
    
    backgroundColor:'inherit',
    opacity:'0.7',
    fontStyle:'bold',
    marginRight:'30px',
    fontSize:'17px',
    height:'44px'
},
headImg:{
    display:'block',
    maxHeight:'50px',
    maxWidth:"100%",
    
    
},
header:{
    marginTop:'120px',
    display:'flex',
    flexDirection:'row',
    paddingBottom:'40px',
    overflowX:"hidden",
    justifyContent:'center'
},
tringleDown:{
    display:'inline',

    width:'0',
    height:0,
    borderLeft:'20px solid transparent ',
    borderRight:'20px solid transparent ',
    borderTop:" 30px solid #ed5565",
    
},
hh:{
    textAlign:"center",
    marginTop:'-20px'
},
advantage:{
    width:'1000px',
    margin:"auto",
    paddingBottom:'40px',
    paddingTop:'40px',
    justifyContent:'center'
},
advantage2:{
    width:'1000px',
    margin:"auto",
    paddingBottom:'40px',
    paddingTop:'60px'
},
imgadv:{
    display:'block',
    margin:'auto',
    width:"70%",
    height:"50%",

},
textadv:{
textAlign:'center',
paddingBottom:'20px'
},
adiv:{
    height:'247px',
    width:"175px",
   marginTop:'20px',
    '&:hover':{
        boxShadow:'0 0 20px rgba(188, 247, 198, 1)'
    }
},
adiv2:{
    height:'247px',
    width:"175px",
    marginTop:'50px',
    '&:hover':{
        boxShadow:'0 0 20px rgba(188, 247, 198, 1)'
    }
},

stockadv:{
    marginTop:'50px',
    width:"1024px",
    display:"flex",
    flexDirection:'row',
    margin:'auto'
},
stockdiv:{
    width:"60%"
},
stockdiv2:{
    width:"40%",
    direction:"rtl",
    textAlign:'right',
    paddingTop:'100px',
    paddingRight:'60px'
},
btnstock:{
    color:'#57cfb1',
    outline:'2px #57cfb1 solid',
    marginTop:'40px'
},
mapimg:{
    display:'block',
    margin:"auto",
    width:"65%",
    height:'100%'
},
mapmapimg:{
    display:'block',
    margin:"auto",
    marginTop:"80px",
    marginBottom:'80px',
},
quests:{
    direction:'rtl',
    maxWidth:"1026px",
     
    
    display:'flex',
    flexDirection:"column",
    flexWrap:'none',
    overflowX:'hidden',
  zIndex:1,
   
    margin:"10px auto 60px auto",
    maxHeight:'340px',
   
    height:'auto',
   
   
    overflowY:'scroll '
    
  
},
pasokh:{
    borderRadius:'5px',
  
    maxHeight:'260px',
    width:"986px",
    height:'auto',
   zIndex:10,
    marginLeft:"10px",
    border:"2px solid #e9ebef",
    marginTop:"5px",
    marginBottom:'5px',
   justifyItems:'center',
   alignContent:'center',
   display:'flex',
   flexDirection:"column",
   
   '&:hover':{
    boxShadow:'0 0 20px rgba(188, 247, 198, 1)'
   }
}, 
span1:{
justifyContent:'center',
alignItems:'center',
display:'flex',

fontSize:"17px",

}
,
span2:{
    width:"40px",
    height:"60px",
    display:'flex',
    justifyContent:'flex-end',
    direction:'rtl',
    left:"0px",
    alignItems:'center',
        
},

pluse:{
    width:'18px',heigth:'18px',display:'block',margin:"auto"
},
awhead:{
    justifyContent:'space-between',
    display:'flex',
    paddingLeft:"20px",
    paddingRight:"20px",
    cursor:'pointer',
    height:'61px'
},
divider:{
    height:"2px",width:'10%',direction:'rtl',marginTop:'10px'
},

awbody:{
    minHeight:'100px',
    height:'auto',
    padding:'5px 15px',
    display:'none'
},
parabody:{
    lineHeight:'30px'
},
success:{ 
    width:'1144px',
    height:'400px',
    margin:'50px auto ',
    backgroundColor:'white !important',
    position: 'relative',
    
},
boxSec:{
display:'none',

 
},
dot:{
    backgroundColor:'grey !important'
},
explain:{
    width:'280px',
    height:'400px',
    backgroundColor:'#f5f7fa',
    position: 'absolute',
    left:'0px',
    borderRadius:'15px',
    paddingRight:'200px',
    paddingLeft:'40px',
    display:'flex',
    direction:'rtl',
    flexDirection:'column',
    justifyContent:'center'
},
vir:{
    display:'block',
    width:'35px',
    height:'35px',
    
},
video:{
    position:'absolute',
    right:'0px',
    top:'5%'
},
sellerBackground:{
    width:'620px',
    height:'460px',
    direction:'rtl',
    textAlign:'right',
    display:'flex',
    flexDirection:'column',
    justifyContent:'flex-end',
    paddingBottom:'100px',
    paddingRight:'100px',
    color:'white',
    justifySelf:'right',
    backgroundImage:"url(https://www.digikala.com/static/files/de12833f.svg)"
},
headPhone:{
    width:'50px',
    height:'50px',
    backgroundColor:"#ef4056",
    borderTopRightRadius:'50%',
    borderBottomRightRadius:'50%',
    borderBottomLeftRadius:'50%',
    display:'flex',
    alignItems:'center',
    justifyContent: 'center',
    position:'fixed',
    bottom:'40px',
    left:'40px'

},
headPhoneIcon:{
    color:'white',
    fontSize:'30px'
}



});
export default useStyles;