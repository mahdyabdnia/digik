import React,{useState,useEffect} from 'react'
import useStyles from './styles'
import {AppBar,Toolbar,Grid,Typography,Button,Divider} from '@material-ui/core'
import 'react-image-gallery/styles/css/image-gallery.css';
import ImageGallery from 'react-image-gallery';
import './style.css'
import classnames from 'classnames'
import AddIcon from '@material-ui/icons/Add';
import {Link} from 'react-router-dom'
import Succes from './Succes/Succes'
import HeadsetMicOutlinedIcon from '@material-ui/icons/HeadsetMicOutlined';



export default function SellersPanel() {
    const classes=useStyles();
  
   
   const [statusA, setStatusA] =  useState(false)
   const [statusB, setStatusB] =  useState(false)
   const [statusC, setStatusC] =  useState(false)
   const [statusD, setStatusD] =  useState(false);
  const handleChangeA=()=>{
     setStatusA(!statusA);
   }

   useEffect(() => {
    upAndDown();
    
   }, []);
  

  const upAndDown=()=>{
    var acc=document.getElementsByClassName('awhead');
   
    var i;
    var j;
    for(i=0;i<acc.length;i++){
  
      
          acc[i].addEventListener('click',function(){
            this.classList.toggle('active');
            var awbody=this.nextElementSibling;
            if(awbody.style.display==="block"){
              awbody.style.display="none";
            
              
            }
            else{
              awbody.style.display="block";
             
            }
          });
        
     
    
    }
  }
  var slideIndexV2=1;
  function currentSlide(n) {
    showSlidesV2(slideIndexV2 = n);
  }

  function showSlidesV2(n) {
    var i;
    var slides = document.getElementsByClassName("boxSec");
    
    if (n > slides.length) {slideIndexV2 = 1}    
    if (n < 1) {slideIndexV2 = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    
    slides[slideIndexV2-1].style.display = "flex";  
    
  }
  useEffect(() => {
    showSlidesV2(slideIndexV2);
    return () => {
    
    }
  }, [])

  useEffect(() => {
    var slideIndex2=0;
    const showSlide=setInterval(function(){
      var i;
      var slides=document.getElementsByClassName('boxSec');
      var dots=document.getElementsByClassName('dotA');
      
      for(i=0;i<slides.length;i++){
        slides[i].style.display="none";
      }
      slideIndex2++;
      if(slideIndex2>slides.length){slideIndex2=1}
      for (i = 0; i < dots.length; i++) {
        dots[i].classList.remove('dotSelected');
      }
      slides[slideIndex2-1].style.display="flex"
      dots[slideIndex2-1].classList.add('dotSelected')

    },5000)
    return () => {
     clearInterval(showSlide);
    }
  }, [])

  useEffect(() => {
  var slideInx=0;
  const sliderShow=setInterval(function(){
var i;
var sliders=document.getElementsByClassName('mySlide');
var dots=document.getElementsByClassName('dots');
for(i=0;i<sliders.length;i++){
  sliders[i].style.display="none";
}
slideInx++;
if(slideInx > sliders.length){
  slideInx=1;
}

sliders[slideInx-1].style.display="block"





  },5000)
    return () => {
      clearInterval(sliderShow);
    }
  }, [])
 
  
     
    return (
        <div style={{ backgroundColor:'white',height:'auto'}}>
          <div className={classes.headPhone}>

<HeadsetMicOutlinedIcon className={classes.headPhoneIcon}/>
</div>
         <Grid container direction="column" className={classes.appBar}>
             <Grid item container direction="row" className={classes.toolBar}>
                <Grid container direction="row" className={classes.leftBar}> 
                <Link to="/sellersPanel/signup"><Button  variant="contained" className={classes.btn1} size="large" > ثبت نام </Button></Link> 
                <Link to="/sellersPanel/login"><Button varinat="outlined" className={classes.btn2} size="large">ورود به پنل فروشندگان</Button></Link>
                 <Button  variant="link" className={classes.btn3}> مرکر آموزش فروشندگان  </Button>
                 <Button  variant="link" className={classes.btn3}>  راهنمای ثبت نام   </Button>
                </Grid>
                <Grid container direction="row" className={classes.rightBar}> 
                <img src="/images/head.svg"  className={classes.headImg} />
                 </Grid>

             </Grid>

         </Grid>
       
         <div className={'carousel'}>
              <div className={classnames('mySlide')}>
              <img src="images/sellpanel (1).jpg" className={classnames('slide')} />
              </div>
              <div className={classnames('mySlide')}>
              <img src="images/sellpanel (2).jpg" className={classnames('slide')} />
              </div>
              <div className={classnames('mySlide')}>
              <img src="images/sellpanel (3).jpg" className={classnames('slide')} />
              </div>
              <div className={classnames('mySlide')}>
              <img src="images/sellpanel (4).jpg" className={classnames('slide')} />
              </div>
              <div className={classnames('mySlide')}>
              <img src="images/sellpanel (5).jpg" className={classnames('slide')} />
              </div>
              
              
           

          
           <div className={'dotBox'}>
           <span className={classnames('dots')}></span>
           <span className={classnames('dots')}></span>
           <span className={classnames('dots')}></span>
           <span className={classnames('dots')}></span>
           <span className={classnames('dots')}></span>
           </div>
           
         </div>
          
         
         
         

         <Grid className={classes.header}>
           <Divider orientation="horizontal" className={classes.divider}  />
           <div className={classes.tringleDown}/>
           <Divider orientation="horizontal" className={classes.divider}  />
         </Grid>
         <Typography className={classes.hh} variant="h5" color="initial">داستان های موفقیت ، از زبان فروشندگان</Typography>

         <div className={classes.success}>
           <div style={{ display:'flex' }} className={classnames(classes.boxSec,'boxSec')}>
           <div className={classes.explain}>
             <img src="images/vir.svg" alt="" className={classes.vir}/>
             <Typography variant="h6" color="initial">فرزانه3 رضایی</Typography>
             <Typography variant="h6" color="textSecondary">دیجی کالا، خانه کسب و کار ایرانی</Typography>
             <Typography variant="body2" color="textSecondary">خانم فرزانه رضایی به همراه برادرانش سعی کرده حرفه  و هنر خوانوادگیشون </Typography>
           </div>
           <video width="743" height="360" controls className={classes.video}>
             <source src="images/sellpanel.mp4" type="video/mp4"/>

           </video>
           </div>

           <div className={classnames(classes.boxSec,'boxSec')}>
           <div className={classes.explain}>
             <img src="images/vir.svg" alt="" className={classes.vir}/>
             <Typography variant="h6" color="initial">فرزانه4 رضایی</Typography>
             <Typography variant="h6" color="textSecondary">دیجی کالا، خانه کسب و کار ایرانی</Typography>
             <Typography variant="body2" color="textSecondary">خانم فرزانه رضایی به همراه برادرانش سعی کرده حرفه  و هنر خوانوادگیشون </Typography>
           </div>
           <video width="743" height="360" controls className={classes.video}>
             <source src="images/sellpanel.mp4" type="video/mp4"/>

           </video>
           </div>

           <div className={classnames(classes.boxSec,'boxSec')}>
           <div className={classes.explain}>
             <img src="images/vir.svg" alt="" className={classes.vir}/>
             <Typography variant="h6" color="initial">فرزانه2 رضایی</Typography>
             <Typography variant="h6" color="textSecondary">دیجی کالا، خانه کسب و کار ایرانی</Typography>
             <Typography variant="body2" color="textSecondary">خانم فرزانه رضایی به همراه برادرانش سعی کرده حرفه  و هنر خوانوادگیشون </Typography>
           </div>
           <video width="743" height="360" controls className={classes.video}>
             <source src="images/sellpanel.mp4" type="video/mp4"/>

           </video>
           </div>

           <div className={classnames(classes.boxSec,'boxSec')}>
           <div className={classes.explain}>
             <img src="images/vir.svg" alt="" className={classes.vir}/>
             <Typography variant="h6" color="initial">فرزانه1 رضایی</Typography>
             <Typography variant="h6" color="textSecondary">دیجی کالا، خانه کسب و کار ایرانی</Typography>
             <Typography variant="body2" color="textSecondary">خانم فرزانه رضایی به همراه برادرانش سعی کرده حرفه  و هنر خوانوادگیشون </Typography>
           </div>
           <video width="743" height="360" controls className={classes.video}>
             <source src="images/sellpanel.mp4" type="video/mp4"/>

           </video>
           </div>

           <div className={classnames('dotBox')} style={{ bottom:'-20px' }}>
             <span className={classnames('dot',classes.dot,'dotA')} onClick={()=>currentSlide(1)}></span>
             <span className={classnames('dot',classes.dot,'dotA')} onClick={()=>currentSlide(2)}></span>
             <span className={classnames('dot',classes.dot,'dotA')} onClick={()=>currentSlide(3)}></span>
             <span className={classnames('dot',classes.dot,'dotA')} onClick={()=>currentSlide(4)}></span>
           </div>
          
            

         </div>

         <Grid className={classes.header}>
           <Divider orientation="horizontal" className={classes.divider} />
           <div className={classes.tringleDown}/>
           <Divider orientation="horizontal" className={classes.divider}  />
         </Grid>
         <Typography className={classes.hh} variant="h5" color="initial">  مزایای فروش در دیجی کالا  </Typography>
         <Grid item container direction="row">
         <Grid container item direction="row" className={classes.advantage}>
           <Grid item container direction="column" className={classes.adiv}>
             <img src="images/map.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>  فروش در سرتاسر کشور   </Typography>
           </Grid>
           <Grid item container direction="column" className={classes.adiv2}>
             <img src="images/protected.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>کاهش هزینه های جانبی فروش تا کمترین زمان ممکن </Typography>
           </Grid>
           <Grid item container direction="column" className={classes.adiv}>
             <img src="images/map.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>  فروش در سرتاسر کشور   </Typography>
           </Grid>
           <Grid item container direction="column" className={classes.adiv2}>
             <img src="images/protected.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>کاهش هزینه های جانبی فروش تا کمترین زمان ممکن </Typography>
           </Grid>
           <Grid item container direction="column" className={classes.adiv}>
             <img src="images/map.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>  فروش در سرتاسر کشور   </Typography>
           </Grid>
           <Grid item container direction="column" className={classes.adiv2}>
             <img src="images/protected.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>کاهش هزینه های جانبی فروش تا کمترین زمان ممکن </Typography>
           </Grid>
           <Grid item container direction="column" className={classes.adiv}>
             <img src="images/map.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>  فروش در سرتاسر کشور   </Typography>
           </Grid>
           <Grid item container direction="column" className={classes.adiv2}>
             <img src="images/protected.jpg" alt="" className={classes.imgadv}/>
             <Typography className={classes.textadv}>کاهش هزینه های جانبی فروش تا کمترین زمان ممکن </Typography>
           </Grid>



         </Grid>

         
         
         </Grid>
         <Grid className={classes.header}>
           <Divider orientation="horizontal" className={classes.divider}  />
           <div className={classes.tringleDown}/>
           <Divider orientation="horizontal" className={classes.divider}  />
         </Grid>
         <Typography className={classes.hh} variant="h5" color="initial"> ارسال کالای شما به نزدیک ترین انبار </Typography>
         <Grid className={classes.stockadv}>
           <Grid className={classes.stockdiv}>
             <img src="images/iranmap.jpg" className={classes.mapimg}/>
           </Grid>
           <Grid className={classnames(classes.stockdiv2)}> 
           <Typography variant="h6" color="initial">با گسترش انبارهای دیجی‌کالا در شهرهای ایران، کالای شما در کمترین زمان ممکن به دست مشتریان خواهد رسید. </Typography>
           <Button variant="outlined" size="large" className={classes.btnstock}>اطلاعات بیشتر در مورد انبار ها </Button>
           </Grid>
         </Grid>

         <Grid className={classes.header}>
           <Divider orientation="horizontal" className={classes.divider}  />
           <div className={classes.tringleDown}/>
           <Divider orientation="horizontal" className={classes.divider}  />
         </Grid>
         <Typography className={classes.hh} variant="h5" color="initial">  فرآیند شروع کار   </Typography>

         <img src="images/mapmap.jpg" className={classes.mapmapimg} />

         <Grid className={classes.header}>
           <Divider orientation="horizontal" className={classes.divider}  />
           <div className={classes.tringleDown}/>
           <Divider orientation="horizontal" className={classes.divider}  />
         </Grid>
         <Typography className={classes.hh} variant="h5" color="initial">  سوالات متداول  </Typography>
          <div className={classes.quests}>


           <div className={classnames(classes.pasokh,'pasokh')}>
            <div className={classnames(classes.awhead,'awhead')}>
            <span className={classes.span1}>
               چه کساینی میتوانند درمرکز فروشندگان دیچی کالا فروشنده شوند 
             </span>
             <span className={classnames(classes.span2,'span2')}>
               <img  src="images/pluse.jpg" className={ classnames(classes.pluse,'pluse')}/>
             </span>
            </div>

            <div className={classnames(classes.awbody,'awbody')}>
            <p className={classes.parabody}>
            مرکز فروشندگان دیجی‌کالا، پلتفرمی است که در آن فروشندگان کالاهای مختلف از جمله برند های معتبر، فروشندگان خرد و کلان، صاحبان کسب و کارهای کوچک و هر شخصی که کالایی برای عرضه دارد، می توانند به صورت آنلاین محصولات خود را در قالب فروشنده حقیقی و فروشنده حقوقی به فروش برسانند . فروشنده حقیقی: فردی است که دارای خصوصیاتی مختص به خود مانند نام، نام خانوادگی، تاریخ تولد، کد ملی، شماره شناسنامه و غیره می باشد. فروشنده حقوقی: موسسات یا شرکت هایی هستند که پس از طی مراحل قانونی به ثبت می‌رسند و دارای مشخصاتی مانند نام شخص حقوقی، تاریخ ثبت، شماره ثبت، کد شناسایی، کد اقتصادی، موضوع فعالیت و غیره می باشند. 
            </p>
            </div>
          
           </div>

           <div className={classnames(classes.pasokh,'pasokh')}>
            <div className={classnames(classes.awhead,'awhead')}>
            <span className={classes.span1}>
               چه کساینی میتوانند درمرکز فروشندگان دیچی کالا فروشنده شوند 
             </span>
             <span className={classnames(classes.span2,'span2')}>
               <img  src="images/pluse.jpg" className={ classnames(classes.pluse,'pluse')}/>
             </span>
            </div>

            <div className={classnames(classes.awbody,'awbody')}>
            <p className={classes.parabody}>
            مرکز فروشندگان دیجی‌کالا، پلتفرمی است که در آن فروشندگان کالاهای مختلف از جمله برند های معتبر، فروشندگان خرد و کلان، صاحبان کسب و کارهای کوچک و هر شخصی که کالایی برای عرضه دارد، می توانند به صورت آنلاین محصولات خود را در قالب فروشنده حقیقی و فروشنده حقوقی به فروش برسانند . فروشنده حقیقی: فردی است که دارای خصوصیاتی مختص به خود مانند نام، نام خانوادگی، تاریخ تولد، کد ملی، شماره شناسنامه و غیره می باشد. فروشنده حقوقی: موسسات یا شرکت هایی هستند که پس از طی مراحل قانونی به ثبت می‌رسند و دارای مشخصاتی مانند نام شخص حقوقی، تاریخ ثبت، شماره ثبت، کد شناسایی، کد اقتصادی، موضوع فعالیت و غیره می باشند. 
            </p>
            </div>
          
           </div>

           <div className={classnames(classes.pasokh,'pasokh')}>
            <div className={classnames(classes.awhead,'awhead')}>
            <span className={classes.span1}>
               چه کساینی میتوانند درمرکز فروشندگان دیچی کالا فروشنده شوند 
             </span>
             <span className={classnames(classes.span2,'span2')}>
               <img  src="images/pluse.jpg" className={ classnames(classes.pluse,'pluse')}/>
             </span>
            </div>

            <div className={classnames(classes.awbody,'awbody')}>
            <p className={classes.parabody}>
            مرکز فروشندگان دیجی‌کالا، پلتفرمی است که در آن فروشندگان کالاهای مختلف از جمله برند های معتبر، فروشندگان خرد و کلان، صاحبان کسب و کارهای کوچک و هر شخصی که کالایی برای عرضه دارد، می توانند به صورت آنلاین محصولات خود را در قالب فروشنده حقیقی و فروشنده حقوقی به فروش برسانند . فروشنده حقیقی: فردی است که دارای خصوصیاتی مختص به خود مانند نام، نام خانوادگی، تاریخ تولد، کد ملی، شماره شناسنامه و غیره می باشد. فروشنده حقوقی: موسسات یا شرکت هایی هستند که پس از طی مراحل قانونی به ثبت می‌رسند و دارای مشخصاتی مانند نام شخص حقوقی، تاریخ ثبت، شماره ثبت، کد شناسایی، کد اقتصادی، موضوع فعالیت و غیره می باشند. 
            </p>
            </div>
          
           </div>

           <div className={classnames(classes.pasokh,'pasokh')}>
            <div className={classnames(classes.awhead,'awhead')}>
            <span className={classes.span1}>
               چه کساینی میتوانند درمرکز فروشندگان دیچی کالا فروشنده شوند 
             </span>
             <span className={classnames(classes.span2,'span2')}>
               <img  src="images/pluse.jpg" className={ classnames(classes.pluse,'pluse')}/>
             </span>
            </div>

            <div className={classnames(classes.awbody,'awbody')}>
            <p className={classes.parabody}>
            مرکز فروشندگان دیجی‌کالا، پلتفرمی است که در آن فروشندگان کالاهای مختلف از جمله برند های معتبر، فروشندگان خرد و کلان، صاحبان کسب و کارهای کوچک و هر شخصی که کالایی برای عرضه دارد، می توانند به صورت آنلاین محصولات خود را در قالب فروشنده حقیقی و فروشنده حقوقی به فروش برسانند . فروشنده حقیقی: فردی است که دارای خصوصیاتی مختص به خود مانند نام، نام خانوادگی، تاریخ تولد، کد ملی، شماره شناسنامه و غیره می باشد. فروشنده حقوقی: موسسات یا شرکت هایی هستند که پس از طی مراحل قانونی به ثبت می‌رسند و دارای مشخصاتی مانند نام شخص حقوقی، تاریخ ثبت، شماره ثبت، کد شناسایی، کد اقتصادی، موضوع فعالیت و غیره می باشند. 
            </p>
            </div>
          
           </div>
          </div>


       <div style={{direction:'rtl' }}>

       <div className={classnames(classes.sellerBackground,'sellerBackground')}>

 <Typography variant="h6">با ما در ارتباط باشید </Typography>
 <div style={{ width:'460px',marginTop:'40px' }}>
 <Typography variant="body1" style={{ justifyContent:'center' }}>استفاده از مطالب فروشگاه اینترنتی دیجی‌کالا فقط برای مقاصد غیرتجاری و با ذکر منبع بلامانع است. کلیه حقوق این سایت متعلق به شرکت نوآوران فن آوازه (فروشگاه آنلاین دیجی‌کالا) می‌باشد.</Typography>

 </div>

</div>
       </div>
          

         


        </div>
    )
}
