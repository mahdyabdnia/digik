import classNames from 'classnames'
import React from 'react'
import useStyles  from './styles'
import Typography from '@material-ui/core/Typography'

export default function Succes() {
    const classes=useStyles();
    return (
        <div className={classes.container} > 
        <video className={classes.video} width="743" height="360" controls>
          <source src="https://dkstatics-public.digikala.com/digikala-video/8f22ebe991ab99a67bea64c3e6c1e059eb25558b_1604664425.MP4" type="video/mp4"/>
        </video>

        <div className={classes.intro}>
            <div className={classes.introduc}>
             <img src="images/virgol.svg" className={classes.img}/>
             <Typography variant="h6" color="initial">گلیم گلسنین</Typography>
             <Typography variant="h6" color="textSecondary">گلیم گلسنین</Typography>
             <Typography variant="body1" color="textSecondary">زنان سخت کوش گلسنین خیلی خوب کار میکنن ماهم زحماتشون آوردیم اینجا بفروشیم خیلیم عالین بخرین ببرین</Typography>
            </div>
        </div>
            
        </div>
    )
}
