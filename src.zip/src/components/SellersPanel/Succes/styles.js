import {makeStyles} from '@material-ui/core'
const useStyles =makeStyles({
container :{
    display:'flex',
    flexDirection:'row',
    height:'400px',
    width:'1144px ',
    margin:'auto',
    position:'relative',
    direction:'rtl',
    alignItems:'center'

},
video:{
    position:'absolute',
    zIndex:'2',
    width:'743px',
    height:'360px',
   backgroundColor:"black",
    right:'0%'
    


},
intro:{
    position:'absolute',
    height:'400px',
    width:'520px ',
    backgroundColor:'#f5f7fa',
    left:'0%'
},
introduc:{
    paddingRight:'200px',
    paddingTop:'100px'
},
img:{
    display:'block',
    width:'35px',
    height:'30px',
    marginBottom:'20px'
}
});

export default useStyles;