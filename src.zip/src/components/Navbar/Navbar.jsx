import React,{useState,useEffect} from 'react'; 
import {Badge,AppBar,Toolbar,Grid, Typography, Icon,IconButton, Divider, Button,Tabs,Tab,Menu,MenuItem,List,ListItem,ListItemText,ListItemIcon, ListItemSecondaryAction} from '@material-ui/core'
import useStyles from './styles'
import SearchIcon from '@material-ui/icons/Search';
import './style.css'
import classnames from 'classnames'
import ShoppingCartOutlinedIcon from '@material-ui/icons/ShoppingCartOutlined';
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';
import MenuIcon from '@material-ui/icons/Menu';
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import $ from 'jquery'

import { Clear, IsoOutlined, KeyboardReturnRounded, Visibility } from '@material-ui/icons';
import ComputerTwoToneIcon from '@material-ui/icons/ComputerTwoTone';
import {Link} from 'react-router-dom'
import {addToCart} from '../../redux'
import {connect} from 'react-redux'
import ComputerOutlinedIcon from '@material-ui/icons/ComputerOutlined';
import CreateOutlinedIcon from '@material-ui/icons/CreateOutlined';
import ArrowBackIosOutlinedIcon from '@material-ui/icons/ArrowBackIosOutlined';
import { width } from 'dom-helpers';

import FastfoodOutlinedIcon from '@material-ui/icons/FastfoodOutlined';
import { cleanup } from '@testing-library/react';

 function Navbar(props) {
    const classes=useStyles();
    const type=[{val:0,label: ' کالاهای دیجتال'},{val:1,label:' خودرو،ابزارو تجهیزات صنعتی '},
    {val:2,label:' مد و پوشاک    '},
    {val:3,label:' اسباب بازی کودک نوزاد  '},
    {val:4,label:'سوپر مارکتی '},
    {val:5,label:'زیبایی و سلامت '},
    {val:6,label:' لوازم آشپزخانه '},
    {val:7,label:'لوازم التحریر'},
    {val:8,label:'ورزش و سفر'},
    {val:9,label:'بومی محلی'},] 

    const typeInner=[
        { id:0,name:'لوازم جانبی گوشی',inner:[{id:0,name:'کیف و کاور گوشی'},{id:1,name:'پاور بانک و شارژر'},{id:2,name:'پایه نگه دارنده گوشی'}]},
        {id:1,name:'گوشی موبایل',inner:[{id:0,name:'سامسونگ'},{id:1,name:'هوآوی'},{id:2,name:'شیائومی'},{id:3,name:'اپل'}   ]  },
        { id:2,name:'لوازم جانبی گوشی',inner:[{id:0,name:'کیف و کاور گوشی'},{id:1,name:'پاور بانک و شارژر'},{id:2,name:'پایه نگه دارنده گوشی'}]},
        {id:3,name:'گوشی موبایل',inner:[{id:0,name:'سامسونگ'},{id:1,name:'هوآوی'},{id:2,name:'شیائومی'},{id:3,name:'اپل'}   ]  },
        
        { id:4,name:'لوازم جانبی گوشی',inner:[{id:0,name:'کیف و کاور گوشی'},{id:1,name:'پاور بانک و شارژر'},{id:2,name:'پایه نگه دارنده گوشی'}]},
        {id:5,name:'گوشی موبایل',inner:[{id:0,name:'سامسونگ'},{id:1,name:'هوآوی'},{id:2,name:'شیائومی'},{id:3,name:'اپل'}   ]  },
        { id:6,name:'لوازم جانبی گوشی',inner:[{id:0,name:'کیف و کاور گوشی'},{id:1,name:'پاور بانک و شارژر'},{id:2,name:'پایه نگه دارنده گوشی'}]},
        {id:7,name:'گوشی موبایل',inner:[{id:0,name:'سامسونگ'},{id:1,name:'هوآوی'},{id:2,name:'شیائومی'},{id:3,name:'اپل'}   ]  },
        
        

    ]
   
     
     const TAB1=1;
     const [value, setValue] = useState(type[0].val);
     const openAndClose=()=>{
         $(document).ready(function(){
            $('.navbar .nav-item').hover(
                      function() {
                        $('.nav-dropmenu', this).stop().show().css({display:'inline-flex'});
                      },
                      function() {
                        $('.nav-dropmenu', this).stop().hide();
                      }
                
                    );

         });
     }

     const close=()=>{
         $(document).ready(function(){
           $('.close').click(function(){
             $('.navbar li ul').stop().slideDown();
           });
         });
     }
  

 

  const handleChange=(event,newValue)=>{
      setValue(newValue);
  }
 

  useEffect(() => {
      const scrt=()=>{
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 30) {
          
            document.getElementsByClassName('toolBar')[0].style.overflow="hidden"
             document.getElementsByClassName('toolBar')[0].style.height="70px"
             document.getElementsByClassName('toolBar')[0].style.transition="0.5s"
      }
      else{
        document.getElementsByClassName('toolBar')[0].style.overflow="initial"
        document.getElementsByClassName('toolBar')[0].style.height="120px";
        document.getElementsByClassName('toolBar')[0].style.transition="0.5s"
      }
      }
      window.addEventListener('scroll',scrt);
      return () => {
        window.removeEventListener('scroll',scrt);
      }
  }, [])
   
  useEffect(() => {
      openAndClose();
       
      close();
      return () => {
  
    }
  }, []);
    return (
        <AppBar position={'sticky'} color="inherit" className={classes.appBar}>
            <Toolbar className={classnames(classes.toolBar,'toolBar')}>
                <Grid item container className={classes.tools}>
                    <Grid item container   style={{ flex:'1119',height:'90%',margin:'auto',flexWrap:'wrap',display:'flex',flexDirection:'row-reverse' }}>

                        <Grid item container  style={{ width:'11%' }}>
                            <Link  to="/" style={{ textDecoration:'none' }}>
                            <Typography variant="h4" color="secondary">digikala </Typography>
                            </Link>
                            
                            </Grid>
                            <div className={classes.searchBar}>
                             <span>
                                <SearchIcon/>
                             </span>
                             <input className={classnames(classes.searchInput,'searchInput')} placeholder="جستجو در  دی جی کالا"/>
                                
                            </div>
                                <Grid item container  style={{ width:'22%'}}></Grid>

                                


                    
                    </Grid>
                    <Grid item container style={{ flex:'370',height:"50%" }} alignItems="center"><Link to="/cart">
                    <Badge color="secondary" badgeContent={props.cartnum}>
                       
                    <ShoppingCartOutlinedIcon/>
                    </Badge> </Link>
                    <Divider orientation="vertical" style={{marginRight:'10px',marginLeft:"10px"}}/>
                    <Link to="/login">

                    <Button variant="outlined"  size="large" endIcon={<PersonOutlineOutlinedIcon style={{marginRight:'-10px'}}/>}>
                    ورود به حساب کاربری
                   </Button>
                    </Link>
                   
                    </Grid>
                
                
                </Grid>
                <Grid item container className={classnames(classes.navbar,'navbar')}>
                  <ul className={classnames('nav')}>
                      <li className={classnames('nav-item',classes.navItem)}>
                          <a style={{ display:'flex',alignItems:'center',direction:'ltr' }}>همه دسته بندی کالاها<Icon><MenuIcon/></Icon></a>
                           <ul dir="rtl" className={classnames(classes.tabs,'nav-dropmenu')}>
                            <li className={classes.tab}>
                            {type.map((item,index)=>{
                                       return(<>
                                       {value===index &&
                                     <div className={classes.sideNav}>
                                     <div className={classes.sideNavItemHover} onMouseOver={()=>setValue(index)}> <span className={classes.span1}><ComputerOutlinedIcon/></span> <Typography variant="body1"> {item.label} </Typography>   </div>

                                    </div>
                                    }
                                       {value!==index &&
                                        <div className={classes.sideNav}>
                                        <div className={classes.sideNavItem} onMouseOver={()=>setValue(index)}> <span className={classes.span1}><ComputerOutlinedIcon/></span> <Typography variant="body1"> {item.label} </Typography>   </div>

                                       </div>
                                    }
                                    
                                       
                                      
                                       
                                       
                                       
                                     </>  )
                                   })

                                   }
                             
                            </li>

                            <li className={classes.tabItem}>
                              
                         
                           {type.map((item,index)=>{
                                     return(
                                         <>
                                         {
                                             value===index &&
                                             <>
                                             <div><Link className={classnames('close')} to={'/category'}>
                                             <Typography variant="body1" style={{display:'inline-flex',alignItems:'center'} }>همه دسته بندی های {item.label} <span><ArrowBackIosIcon style={{fontSize:"15px"}}/></span></Typography>
                                         </Link></div>
                                         <div className={classes.cate}>
                                           <ul className={classes.ulul}>
                                               {
                                                   typeInner.map((item)=>{
                                                       return(<><li className={classes.ulliH}>{item.name}</li>
                                                       {item.inner.map((obj)=>{
                                                           return(
                                                            <li className={classes.ulli}> {obj.name} </li>
                                                           )
                                                       })}
                                                       
                                                       </>)
                                                   }
                                                    ) }
                                              
                                              
                                              

                                          
                                             
                                           </ul>
                                         </div>
                                          </>   
                                             
                                         }
                                          {
                                             value!==index &&
                                             <>
                                            
                                          </>   
                                             
                                         }
                                       
                                         </>
                                     )
                                 })}
                         

                          
                                                  
                          
                           
                             
                            </li>



                              

                           </ul>
                      </li>
                      <li className={classnames('nav-item',classes.navItem)}>
                          <Link to="/supermarket" style={{ display:'flex',alignItems:'center',justifyContent:'space-around' }}> <span style={{ marginLeft:'5px' }}><FastfoodOutlinedIcon/> </span> سوپر مارکت  </Link>
                      </li>
                      <li className={classnames('nav-item',classes.navItem)}>
                          <Link to="/sellersPanel">فروشنده شوید</Link>
                      </li>
                  </ul>

                </Grid>

                
            
            </Toolbar>
        </AppBar>
    )
}

const mapStateToProps=(state)=>{
    return{
        cartnum:state.cartnum
    }
}



export default connect(mapStateToProps,null)(Navbar);
