import {makeStyles } from '@material-ui/core'
import { BorderLeft } from '@material-ui/icons';
const useStyles =makeStyles({
toolBar:{
    display:'flex',
    flexDirection:'column',
    height:'120px',
   OverflowX:'hidden'
   
}, 
appBar:{
   
} 
,
searchInput:{
    outline:'none',border:'none', backgroundColor:'#f0f0f1',marginRight:'20px',
    display:'block-inline',
    width:'100%',
    '$:focus':{
        outline:'none',border:'none'
    }

}
,
searchBar:{
    width:"66%",
    direction:'rtl',
    alignItems:'center',
    display:'flex',
    flexDirection:'row',
    backgroundColor:'#f0f0f1',
    borderRadius:'5px',
    height:'50px',
    marginRight:'20px'

}
,

navbar:{
    flex:'46',
    display:'flex',
    direction:'rtl',
    flexDirection:'row'
    
},
tools:{
    flex:'74',
    display:'flex',
    flexDirection:'row-reverse',
    marginTop:'10px'
},
tabs:{
    display:'inline-flex',
    marginTop:'20px'
    
    
    
},
tab:{ 
    width:'13%',
   display:'block',
   height:'100%',
   borderLeft:'1px solid #f5f5f5',
   
  
},
tabItem:{
    width:'85%',
    display: 'block-flex',
    height:'100%',
    flexDirection:'column'
    
    
},
tabAll:{
  display:'flex',
  flexDirection:'column'

},
sideNav:{
    display:'inline-flex',
    flexDirection:'column',
    flexWrap:'wrap'
    
},
sideNavItem:{
   
    display:"flex",

    marginRight:'-50px',
    width:'220px',
    
    padding:'11px 10px 11px 0',
    
},
sideNavItemHover:{
   
    display:"flex",

    marginRight:'-50px',
    width:'220px',
    
    padding:'11px 10px 11px 0',
    color:'#ee384e',
    backgroundColor:'#f0f0f1'
},
span1:{
    marginLeft:'10px'
},
ulHeader:{
    display:'inline-flex',
    flexDirection:'row',
    alignItems:'center'
},
cate:{
marginTop:'20px',


paddingBottom:'60px',
display:'flex',
flexDirection:'column',
flexWrap:'wrap',
minWidth:'284px',
width:'auto',
height:'90%'



},

close:{
height:'10%'
},
ulul:{
    display:'flex',
    flexDirection:'column',
    width:'100%',
    listStyleType:'none',
   
    marginRight:'-40px',
    flexWrap:'wrap',
    height:'100%',
    overflow:'hidden'
},
ula:{
    display:'flex',
    alignItems:'center',
    flexDirection:'row',
    fontSize:'16px',
    fontWeight:'bold'
},
arrow:{
    fontSize:'16px',

},
ulli:{
    lineHeight:'20px',
    opacity:'0.8',
    marginRight:"-1px",
    fontSize:"14px",
    width:'20%',
    cursor:'pointer',
    
    '&:hover':{
        color:'red'
}},
ulliH:{
    lineHeight:'20px',
    opacity:'1',
    marginRight:"-1px",
    fontSize:"15px",
    fontWeight:'bold',
    width:'20%',
    paddingRight:'10px',
    borderRight:'3px solid red',
    '&:hover':{
        color:'red'
    },
    cursor:'pointer'
},





});


export default useStyles;