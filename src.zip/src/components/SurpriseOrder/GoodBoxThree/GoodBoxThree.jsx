import React from 'react'
import useStyles from './styles'
import { Typography } from '@material-ui/core';
export default function GoodBoxTwo() {
    const classes=useStyles(); 
    return (
        <div className={classes.container}>
            <div className={classes.header}> 
            <Typography variant="body1" style={{ textAlign:'right',marginRight:'20px' }}>پیشنهاد شگفت انگیز</Typography>
             </div>
            <div className={classes.imgBox}>
                <img src="images/ghab.jpg" className={classes.img} alt="" />
            </div>
            <div className={classes.titleBox}>
            <Typography variant="body1" className={classes.name}>زودپز دوقلو ماتریکس</Typography>
            <span className={classes.offBox}>
                <span className={classes.offPer}>25%</span>
                <span className={classes.off}>755000</span>
            </span>
            <h3 style={{ marginLeft:'20px' }}>50000 تومان</h3>
            <div className={classes.bar}>
                <div className={classes.barPercent}></div>
            </div>
            <div className={classes.bottomBox}>
                <span className={classes.right}>
                    <span className={classes.percent}>15%</span>
                    <span className={classes.selled}>فروش رفته </span>
                </span>
                 <span className={classes.left}>
                     <img src="images/clock2.jpg" className={classes.clock}/>
                     <span className={classes.selled}>12:20:30</span>
                     </span>   
            </div>

            </div>
          

            
        </div>
    )
}
