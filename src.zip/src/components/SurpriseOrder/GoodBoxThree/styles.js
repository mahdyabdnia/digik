import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({
container:{
    width:'301px',
    height:'430px',
    display:'flex',
    flexDirection:'column',
   border:'1px solid #ececed',
    backgroundColor:'white',
    '&:hover':{
        boxShadow:'0px 0px 10px 10px #f4f4f4'
    }
},
header:{ 
height:'50px ',
color:'red',
fontSize:'15px',
display:'flex',
alignItems: 'center',
direction:'rtl',
marginTop:'15px'



},
titleBox:{
height:'100%'
},
imgBox:{
height:'200px'
},
img:{
    width:'180px',
    height:'180px',
    display:'block',
    margin:'auto'
}



,
name:{
    color:'#616161',
    textAlign:'right',marginRight:'10px',
    marginBottom:'40px'
},
offBox:{
    display:'flex',
    flexDirection:'row',
    direction:'ltr',
    alignItems: 'center',
},
offPer:{
    color:'white',
    backgroundColor:'red',
    display:'flex',
    alignContent:'center',
    justifyItems:'center',
    borderRadius:'20px',
    height:'20px',
    fontSize:'15px',
    padding:'5px 10px',
    margin:'0px 10px'
},
off:{
    textDecoration:'solid line-through #c6c6c6',
    color:'#c6c6c6',
    fontSize:'18px'
},
bar:{
    height:'5px',
    backgroundColor:'#e2e2e2',
    width:'90%',
    margin:'auto'

},
barPercent:{
    height:'5px',
    zIndex:'20',
    backgroundColor:'red',
    width:'80%'
},
bottomBox:{
    display:'flex',
    alignItems: 'center',
    justifyItems:'space-between',
    height:'30px',
    direction:'rtl',
    padding:'10px 8px 0px 8px',
},
right:{
    display:'flex',
    alignItems: 'center',
    direction:'rtl',
    width:'50%'
},
percent:{
fontSize:'15px',
color:'red'
},
selled:{
    fontSize:'15px',
    color:'#818181'

},
left:{
    display:'flex',
    alignItems: 'center',
    direction:'ltr',
    width:'50%'
},
clock:{
    width:'25px',
    height:'25px'
}

});
export default useStyles;