import React,{useEffect} from 'react'
import useStyles from './styles'
import BallotOutlinedIcon from '@material-ui/icons/BallotOutlined';
import LaptopChromebookOutlinedIcon from '@material-ui/icons/LaptopChromebookOutlined';
import BuildOutlinedIcon from '@material-ui/icons/BuildOutlined';
import PermIdentityOutlinedIcon from '@material-ui/icons/PermIdentityOutlined';
import FaceOutlinedIcon from '@material-ui/icons/FaceOutlined';
import FavoriteBorderOutlinedIcon from '@material-ui/icons/FavoriteBorderOutlined';
import WeekendOutlinedIcon from '@material-ui/icons/WeekendOutlined';
import CreateOutlinedIcon from '@material-ui/icons/CreateOutlined';
import AirportShuttleOutlinedIcon from '@material-ui/icons/AirportShuttleOutlined';
import classnames from 'classnames'
import Carousel from 'react-elastic-carousel'
import './style.css'
import GoodBox from './GoodBox/GoodBox';
import GoodBoxTwo from './GoodBoxTwo/GoodBoxTwo';
import GoodBoxThree from './GoodBoxThree/GoodBoxThree'
import SortIcon from '@material-ui/icons/Sort';
export default function GoodOrder() {
    useEffect(() => {
       var tab=document.getElementsByClassName('tab');
       var i;
       for(i=0;i<tab.length;i++){
           tab[i].addEventListener('click',function(){
             var tabs=document.getElementsByClassName('tab');
             var j;
             for(j=0;j<tabs.length;j++){
                 tabs[j].classList.remove('selectedTab');
                 tabs[j].classList.add('tab')
                 
             }
             this.classList.add('selectedTab');
           })
       }
        return () => {
          
        }
    }, [])
   useEffect(() => {
       var item=document.getElementsByClassName('sortItem');
       var i;
       for(i=0;i<item.length;i++){
           item[i].addEventListener('click',function(){
               var it=document.getElementsByClassName('sortItem');
               var j;
            for(j=0;j<it.length;j++){
                it[j].classList.remove('selectedSort');
                it[j].classList.add('sortItem');
            }
            this.classList.add('selectedSort')
           })
       }
   }, []);

    useEffect(() => {
        var red=document.getElementsByClassName('red')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#ef5461";
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur1.png"

        })
    }, []);
    useEffect(() => {
        var red=document.getElementsByClassName('blue')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#5d52c1";
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur2.png"
         

        })
    }, []);
   
    useEffect(() => {
        var red=document.getElementsByClassName('orange')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#d95d26"    
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur3.png"
        })
    }, []);
    useEffect(() => {
        var red=document.getElementsByClassName('lightOrange')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#ea8361"  
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur4.png"  

        })
    }, []);

    useEffect(() => {
        var red=document.getElementsByClassName('pink')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#df3360"   
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur5.png" 

        })
    }, []);
    useEffect(() => {
        var red=document.getElementsByClassName('purple')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#b71aed"    
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur6.png"

        })
    }, []);
    useEffect(() => {
        var red=document.getElementsByClassName('green')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#009eb0"  
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur7.png"  

        }) 
    }, []);
    useEffect(() => {
        var red=document.getElementsByClassName('yellow')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#fa8817"
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur8.png"    

        })
    }, []);
    useEffect(() => {
        var red=document.getElementsByClassName('darkBlue')[0];
        red.addEventListener('click',function(){
         var box=document.getElementsByClassName('box')[0];
         box.style.backgroundColor="#1895c0"
         var img=document.getElementsByClassName('srimg')[0];
         img.src="http://localhost:3000/images/sur9.png"    

        })
    }, []);

    
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <img src="images/bnn.jpg" alt="" />
            <div className={classnames(classes.tabCarouselBox,'box')}>
              <h1 className={classes.header}>پشینهاد شگفت انگیز</h1>
              <div className={classes.tabs}>
                  <div className={classnames(classes.tab,'selectedTab','tab','red')}>
                <BallotOutlinedIcon className={classes.icon}/>
                    <h3 className={classes.header}>همه دسته بندی ها </h3>
                      
                  </div>
                  <div className={classnames(classes.tab,'tab','blue')}>
                      <LaptopChromebookOutlinedIcon className={classes.icon}/>
                      <h3 className={classes.header}>کالاهای دیجیتال</h3>
                  </div>
                  <div className={classnames(classes.tab,'tab','orange')}>
                      <BuildOutlinedIcon className={classes.icon}/>
                      <h3 className={classes.header}>خودرو ابزار آلات صنعتی</h3>
                  </div>
                  <div className={classnames(classes.tab,'tab','lightOrange')}>
                      <PermIdentityOutlinedIcon className={classes.icon}/>
                      <h3 className={classes.header}>مد و پوشاک</h3>
                  </div>
                  <div className={classnames(classes.tab,'tab','pink')}>
                      <FaceOutlinedIcon className={classes.icon}/>
                      <h3 className={classes.header}>اسباب بازی کودک و نوزاد</h3>
                  </div>
                  <div className={classnames(classes.tab,'tab','purple')}>
                      <FavoriteBorderOutlinedIcon className={classes.icon}/>
                      <h3 className={classes.header}>زیبایی و سلامت </h3>
                  </div>
                  
                  <div className={classnames(classes.tab,'tab','green')}> 
                  <WeekendOutlinedIcon className={classes.icon}/>
                  <h3 className={classes.header}> خانه و آشپزخانه</h3>
                  </div>
                  
                  <div className={classnames(classes.tab,'tab','yellow')}>
                      <CreateOutlinedIcon className={classes.icon}/>
                      <h3 className={classes.header}>لوازم و تحریر</h3>
                  </div>

                  <div className={classnames(classes.tab,'tab','darkBlue')}>
                   <AirportShuttleOutlinedIcon className={classes.icon}/>
                   <h3 className={classes.header}>ورزش و سفر</h3>

                  </div>
              </div>
              
              <div className={classes.carouselBox}>
                  <div className={classes.headerBox}>
                      <img src="images/header.svg" alt="" />
                      <img src="images/sur1.png" className='srimg' alt="" />
                  </div>
                  
                      <div className={classes.carousel}>
                        <Carousel itemsToShow={5} itemsToScroll={5}>
                            <GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/><GoodBox/>
                        </Carousel>
                      </div>
                  
                  

              </div>
 

            </div>
            <div className={classes.toEnd}>
                <div className={classes.endHeader}>
                    <img src="images/clock.jpg" className={classes.endImg}/>
                    <h3>شگفت انگیز های روبه اتمام</h3>
                </div>
                <div className={classes.endCarousel}>
                    <Carousel itemsToScroll={5} itemsToShow={5}>
                        <GoodBoxTwo/>
                        <GoodBoxTwo/> 
                         <GoodBoxTwo/>  
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                         <GoodBoxTwo/> 
                    </Carousel>
                </div>
            </div>

            <div className={classes.all}>
                <h3 style={{ marginRight:'20px',marginTop:'10px' }}>همه شگفت انگیزها</h3>
                <div className={classes.sortBox}>
                    <span style={{ marginLeft:'10px' }}><SortIcon/></span>
                    <span>مرتب سازی براساس:</span>
                    <span className={classes.sortsItems}>
                        <span className={classnames(classes.sortItem,'sortItem','selectedSort')}>پرفروش ترین</span> 
                        <span className={classnames(classes.sortItem,'sortItem',)}>پرفروش ترین</span> 
                        <span className={classnames(classes.sortItem,'sortItem',)}>پرفروش ترین</span>
                      
                    </span>
                </div>
                <div className={classes.goods}>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                    <GoodBoxThree/>
                </div>
            </div>
        </div>
    )
}
