import React from 'react'
import useStyles from './styles'
import { Typography } from '@material-ui/core';
export default function GoodBox() {
    const classes=useStyles();
    return (
        <div className={classes.container}>
            <div className={classes.imgBox}>
                <img src="images/goodOrg.jpg" alt="" className={classes.img} />
            </div>
            <div className={classes.titleBox}>
                <Typography variant="body1" className={classes.name}>گوشی موبایل اپل مدل iphone x pro2 ظرفیت 320 گیگابایت</Typography>
                <span className={classes.offBox}><span className={classes.offPer}>25%</span><span className={classes.off}>500000</span></span>
          <h3 style={{ marginLeft:'20px' }}>50000 تومان</h3>
                   
            </div>
        </div>
    )
} 
