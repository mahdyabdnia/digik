import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({
container:{
    width:'255px',
    height:'434px',
    display:'flex',
    flexDirection:'column',
    justifyContent:'flex-start',
    backgroundColor:'white',
    borderRadius:'10px',
    marginLeft:'5px'
},
imgBox:{
    height:'50%',
    width:'100%',

},
img:{
    display:'block',
    margin:'30px auto 10px auto',
    width:'180px', 
    height:'180px'
},
titleBox:{
    height:'50%',
    display:'flex',
    flexDirection:'column',

},
name:{
    color:'#616161',
    textAlign:'right',marginRight:'10px',
    marginBottom:'40px'
},
offBox:{
    display:'flex',
    flexDirection:'row',
    direction:'ltr',
    alignItems: 'center',
},
offPer:{
    color:'white',
    backgroundColor:'red',
    display:'flex',
    alignContent:'center',
    justifyItems:'center',
    borderRadius:'20px',
    height:'20px',
    fontSize:'15px',
    padding:'5px 10px',
    margin:'0px 10px'
},
off:{
    textDecoration:'solid line-through #c6c6c6',
    color:'#c6c6c6',
    fontSize:'18px'
}

});
export default useStyles;