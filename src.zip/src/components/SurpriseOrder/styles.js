import { makeStyles } from "@material-ui/core";
const useStyles=makeStyles({
container:{
    display:'flex',
    flexDirection:'column',
    direction:'rtl',
    backgroundColor:'white',
    height:'auto'
},
tabCarouselBox:{
    display:'flex',
    flexDirection:'column',
    backgroundColor:'#ef4657',
    width:'100%',
    height:'auto',

},
header:{
    textAlign:'center',
    color:'white'
},
tabs:{
    display:'flex',
    flexDirection:'row',
    padding:'0px 30px',
    justifyContent:'center',
    alignItems: 'center',
},
tab:{
    display:'flex',
    flexDirection:'column',
    justifyContent:'center',
    alignItems:'center',
    width:'12.5%',
    color:'white',
    height:'100px',
   
},
icon:{
    fontSize:'35px !important'
},
carouselBox:{ 
    display:'flex',
    flexDirection:'row',
    justifyContent:'flex-start',
    padding:'30px 0px',height:'444px',

},
headerBox:{
    display:'flex',
    flexDirection:'column',
    alignItems: 'center',
    justifyContent:'center',
    width:'12%',
},
carousel:{ 
    width:'88%'
},
toEnd:{
    display:'flex',
    flexDirection:'column',
    borderRadius:'10px',
    border:'1px solid #e3e3e5',
    width:'98%',
    margin:'15px auto 15px auto',
    
    backgroundColor:'white'
},
endHeader:{
    display:'flex',
    alignItems: 'center',
    borderBottom:'5px solid red',
    width:'240px',
   
    overflowX:'visible'
},
endImg:{
    display:'block',
    width:'25px',
    height:'25px',
    marginLeft:'5px',
    marginRight:'10px'
},
endCarousel:{
    width:'100%',
    height:'441px',
    backgroundColor:'white',
    marginTop:'20px'
},
all:{
    display:'flex',
    flexDirection:'column',
    direction:'rtl'
},
sortBox:{
    display:'flex',
    flexDirection:'row',
    marginTop:'20px',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginRight:'20px'
},
sortItems:{
    display:'flex',
    flexDirection:'row',
  
},
sortItem:{
    margin:'0px 20px 0px 0px',
    color:'#94989d'
},
goods:{
    display:'flex',
    flexDirection:'row',
    flexWrap:'wrap',
    
}
});

export default useStyles;