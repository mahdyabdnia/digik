import {makeStyles}from '@material-ui/core'
const useStyles=makeStyles({
contianer:{
    width:'auto',
    display:'flex',
    flexDirection:'column',
    padding:"0px 20px",
    direction:'rtl',
    backgroundColor:'white',
    height:'auto',
    minHeight:'1000px'
},
broadcampBox:{
    height: '40px',
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center'
},
broadcamp:{
    display:'inline-flex',
    listStyleType:'none',
    padding:'0px'

},
broadcampLi:{
    display:'inline',
    fontSize:'15px',
    color:'#777777',
    
},
broadcampLit:{
    display:'inline',
    fontSize:'15px',
    color:'#777777'
},
row:{
    display:'flex',
    flexDirection:'row',
    
    width:'100%'
 
},
gallary:{
    display:'flex',
   
    minHeight:'500px',
    width:'35%',
    flexDirection:'column'
    
},
contentBox:{
   minHeight:'500px',
   height:'auto',
   width:'65%',
  

},
imgBox:{
    display:'flex',
    flexDirection:'row'
},
imgToolbar:{
    display:'flex',
    flexDirection:'column',
    width:'24px',
    height:'392px'
},
toolList:{
    padding:'0px',
    listStyleType:'none'
},
toolLi:{
marginBottom:'15px'
},

iconButton:{
    padding:'0px'
},
icon:{
    color:'black'
},img:{
    height:'392px',
    width:'100%'
},
imgList:{
    display:'flex',
    flexDirection:'row',
    position:'relative',
    height:'87px',
    flexWrap:'wrap',justifyContent:'space-around',
    overflow:'hidden'
},
imgWrapper:{
    display:'inline-flex',
    border:'#e3e3e3 1px solid',
    borderRadius:'10px',
  width:'85px',
  height:'85px',
   marginLeft:'5px',
   position:'relative'
},
imgth:{
    height:'76px',width:'76px',
    display:'block',
    margin:'auto',
    opacity:'0.5',
    '&:hover':{
        opacity:'1'
    }
},
iconButtonTwo:{
    position:'absolute',
    padding:'0px',
    top:'40%',
    right:'40%',
    zIndex:'10',
    backgroundColor:'#797878',
    opacity:'1',
    '&:hover':{
        opacity:'1'
    },
    borderRadius:'50%',
    outline:'none',
    border:'none'
},
contentBody:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-around',
    marginTop:'5px'
},
productDetail:{
    width:'62%',
    minHeight:'300px'
},

property:{
    display:'flex',
    flexDirection:'column'
},
spic:{
    listStyleType:'disc',
    padding:'0px',
    
},
spicLi:{
    color:'#a1a1a1',
    fontSize:'16px'
},buyConfig:{
    width:'37%',
    minHeight:'206px',
    height:'auto',
    maxHeight:'420px',
    display:'flex',
    flexDirection:'column',
    backgroundColor:'#f5f5f5',
    borderRadius:'15px',
    border:'1px solid #f6f6f6'
},
productSeller:{
    margin:'10px 0px',
    padding:'0px 15px',
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between',
    cursor:'pointer'
},seller:{
    height:'73px',
    display:'flex',
    flexDirection:'row',
    padding:'0px 10px',
    alignItems:'center'
},
sellerIcon:{
width:'10%'
},
sellerNameBox:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between',
    height:'50%',
    width:'100%'
},
sellerGrid:{
display:'flex',
flexDirection:'row',
alignItems:'center',
height:'50%',
width:'100%'
},
sellerBox:{
    display:'flex',
    flexDirection:'column',
    width:'100%',
    height:'100%',
    borderBottom:'1px solid #e2e2e2'
},
verifyGood:{
    display:'flex',
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'flex-start',
    height:'50px',
    padding:'0px 10px'
},verify:{
    display:'flex',

    flexDirection:'row',
    alignItems:'center',
    width:'100%',
    height:'100%',  borderBottom:'1px solid #e2e2e2'
},
sendBox:{
    display:'flex',
    flexDirection:'column',
    padding:'10px'
},
isStock:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between'
},
stockUl:{
    padding:'0px',
    marginRight:'15px',
    margin:'0px auto',borderBottom:'1px solid #e2e2e2',
    width:'90%',
    marginLeft:'0px'
},
price:{
    display:'flex',
    padding:'10px 20px 10px 20px',
    direction:'ltr'
},
eye:{
    display:'flex',
    alignItems:'center',
    opacity:'0.5',
    padding:'10px',
    fontSize:'12px'
},
addToCart:{
    padding:"20px",
    marginBottom:'40px'
},
button:{
    width:'100%',
    backgroundColor:'#ef394e',
    height:'125%'
},
wage:{
    width:'auto',
    maxWidth:'100%',
    borderRadius:'5px',
    border:'1px solid #fcbdc4',
    padding:'10px 10px 10px 0px',
    position:'relative',
    overflow:'hidden'
},
wageHead:{
    fontSize:'20px',
    fontWeight:'700',
    color:'#ef4056',
    marginBottom:'20px'
},
digiHead:{
    fontSize:'15px',
    fontWeight:'700',
    color:'black',
    
},
wageImg:{
    position:'absolute',
    width:'145px',
    
    top:'5px',
    left:'-30px',

},
digipluse:{
    width:'auto',
    maxWidth:'100%',
    borderRadius:'5px',
    border:'1px solid #fcbdc4',
    padding:'10px 10px 10px 0px',
    position:'relative',
    overflow:'hidden',
    marginTop:'20px'
},
freeImg:{
    position:'absolute',
    top:'2px',
    left:'2px',
    width:'35%',
    height:'100%'
},
free:{

    paddingBottom:'20px',
    paddingRight:'20px'
},
rowTwo:{
    display:'flex',
    flexDirection:'column'
},
sellersBox:{
    display:'flex',
    flexDirection:'column'
},
sellersInfo:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-around',
    marginTop:'30px',
    direction:'rtl',
    padding:'5px 20px  15px 20px',
    borderBottom:'1px solid #ebebec'
},
info:{
    width:'20%',
    display:'flex',
    flexDirection:'row',alignItems:'center'
},
infoC:{
    width:'20%',
    display:'flex',
    flexDirection:'row',alignItems:'center',
    justifyContent:'center'
},
digiInfo:{
    marginLeft:'10px'
},
spanInfo:{
    transform:'scaleX(-1)',color:'red',marginLeft:'10px'
},
spanInfo1:{
    marginLeft:'10px'
},
infoL:{
    width:'20%',
    display:'flex',
    flexDirection:'row',alignItems:'center',
    justifyContent:'flex-end'
},
rowThree:{
    display:'flex',
    justifyContent:'space-between',
    position:'relative',
},
des:{
    width:"77%",
    marginBottom:'20px'

},

desHeader:{
    display:'flex',
    flexDirection:'row',
    borderBottom:'1px solid #ebebec',
    justifyContent:'flex-start',
    alignItems: 'center',
    paddingTop:'30px',
    paddingBottom:'20px'

},
desHeaderItem:{
width:'10%',

},
desHeaderItemTitle:{
    fontFamily:'600',
    fontSize:'15px',
    color:'#728392',
    textDecoration:'none'
},
miniBuy:{
    width:'20%',
    border:'1px solid #ebebec',
    padding:'10px',
    paddingTop:'40px',
    marginTop:'10px',
    display:'flex',
    flexDirection:'column',
    borderRadius:'10px'
},
miniBuyName:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'space-between',
    borderBottom:'1px solid #ebebec',
    paddingBottom:'20px',
    marginBottom:'20px'
},
miniImg:{
    display:'block',
    width:'80px',
    height:'80px'
},
miniIcon:{
    display:'flex',
    alignItems:'center',
    padding:'5px 10px 5px 0px'
},
icon:{
    width:'30px',
    height:'22px',
    display:'block'

},
mini:{
    fontSize:'20px'
},
article:{
    paddingTop:'20px',
    paddingRight:'20px',
    borderBottom:'1px #f3f3f3 solid',
    paddingBottom:'20px'
},
line:{
    width:'80px',
    height:'3px',
    backgroundColor:'red',
    marginTop:'5px',
    marginBottom:'20px'
},
options:{
    display:'flex',
    flexDirection:'row',
},
optionsUl:{
    margin:'0px',
    padding:'0px',
    listStyleType:'none',
    width:'100%'
},
optionLi:{
    padding:'13px'
},
optionSpanOne:{
    width:'25%',display:'inline-block',color:'#b2b4b8'
},
optionSpanTwo:{
    dispaly:'inline-block' ,width:'75%'

},
modal:{
    display:'none',
    overflowY:'auto',
    overflowX:'hidden',
    position:'fixed',
    width:'100%',
    height:'100%',
    zIndex:'500000',
    backgroundColor:'rgb(0,0,0)',
    backgroundColor:'rgba(0,0,0,0.4)'
},
modalContent:{
    width:'60%',
    backgroundColor:'white',
    borderRadius:'10px',
    maxHeight:'1000px',
    height:'auto',
    margin:'auto',
    position:'absolute',
    top:'5%',
    left:'20%',
    display:'flex',
    flexDirection:'column'
    
},
modalContentHeader:{
    display:'flex',
    direction:'rtl',
    justifyContent:'space-between',
    padding:'15px 20px',
    borderBottom:'1px solid #ebebeb',
    alignItems:'center'

},
close:{
cursor:'pointer'
},
modalTab:{
    padding:'0px 10px 15px 10px ',
    color:'#747880',
    fontSize:'16px',
    fontWeight:'500'

},
modalContentBody:{
    padding:'10px 20px',
    display:'flex',
    flexDirection:'row',
    position: 'relative',

},
modalImg:{
    width:'529px',
    height:'529px',
    display:'block',
    position:'absolute',
    right:'20px',
    top:'10px'
},
galleryInfo:{
    height:'529px',
    width:'300px',
    overflowY:'scroll',
   direction:'ltr',
   display:'flex',
   flexDirection:'column',
   marginLeft:'20px'
},
imgInfoBox:{
    display:'flex',
    flexDirection:'row',
    flexWrap:'wrap',

},
infoDiv:{
    width:'64px',
    height:'64px',
    borderRadius:'5px',
    border:'1px solid #ebebeb',
    display:'flex',
    margin:'5px 0px 0px 5px',
    cursor:'pointer'
},
infoImg:{
    width:'58px',
    height:'58px',
    display:'block',
    margin:'auto'
}



});
export default useStyles;