import React,{useEffect,useState} from 'react'
import useStyles from './styles'
import './style.css'
import classnames from 'classnames'
import StoreMallDirectoryOutlinedIcon from '@material-ui/icons/StoreMallDirectoryOutlined';
import FavoriteBorderOutlinedIcon from '@material-ui/icons/FavoriteBorderOutlined';
import ShareOutlinedIcon from '@material-ui/icons/ShareOutlined';
import TimelineOutlinedIcon from '@material-ui/icons/TimelineOutlined';
import CompareOutlinedIcon from '@material-ui/icons/CompareOutlined';
import TocOutlinedIcon from '@material-ui/icons/TocOutlined';
import NotificationsActiveOutlinedIcon from '@material-ui/icons/NotificationsActiveOutlined';
import {IconButton, Typography,Divider,Button} from '@material-ui/core'
import MoreHorizOutlinedIcon from '@material-ui/icons/MoreHorizOutlined';
import ThumbUpAltOutlinedIcon from '@material-ui/icons/ThumbUpAltOutlined';
import ErrorOutlineOutlinedIcon from '@material-ui/icons/ErrorOutlineOutlined';
import StarIcon from '@material-ui/icons/Star';
import StorefrontIcon from '@material-ui/icons/Storefront';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import VerifiedUserOutlinedIcon from '@material-ui/icons/VerifiedUserOutlined';
import NavigateBeforeOutlinedIcon from '@material-ui/icons/NavigateBeforeOutlined';
import StorefrontOutlinedIcon from '@material-ui/icons/StorefrontOutlined';
import LocalShippingOutlinedIcon from '@material-ui/icons/LocalShippingOutlined';
import VisibilityOutlinedIcon from '@material-ui/icons/VisibilityOutlined';
import CloseIcon from '@material-ui/icons/Close';
import { CloseSharp } from '@material-ui/icons';
export default function Good() {
  const [mdState, setMdState] = useState(0)
  const selectTab=()=>{
    var mdTab=document.getElementsByClassName('modalTab');
  
    var i;
    var j;
    for(i=0;i<mdTab.length;i++){
      mdTab[i].addEventListener('click',function(){
        
      
      for(j=0;j<mdTab.length;j++){
       mdTab[j].classList.remove('selectedtab');

      }
      this.classList.add('selectedtab');
      
     
      });
    }
  }

  const changeImg=()=>{
    var infoImg=document.getElementsByClassName('infoImg');
    var modalImgId=document.getElementById('modalImgId');
    var i;
    for(i=0;i<infoImg.length;i++){
      infoImg[i].addEventListener('click',function(){
        modalImgId.src=this.src;
      })
    }
  }

 

  useEffect(() => {
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
    var span=document.getElementsByClassName("close")[0];
    span.onclick = function() {
      modal.style.display = "none";
    }
    var btn=document.getElementsByClassName('open')
    var i;
   
    var modal=document.getElementById('modal');
   
    for(i=0;i<btn.length;i++){
      btn[i].addEventListener('click',function(){
        modal.style.display = "block";
      })
    }
    
    selectTab();
    changeImg();
    
   
  }, []);
 
  const classes=useStyles();
  return (<>
    <div id="modal" className={classnames(classes.modal)}>
        <div className={classes.modalContent}>
           <div className={classes.modalContentHeader}>
             <div><span onClick={()=>setMdState(0)} className={classnames(classes.modalTab,'modalTab','selectedtab')}>تصاویر رسمی</span><span onClick={()=>setMdState(1)} className={classnames(classes.modalTab,'modalTab')}>تصاویر خریداران</span></div>
            <a className={classnames(classes.close,'close')}><CloseIcon className="close"/></a>
           </div>
           <div className={classes.modalContentBody}>
             {mdState==0 &&  <div>
              <img src="images/goodOrg.jpg" alt="" className={classes.modalImg} id="modalImgId" />
             <div className={classes.galleryInfo}>
               <Typography variant="body1" color="initial" style={{ textAlign:'right' }}>گوشی موبایل شیائومی مدل POCO X3 Pro M2102J20SG دو سیم‌ کارت ظرفیت 256 گیگابایت و 8 گیگابایت رم </Typography>
              <div className={classes.imgInfoBox}>
                  
                   <div className={classes.infoDiv}>
                    <img src="images/goodOrg.jpg" className={classnames(classes.infoImg,'infoImg')} alt="" />
                  </div>
                  <div className={classes.infoDiv}>
                    <img src="images/g1.jpg" className={classnames(classes.infoImg,'infoImg')} alt="" />
                  </div>
                  <div className={classes.infoDiv}>
                    <img src="images/g2.jpg" className={classnames(classes.infoImg,'infoImg')} alt="" />
                  </div>
                  <div className={classes.infoDiv}>
                    <img src="images/g4.jpg" className={classnames(classes.infoImg,'infoImg')} alt="" />
                  </div><div className={classes.infoDiv}>
                    <img src="images/g4.jpg" className={classnames(classes.infoImg,'infoImg')} alt="" />
                  </div><div className={classes.infoDiv}>
                    <img src="images/g5.jpg" className={classnames(classes.infoImg,'infoImg')} alt="" />
                  </div>
              
              </div>
             </div>
             
             
             </div>}

             {mdState==1 && <div></div>}
             
           </div>

        </div>
      </div>
    <div className={classes.contianer}>
      
      <div className={classes.broadcampBox}>
       <span>
         <ul className={classes.broadcamp}>
           <li className={classes.broadcampLi}><a> دیجی کالا </a></li>

           <li className={classnames(classes.broadcampLit,'broadcampLit')}><a>کالای دیجیتال </a></li>
           <li className={classnames(classes.broadcampLit,'broadcampLit')}><a>موبایل</a></li>
           <li className={classnames(classes.broadcampLit,'broadcampLit')}><a> گوشی موبایل </a></li>
         </ul>


       </span>
       <span style={{ display:'flex',alignItems:'center',color:'#777777' }}> 
       <span>کالای خود را در دیجی کالا بفروشید</span>
       <StoreMallDirectoryOutlinedIcon/>
       
       </span>
      </div>

      <div className={classes.row}>
        <div className={classnames(classes.gallary,'gallary')}>
         <div className={classes.imgBox}>
           <div className={classes.imgToolbar}>
             <ul className={classes.toolList}>
               <li className={classes.toolLi}>
                 <IconButton className={classes.iconButton}>
                   <FavoriteBorderOutlinedIcon className={classes.icon}/>
                 </IconButton>
               </li>
               <li className={classes.toolLi}>
                 <IconButton className={classes.iconButton}>
                   <ShareOutlinedIcon className={classes.icon}/>
                 </IconButton>
               </li>
               <li className={classes.toolLi}>
                 <IconButton className={classes.iconButton}>
                   <NotificationsActiveOutlinedIcon className={classes.icon}/>
                 </IconButton>
               </li>
               <li className={classes.toolLi}>
                 <IconButton className={classes.iconButton}>
                   <TimelineOutlinedIcon className={classes.icon}/>
                 </IconButton>
               </li>
               <li className={classes.toolLi}>
                 <IconButton className={classes.iconButton}>
                   <CompareOutlinedIcon className={classes.icon}/>
                 </IconButton>
               </li>
               <li className={classes.toolLi}>
                 <IconButton className={classes.iconButton}>
                   <TocOutlinedIcon className={classes.icon}/>
                 </IconButton>
               </li>
             </ul>
           </div>
           <div className={classes.img}>
             <img src="images/goodOrg.jpg" style={{width:'385px',heigh:'385px',dispaly:'block',margin:"auto" }} alt="" />
           </div>
         </div>
         <div className={classes.imgList}>
          <div className={classes.imgWrapper}><img className={classnames(classes.imgth,'open','infoImg')}  src="images/g4.jpg" alt="" /></div>
          <div className={classes.imgWrapper}><img className={classnames(classes.imgth,'open','infoImg')}  src="images/g1.jpg" alt="" /></div>
          <div className={classes.imgWrapper}><img className={classnames(classes.imgth,'open','infoImg')}  src="images/g2.jpg" alt="" /></div>
          <div className={classes.imgWrapper}><img className={classnames(classes.imgth,'open','infoImg')}  src="images/g3.jpg" alt="" /></div>
          <div className={classes.imgWrapper}><img className={classnames(classes.imgth0,'open')}  src="images/mobileTh.jpg" alt=""  />
          <button className={classnames(classes.iconButtonTwo,'open')}><MoreHorizOutlinedIcon style={{color:'white'}} /></button>
          </div>
          <div className={classes.imgWrapper}><img className={classes.imgth}  src="images/mobileTh.jpg" alt="" /></div>
          <div className={classes.imgWrapper}><img className={classes.imgth}  src="images/mobileTh.jpg" alt="" /></div>
          <div className={classes.imgWrapper}><img className={classes.imgth}  src="images/mobileTh.jpg" alt="" /></div>
          <div className={classes.imgWrapper}><img className={classes.imgth}  src="images/mobileTh.jpg" alt="" /></div>
         </div>
         
        
        
        
        </div>
        <div className={classnames(classes.contentBox,'contentBox')}>
         <div className={classes.contentHeader}>
         <div className={classes.broadcampBox}>
       <span>
         <ul className={classes.broadcamp}>
           <li className={classes.broadcampLi}><a style={{ color:'#67cadb' }}> شیائومی </a></li>

           <li className={classnames(classes.broadcampLit,'broadcampLit')}><a style={{ color:'#67cadb' }}> گوشی موبایل شیائومی </a></li>
        
         </ul>
       </span>
      </div>
      <Typography variant="h1" style={{ fontSize:'20px',fontWeight:'700' }} color="initial">گوشی موبایل شیائومی مدل POCO X3 Pro M2102J20SG دو سیم‌ کارت ظرفیت 256 گیگابایت و 8 گیگابایت رم </Typography>
         </div>
         <div className={classes.contentBody}>
        
           <div className={classes.productDetail}>
             <div style={{ dispaly:'flex',flexDirection:'row',alignItems:'center' }}>
             <Typography style={{ display:'inline' }} variant="caption" color="textSecondary">Xiaomi POCO X3 Pro M2102J20SG Dual SIM 256GB And 8GB RAM Mobile Phone</Typography>
            
             
             </div>
             <span style={{ dispaly:'flex',alignItems:'center',opacity:'0.5',fontSize:'15px' }}>
              <span><ThumbUpAltOutlinedIcon/></span> 
               <span>۸۸٪ (۸۳۰ نفر) از خریداران، این کالا را پیشنهاد کرده‌اند.</span>
              <span> <ErrorOutlineOutlinedIcon/></span>
             </span>
           <div style={{marginTop:'5px',opacity:'0.7'}} >
             
             <span><StarIcon style={{color:'#fac74b',fontSize:'13px'}}/>4.4</span>
           </div>

           <div style={{ marginTop:'20px' }}><Typography variant="body1" color="initial">رنگ: قرمز</Typography></div>
           <div className={classes.property}>
             <ul className={classes.spic}>
               <a>ویژگی های کالا</a>
               <li className={classes.spicLi}>حافظه داخلی:232 گیگابایت </li>
               <li className={classes.spicLi}>حافظه داخلی:232 گیگابایت </li>
               <li className={classes.spicLi}>حافظه داخلی:232 گیگابایت </li>
               <li className={classes.spicLi}>حافظه داخلی:232 گیگابایت </li>
               <li className={classes.spicLi}>حافظه داخلی:232 گیگابایت </li>
             </ul>
           </div>

           <div className={classes.wage}>
             <Typography variant="h1" color="initial" className={classes.wageHead}>قرعه کشی شگفت انگیز دیجی کالا</Typography>
             <Typography variant="body1" color="textSecondary" style={{ width:'60%' }}> 
             ون 12 و گلکسی s21ون 12 و گلکسی s21ون 12 
             و گلکسی s21ون 12 و گلکسی s21ون 12 و گلکسی s21ون 12 و گلکسی s21یک دستگاه گوشی آیفون 12 و گلکسی s21</Typography>
             <img src="images/wage.png" alt=""  className={classes.wageImg}/>
           </div>
           <div className={classes.digipluse}>
             <div style={{width:'100%', display:'flex',flexDirection:'row',jsutifyContent:"space-between",alignItems:'center' }}>
                <div variant="h1" color="initial" className={classes.digiHead}><img src="images/st.jpg" style={{width:'15%'}}/> خدمات ویژه کاربران دیچی پلاس</div> 
                <div style={{position:'absolute',left:'0px', color:'#1fc7db',display:'flex',alignItems:'center',direction:'rtl' }}> هم اکنون عضو شوید <NavigateBeforeOutlinedIcon/></div>
                </div>
                <Typography variant="body1" color="textSecondary" style={{ marginTop:'20px' }}>
              ارسال رایگان امکان ارسال فوری
              </Typography>
             
             
           </div>

           <div className={classnames(classes.digipluse,classes.free)}>
             <div style={{ display:'flex',alignItems:'center' }}> <LocalShippingOutlinedIcon style={{transform:'scaleX(-1)',marginLeft:'10px',color:'red'}}/><span>ارسال رایگان سفارش</span></div>
             <div > <Typography variant="body1" color="textSecondary">اولین سفارش کاربران جدید</Typography></div>
             <img src='images/free.png' className={classes.freeImg}/>
           </div>

           <div className={classes.digipluse}>
             <div style={{width:'100%', display:'flex',flexDirection:'row',jsutifyContent:"space-between",alignItems:'center' }}>
                <div variant="h1" color="initial" className={classes.digiHead}><img src="images/st1.jpg" style={{width:'12%'}}/> به اعتبار دیجی پی قسطی بخرید </div> 
                <div style={{position:'absolute',left:'0px', color:'#1fc7db',display:'flex',alignItems:'center',direction:'rtl' }}> اطلاعات بیشتر <NavigateBeforeOutlinedIcon/></div>
                </div>
                <Typography variant="body1" color="textSecondary" style={{ marginTop:'20px' }}>
              ارسال رایگان امکان ارسال فوری
              </Typography>
             
             
           </div>
           </div>


           <div className={classes.buyConfig}>
             <div className={classes.productSeller}>
               <Typography variant="h6" color="initial">فروشنده</Typography>
             </div>

             <div className={classes.seller}>
                <div className={classes.sellerIcon}> 
                <StorefrontIcon/> </div>  
                <div className={classes.sellerBox}>
                  <div className={classes.sellerNameBox}>
                    <Typography variant="body1" color="initial">دیجی آنلاین</Typography>
                    <span><ArrowBackIcon/></span>
                  </div>
                  <div className={classes.sellerGrid}>
                    <span>100%</span>
                    <Typography variant="body1" color="textSecondary">رضایت کاربران</Typography>
                    <Divider orientation="vertical" style={{ height:'50%',margin:'auto 5px' }} />
                    <span>100%</span>
                    <Typography variant="body1"  color="textSecondary">رضایت کاربران</Typography>
                  </div>

                  </div>  
             </div>

            
               <div className={classes.verifyGood}>
               <div className={classes.sellerIcon}> 
               <VerifiedUserOutlinedIcon/>
               </div>
               <div className={classes.verify}>
                 <Typography variant="body1" color="initial">گارانتی سلامت و ایمنی کالا </Typography>
               </div>
               </div>

             <div className={classes.sendBox}>
               <div className={classes.isStock}>
                 <span style={{ display:'flex',alignItems:'center' }}><StorefrontOutlinedIcon/>
                <span style={{ alignContent:'center',display:'inline-flex',paddingRight:'5px' }}>موجود در انبار دیجی کالا</span> 
                 </span>
                 <span><NavigateBeforeOutlinedIcon/></span>
                 </div>  
                 <Divider orientation="vertical" style={{ height:'20px',width:'2px',margin:'auto 10px auto 0px' }} /> 
                 <ul className={classes.stockUl}>
                   <li style={{ color:'#2cb4cc',alignItems: 'center', }}><div style={{ paddingRight:'5px',display:'flex',alignItems:'center',width:'100%' }}><LocalShippingOutlinedIcon style={{ color:'#e72a50' }} />
                    <span style={{ paddingRight:'5px',color:'black' }}>ارسال توسط دیجی کالا</span>
                  
                   
                   </div></li>
                   </ul>        
             </div>

             <div className={classes.price}>
               <Typography variant="h6" color="initial">۶,۸۹۹,۰۰۰
تـومـان</Typography>
             </div >
             <div className={classes.eye}><VisibilityOutlinedIcon/> <span> +100 در حال مشاهده این کالا می باشند </span></div>
           <div className={classes.addToCart}>
           <Button color="secondary" variant="contained" className={classes.button}>افزودن به سبد خرید </Button></div> 


           </div>


         </div>

 

        
        
        </div>

        
      </div>
     
      <div className={classes.rowTwo}>

        <Typography variant="h6" color="initial"> لیست فروشندگان این کالا </Typography>
        <Divider orientation="horizontal" style={{height:'3px',width:'80px',backgroundColor:'red'}}/>
        <div className={classes.sellersBox}>
          <div className={classes.sellersInfo}>
            <div className={classes.info }>
              <span className={classes.digiInfo}><img src="images/digimark.jpg" /></span>
              <div>
              <Typography variant="body1" color="initial">دیجی کالا</Typography>
              <Typography variant="body1" color="initial">رضایت مشتریان</Typography>
              </div>
            </div>
            <div className={ classes.infoC }>
              <span className={classes.spanInfo}><LocalShippingOutlinedIcon/></span><span>ارسال دیجی کالا</span>
            </div>
            <div className={ classes.infoL }><span className={classes.spanInfo1}><VerifiedUserOutlinedIcon/></span><span>گارانتی 18 ماهه</span></div>
            <div className={ classes.infoL }>
              <span>138500</span>  <span>تومان</span>
            </div>
            <div className={ classes.infoL }>
              <Button variant="outlined" color="secondary" size="large">  افزودن به سبد خرید</Button>
            </div>
            
          </div>
          <div className={classes.sellersInfo}>
            <div className={classes.info }>
              <span className={classes.digiInfo}><img src="images/digimark.jpg" /></span>
              <div>
              <Typography variant="body1" color="initial">دیجی کالا</Typography>
              <Typography variant="body1" color="initial">رضایت مشتریان</Typography>
              </div>
            </div>
            <div className={ classes.infoC }>
              <span className={classes.spanInfo}><LocalShippingOutlinedIcon/></span><span>ارسال دیجی کالا</span>
            </div>
            <div className={ classes.infoL }><span className={classes.spanInfo1}><VerifiedUserOutlinedIcon/></span><span>گارانتی 18 ماهه</span></div>
            <div className={ classes.infoL }>
              <span>138500</span>  <span>تومان</span>
            </div>
            <div className={ classes.infoL }>
              <Button variant="outlined" color="secondary" size="large">  افزودن به سبد خرید</Button>
            </div>
            
          </div>
        
        </div>
      </div>
      <div className={classes.rowThree}>
       <div className={classes.des}>
         <div className={classes.desHeader}>
           <div className={classes.desHeaderItem}><a href="#id1" className={classes.desHeaderItemTitle}>نقد و بررسی</a></div>
           <div className={classes.desHeaderItem}><a href="#id2" className={classes.desHeaderItemTitle}>مشخصات </a></div>
           <div className={classes.desHeaderItem}><a href="#id3" className={classes.desHeaderItemTitle}>بررسی تخصیی</a></div>
           <div className={classes.desHeaderItem}><a href="#id4" className={classes.desHeaderItemTitle}>دیدگاه کاربران </a></div>
           <div className={classes.desHeaderItem}><a href="#id5" className={classes.desHeaderItemTitle}>پرسش و پاسخ</a></div>
         </div>
         <div>
         <div id="id1" className={classes.article}>
           <article>
             <div> <Typography variant="h6" color="initial">نقد و بررسی اجمالی</Typography>
            <Typography variant="body2" color="textSecondary">Xiaomi POCO X3 Pro M2102J20SG Dual SIM 256GB And 8GB RAM Mobile Phone</Typography>
            <Divider orientation="horizontal" className={classes.line}/></div>
           
            <Typography style={{ lineHeight:'2.2' }} variant="body1" color="initial"> گوشی موبایل شیائومی مدل Poco X3 Pro دو سیم‌ کارت ظرفیت 256 گیگابایت از جمله محصولات برند شیائومی که در سال 2021 روانه بازار شده است. این محصول دارای ساختاری متوازن و خوش‌ساخت بدون پشتیبانی از تکنولوژی 5G روانه بازار شده است. این محصول از بدنه پلاستیکی ساخته شده است که قاب جلو شیشه‌ای جلوه ویژه‌ای به این مدل بخشیده است. صفحه‌نمایش گوشی موبایل شیائومی مدل POCO X3 Pro دو سیم‌ کارت ظرفیت 256گیگابایت در اندازه 6.67 منتشر شده است. این صفحه‌نمایش کاملاً تمام‌صفحه است و در بالا وسط اثری از بریدگی یا حفره دوربین سلفی وجود دیده می‌شود. دوربین سلفی این محصول دارای حسگر 20 مگاپیکسلی است .صحفه‌نمایش گوشی موبایل شیائومی مدل POCO X3 با استفاده از فناوری Corning Gorilla Glass 6 در برابر خط‌وخش و صدمات احتمالی محافظت می‌شود. گفتنی است چهار دوربین که سنسور اصلی آن 48 مگاپیکسلی است در قسمت پشتی این گوشی جا خوش کرده‌اند. این دوربین‌ها قادر هستند ویدئوی 4K را ثبت و ضبط کنند. دوربین‌ سلفی این محصول هم به سنسوری 20 مگاپیکسلی مجهز شده است. بلوتوث نسخه 5.0، نسخه 11 سیستم عامل اندروید و باتری 5160 میلی‌آمپرساعتی از دیگر ویژگی‌‌های این گوشی جدید هستند. </Typography>
           </article>
         </div>
         <div id="id2" className={classes.article}><div> <Typography variant="h6" color="initial"> نقد و بررسی تخصصی </Typography>
            <Typography variant="body2" color="textSecondary">Xiaomi POCO X3 Pro M2102J20SG Dual SIM 256GB And 8GB RAM Mobile Phone</Typography>
            <Divider orientation="horizontal" className={classes.line}/></div> </div>
         <div id="id3" className={classes.article}>
         <div> <Typography variant="h6" color="initial"> مشخصات کالا </Typography>
            <Typography variant="body2" color="textSecondary">Xiaomi POCO X3 Pro M2102J20SG Dual SIM 256GB And 8GB RAM Mobile Phone</Typography>
            <Divider orientation="horizontal" className={classes.line}/></div>

            <div className={classes.options}> 
            <span style={{ fontWeight:'700',fontSize:'22px',width:"280px",paddingTop:'13px' }}>مشخصات کلی</span>
            <ul className={classes.optionsUl}>

              <li className={classes.optionLi}>
              <span className={classes.optionSpanOne}>ابعاد </span><span className={classes.optionSpanTwo}>165.3x76.8x9.4 میلی‌متر </span></li>
              
              <li className={classes.optionLi}>
              <span className={classes.optionSpanOne}>ابعاد </span><span className={classes.optionSpanTwo}>165.3x76.8x9.4 میلی‌متر </span></li>
              
              <li className={classes.optionLi}>
              <span className={classes.optionSpanOne}>ابعاد </span><span className={classes.optionSpanTwo}>165.3x76.8x9.4 میلی‌متر </span></li>
              
              <li className={classes.optionLi}>
              <span className={classes.optionSpanOne}>ابعاد </span><span className={classes.optionSpanTwo}>165.3x76.8x9.4 میلی‌متر </span></li>
              
              
              

            </ul>
            </div>

         </div>
         <div id="id4" className={classes.article}>
         <div> <Typography variant="h6" color="initial"> امتیاز و دیدگاه کاربران </Typography>
            <Typography variant="body2" color="textSecondary">Xiaomi POCO X3 Pro M2102J20SG Dual SIM 256GB And 8GB RAM Mobile Phone</Typography>
            <Divider orientation="horizontal" className={classes.line}/></div>
         </div>
         <div id="id5" className={classes.article}>
         <div> <Typography variant="h6" color="initial"> پرسش و پاسخ کاربران </Typography>
            <Typography variant="body2" color="textSecondary">Xiaomi POCO X3 Pro M2102J20SG Dual SIM 256GB And 8GB RAM Mobile Phone</Typography>
            <Divider orientation="horizontal" className={classes.line}/></div>
         </div>
         </div>
         
       
       
       </div>
        <div className={classes.miniBuy}>
          <div className={classes.miniBuyName}>
            <span style={{ width:'50%' }}><img src="images/mobileTh.jpg" className={classes.miniImg} /></span>
            <span style={{ width:'50%',color:'#5f5f5f',fontWeight:'100', }}>گوشی موبایل شیائومی مدل POCO X3 Pro M2102J20SG دو سیم‌ کارت ظرفیت 256 گیگابایت و 8 گیگابایت رم </span>
          </div>
           <div className={classes.miniIcon} >
             <span><img className={classes.icon} src="images/digimark.jpg" alt="" /></span> <span>دیجی کالا</span>
           </div>

           <div className={classes.miniIcon} >
             <span><VerifiedUserOutlinedIcon className={classes.mini}/></span> <span>گارانتی 18 ماهه </span>
           </div>

           <div className={classes.miniIcon} >
             <span><StorefrontOutlinedIcon className={classes.mini}/></span> <span>موجود در انبار دی جی کالا</span>
           </div>

           <div style={{ direction:"ltr" }}>
             <Typography variant="h6" color="initial">1445000 تومان </Typography>
           </div>

           <div style={{ padding:'10px' }}>
             <Button variant="contained" color="secondary" style={{ width:'100%' }} >
               افزودن به سبد خرید
             </Button>
           </div>
          
        </div>
      </div>
    </div>

    {mdState}
    </>
  )
}

