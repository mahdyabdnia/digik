import React from 'react'
import useStyles from './styles'
import {Grid, Typography,Divider} from '@material-ui/core'

export default function Fotter() {
    const classes=useStyles();
    return (
        <div style={{ borderTop:'1px #e3e3e5 solid',backgroundColor:'white',paddingTop:'10px',width:'100%',position:'absolute',bottom:'0px' }}>
            <Typography className={classes.brand} variant="h4" color="secondary">دی جی کالا</Typography>
            <Typography className={classes.brand} variant="body2" color="textSecondary"> تلفن :021 888 55 434  </Typography>
            <Grid item container direction="row" className={classes.prop}>
                <Grid  style={{ width:"20%",display:'flex',flexDirection:'row' }}> 

                    <img src="images/cap.jpg" style={{margin:'auto',}}/>
                </Grid>
                <Grid  style={{ width:"20%",display:'flex',flexDirection:'row' }}>

                   <img src="images/cap.jpg" style={{margin:'auto',}}/>
                </Grid>

                <Grid  style={{ width:"20%",display:'flex',flexDirection:'row' }}>

                    <img src="images/cap.jpg" style={{margin:'auto',}}/>
                </Grid>
                <Grid  style={{ width:"20%",display:'flex',flexDirection:'row' }}>

                   <img src="images/cap.jpg" style={{margin:'auto',}}/>
                </Grid>

                <Grid  style={{ width:"20%",display:'flex',flexDirection:'row' }}>

<img src="images/cap.jpg" style={{margin:'auto',}}/>
</Grid>


<Divider orientation="horizontal" style={{backgroundColor:"#f3f3f4",margin:'10px'}}/>

 
               
               
            </Grid>
            
        </div>
    )
}
