import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({

brand:{
    textAlign:'right',
    marginRight:'40px'
},
prop:{
    marginTop:"20px"
}





});
export default useStyles;