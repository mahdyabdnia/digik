import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import Button from '@material-ui/core/Button'
import { Link } from 'react-router-dom';




export default function Login() {
    const classes=useStyles();
    return (
        <div className={classes.container}>
            
        <div className={classes.row}>
          <div className={classes.inner}>
              <Link to="/" style={{ textDecoration:"none" }}>
              <Typography className={classes.brand} variant="h3" color="secondary"> digikala </Typography>
              </Link>
             
              <Typography variant="h6" color="initial" className={classes.loginTitle}>ورود / ثبت نام </Typography>
              <Typography variant="body1" color="textSecondary" className={classes.enterText}>شماره موبایل یا پست الکترونیکی خود را وارد کنید</Typography>
              <input type="text" className={classes.input}/>
              <Link to="/loginSec">
              <Button variant="contained" color="secondary" size="large" className={classes.button}>
                ورود به دیجی کالا
              </Button></Link>
              <p className={classes.privacy}  >با ورود و یا ثبت نام در دیجی‌کالا شما شرایط و قوانین استفاده از سرویس های سایت دیجی‌کالا و قوانین حریم خصوصی آن را می‌پذیرید. </p>
              
          </div>

        </div>


        </div>
    )
}
