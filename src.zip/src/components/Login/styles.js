import {makeStyles} from '@material-ui/core'
const useStyles =makeStyles({

  container:{
      display:'flex',
      alignItems:"center",
      flexDirection:"column",
      justifyContent:'center'
     
      
  },
  row:{ 
      margin:'auto',
    width:"360px",
    minHeight:'437px',
    height:"auto",
   
    marginTop:'150px',
    marginBottom:"auto",
    display:'flex',
    flexDirection:'column',
   
    border:'1px solid #efefef'
  },
  inner:{
      padding:"20px"
  },
  brand:{
      textAlign:"center"
  }
      ,
loginTitle:{
    textAlign:"right",
    marginTop:'40px',
    marginRight:"10px",
    fontWeight:"bold"
},
enterText:{
    marginTop:"20px",
    textAlign:"right"
},
input:{
    marginRight:'auto',
    marginLeft:'auto',
    marginTop:'10px',
    width:'97%',
    paddingRight:"10px",
    height:"13%",
    direction:'rtl',
    
    borderRadius:'5px',
    outline:'none'
},
button:{
    justifySelf:'center',
    alignSelf:'center',
    width:'100%',
    marginTop:"40px ",
    marginRight:"auto",
    marginLeft:"auto",
    fontWeight:'bold'
},
privacy:{
    textAlign:'center',
    opacity:'0.5',
    fontSize:"13px"
}

});

export default useStyles;