import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({
container:{
    
    minWidth:'255px',
   
    borderRadius:'10px',
    height:'345px',
    '&:hover':{
        boxShadow:'0px 0px 5px 5px #ebebeb'
    },
    margin:'auto 0px'

},
imgBox:{
    display: 'flex',
    flexDirection:'column',
    height:'55%',
    width:'100%',
    justifyContent:'center',
    alignItems:'center'
},
img:{
    maxWidth:'170px',
    maxHeight:'170px',
    display:'block',
    margin:'auto'
},
titleBox:{
    height:'45%',
    display:'flex',
    flexDirection:'column'
},
nameBox:{
    display:'flex',
    height:'50%',
    direction:"rtl",
    justifyContent:'center',
    alignItems:'center'
},
name:{
    textAlign:'center',
    display:'flex',
    justifyContent:'center'
},
offBox:{
    display:'flex',
    flexDirection:'row',
    justifyContent:'left',
    alignItems: 'center',
    height:'25%',
    paddingLeft:'20px',
    direction:'ltr'
},
off:{
    padding:"2.5px 5px",
    backgroundColor:'red',
    color:'white',
    borderRadius:'10px'
},
beforeOff:{
    color:'#b1b1b1',
    textDecorationColor:'#b1b1b1',
    textDecorationLine:'line-through',
    marginLeft:'10px'
},
priceBox:{
display:'flex',
flexDirection:'row',
direction:"ltr",
paddingLeft:'20px'
},
imgLink:{ 
    cursor:'pointer'
},nameLink:{
    cursor:'pointer'
}
});
export default useStyles;