import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'
import {Link} from 'react-router-dom'
export default function CardType({name,src,price}) {
    const classes=useStyles();


    return (
        <div className={classes.container}>
            <div className={classes.imgBox}>
              <Link className={classes.imgLink} to="/good">  <img src={src} alt="" className={classes.img} /> </Link>
            </div>
            <div className={classes.titleBox}>
               <div className={classes.nameBox}>
                 <a className={classes.nameLink}> <Typography variant="body1" color="textSecondary"> {name} </Typography> </a> 
               </div>
               <div className={classes.offBox}>
                   <span className={classes.off}>25%</span>
                   <span className={classes.beforeOff}>{price} </span>

               </div>
               <div className={classes.priceBox}>
                   <Typography variant="body1" color="initial" className={classes.price}> {price}</Typography>
               </div>


            </div>
        </div>
    )
}
