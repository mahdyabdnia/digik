import {makeStyles} from '@material-ui/core'
 const useStyles=makeStyles({
container:{
    display:'flex',
    flexDirection:'column',
    width:'201px',
    height:'327px',
    borderRadius:'10px',
    '&:hover':{
        boxShadow:'0px 0px 10px 10px #f5f5f5'
    }
},
imgBox:{
    height:'50%'
},
img:{
width:'161px',
height:'161px',
display:'block',
margin:'auto'
},
title:{
    height:'50%',
    paddingTop:'40px'
},
name:{
    height:'50px',
    paddingRight:'20px'
},
offBox:{
    display:"flex",
    flexDirection:'row',
    height:'25px',
    direction:'ltr',
    paddingLeft:'20px',
    alignItems: 'center',


},
off:{
    backgroundColor:'red',
    color:'white',
    borderRadius:'20px',
    padding:'5px 10px',
    display:'flex',
    alignItems:'center'

},
beforeOff:{
    color:'#b0b0b0',
    
    textDecorationStyle:'solid',
    textDecorationColor:'#b0b0b0',
    textDecorationLine:'line-through',
    marginLeft:'20px'
},
price:{
    direction:'ltr',
    color:'black',
    paddingLeft:'20px',
    height:'25px',
    display:'flex',
    alignItems:'center',
    marginTop:'5px',
}
 });
 export default useStyles;