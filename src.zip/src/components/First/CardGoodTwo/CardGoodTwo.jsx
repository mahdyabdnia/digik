import React from 'react'
import useStyles from './styles'
import Typography from '@material-ui/core/Typography'

export default function CardGoodTwo() {
    const classes=useStyles()
    return (
        <div className={classes.container}>
            <div className={classes.imgBox}>
                <img src="images/cover.jpg" className={classes.img} alt="" />
            </div> 
            <div className={classes.title}>
                <div className={classes.name}>
                <Typography variant="body2" color="textSecondary">کاور گوشی لوکسار مدل k-4454</Typography>
                </div> 
               
                <div className={classes.offBox}>
                <span className={classes.off}>25%</span>
                <span className={classes.beforeOff}>250000</span>
            </div>
            <div className={classes.price}>
                <Typography variant="body1" color="initial">250000تومان</Typography>
            </div>
            </div>
           
        </div>
    )
}
