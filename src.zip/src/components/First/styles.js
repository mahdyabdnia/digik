import {makeStyles} from '@material-ui/core'
const useStyles=makeStyles({
container:{
display:'flex',
flexDirection:'column',
direction:'rtl',
marginTop:'20px'
}   , 
firstBanner:{
    margin:'auto 91px',
    maxWidth:'1336px',
    width:'100%',
    display:'flex',
    flexDirection:'row',

}, 
firstBannerCarousel:{
    width:'883px',
    height:'440px',
    marginLeft:'20px', 
    marginTop:'10px',
    position:'relative',
    marginBottom:'20px'

},
imgCr:{
    width:'883px',
    height:'440px',
    borderRadius:'21px',
    display:'block',
},
dot:{
height:'10px',
width:'10px',
borderRadius:'50%',
margin:'0px 2px',
backgroundColor:'white',
display:'inline-block',
transition: 'background-color 0.6s ease'
},
dotBox:{
    right:'0%',
    left:'0%',
    position:'absolute',
    textAlign:'center',
    bottom:'30px'
},
mySlides:{
display:'none'
},
firstBannerDiv:{
    width:'440px',
    display:'flex',
    flexDirection:'column',
    marginRight:'20px'
},
firstBannerAd:{
    display:'flex',
    flex:'1',
    margin:'10px 0px',
    cursor:'pointer'
},
img:{
display:'block',
width:'100%',
height:'100%'
},

imgGif:{
    display:'block',
    width:'100%',
    height:'100%',
    borderRadius:'10px'
},

supriseBox:{
    width:'100%',
    margin:'auto',
    backgroundColor:'red',
    height:'521px',
    opacity:'0.8'
},
supriseBox2:{
    width:'100%',
    margin:'auto',
    backgroundColor:'#6bb927',
    height:'521px',
    opacity:'0.8'
},
suprise:{
    width:'89%',
    margin:'auto',
    backgroundColor:'inherit',
    height:'521px',
    direction:'rtl',
    display:'flex',
   
},
supriseEnter:{
    width:'20%',
 
    marginTop:'auto',
    marginBottom:'auto',
    height:'444px'
},
supriseImg:{
width:'170px',
height:'90.89%',
marginRight:'auto',
marginLeft:'auto',

},
supriseButtonBox:{
width:'170px',
marginLeft:'auto',
marginRight:'auto',

direction:'rtl',
height:'9.11%'
},
btn:{
backgroundColor:'inherit',
height:'100%',
border:'1px solid white',
color:'white',
borderRadius:'5px',
width:'140px'
},
supriseCarousel:{
    width:'80%',
    marginTop:'auto',
    marginBottom:'auto',
   
    height:'444px'
},

adOne:{
    dispaly:'flex',
    marginTop:'40px',
    width:'100%',
    padding:'0px 80px',
    justifyContent:'space-around'
},
ad:{
    display:'inline-flex',
    width:'319px',
    height:'239px',
    margin:'0px 10px',
    
},
adImg:{
    display:'block',
    width:'inherit',
    height:'inherit',
    borderRadius:'21px'
},
mobileBox:{
    display:'flex',
    flexDirection:'row',
    width:'1350px',
    height:"428px",
    margin:'auto',
    justifyContent:'space-around',
    marginTop:'20px'
},

rightBox:{
    width:"81%",
    borderRadius:'5px',
    backgroundColor:'white',
},
rightBoxHeader:{
    height:'18%',
    display:'flex',
    justifyContent:'space-around',
    padding:'0px 20px'
},
rightBoxHeaderTag:{
width:'16%',
borderBottom:'solid 1px red',
display:'flex',
flexDirection:'column',
justifyContent:"center"
},
rightBoxHeaderRight:{
width:'81%',
borderBottom:'1px solid #e3e3e3'
},
rightBoxBody:{
    height:'81%',
   display:'flex',
   position:'relative'
},
right:{
    position:'absolute',
    backgroundColor:'white',
    top:'30%',
    borderRadius:'0 3px 3px 0',
    outline:'none',
    border:'#e8e8e8 1px solid',
    padding:'25px 10px',
    right:'0px',
    cursor:'pointer'
},
left:{
    position:'absolute',
    backgroundColor:'white',
    top:'30%',
    borderRadius:'0 3px 3px 0',
    outline:'none',
    border:'#e8e8e8 1px solid',
    padding:'25px 10px',
    left:'0px',
    cursor:'pointer'
},
leftBox:{
    width:'16%',
    borderRadius:'5px',
    backgroundColor:'white',
    display:'flex',
    flexDirection:'column',
    
},
leftBoxHeader:{
    height:'57px',
    display:'flex',
    alignItems:'center',
    width:'100%',
    justifyContent:'center'
},
card:{
    display:'flex',
    flexDirection:'column',

},
categories:{
    display:'flex',
    flexDirection:'column',
    height:'200px',
    width:'1340px',
    margin:'auto',
    backgroundColor:'white',
    marginTop:"40px ",
    paddingTop:'20px'
},
categoriesHeader:{
    display:'flex',
    justifyContent:'center',
    height:'10%',
    width:'100%'
},
categoriesBody:{
    display:'flex',
    justifyContent:'space-around',
    marginTop:'20px',
    width:'100%',
    height:'100%'
},
category:{
    flex:'1',
    display:'flex',
    flexDirection:'column',
    justifyContent:'space-around',
    alignItems:'center'
},
icon:{
    fontSize:'30px !important',
    color:'#00bfd6'
},
count:{
    color:'#00bfd6'
},
customize:{
    display:'flex',
    flexDirection:'row',
    width:'1330px',
    height:'438px',
    justifyContent:'space-between',
    margin:'20px auto'
},
rightCustomize:{
    display:'flex',
    flexDirection:'column',
    backgroundColor: "white",
    borderRadius:'10px',
    width:'20%',
    textAlign:'center'
},
lgBtn:{
display:'block',
color:'white',
backgroundColor:'#ef394e',
border:'1px #ef394e solid',
width:'80%',
margin:'auto',
height:'40px',
borderRadius:'5px',
textDecoration:'none !important',
marginTop:'40px !important'

},
leftCustomize:{
    display:'flex',
    flexDirection:'column',
    width:'79%',
    backgroundColor:'white',
    height:'100%'
},
leftCustomizeHeader:{
    height:'17% ',
    width:'90%',
    display:'flex',
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
    margin:"0px auto"
},
leftCustomizeHeaderRight:{
width:'17%',
height:'100%',
borderBottom:'1px solid red',
display:'flex',
flexDirection:'column',
justifyContent:'center'
},
leftCustomizeHeaderLeft:{
width:'82%',
height:'100%',
borderBottom:'1px solid #dfdfdf',
textAlign:'center'
},
leftCustomizeBody:{
    height:'83%',
    width:'100%',
    position:'relative',
    display:'flex',
    flexDirection:'row',
    alignItems:'center',
    paddingRight:'10px'
},
leftNav:{
position:'absolute',
left:'3.7%',
top:'30%',
padding:'25px 10px',borderRadius:'5px',
border:'1px solid #ebebeb',
backgroundColor:'white',
zIndex:'20'

},
leftArrow:{
display:'absolute',
left:'10px !important'
},
rightNav:{
position:'absolute',
right:'0%',
top:'30%',
padding:'25px 10px',borderRadius:'5px',
border:'1px solid #ebebeb',
backgroundColor:'white',
zIndex:'20'

},
arrow:{
    fontSize:'45px'
},
adTwo:{
    width:'1346px',
    display:'flex',
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
    margin:'auto',
    marginBottom:'20px'
},
adTwoBlock:{
   width:'49.4%',
    borderRadius:'10px',
},
adTwoImg:{
    display:'block',
    borderRadius:'10px',
    width:'100%',
    height:'100%'
},
typesGood:{
    display:'flex',
    flexDirection:'column',
   paddingTop:'10px',
   paddingBottom:'10px',
    height:'438px',
    borderRadius:'5px',
    position:'relative',
    paddingRight:'30px',
    backgroundColor:'white',
    Width:'1306px !importnat',
    overflow:'hidden',
    marginBottom:"20px"
    
},
typesGoodTwo:{
    display:'flex',
    flexDirection:'column',
   paddingTop:'10px',
   paddingBottom:'10px',
    height:'418px',
    borderRadius:'5px',
    position:'relative',
    paddingRight:'30px',
    backgroundColor:'white',
    Width:'1336px !importnat',
    overflow:'hidden',
    marginBottom:"20px"
    
},
typesGoodHeader:{
    display:'flex',
    flexDirection:'row',
    direction:'rtl',
    height:'78px',
    paddingLeft:'30px',
    justifyContent:'space-between'
},
typesGoodHeaderTwo:{
    display:'flex',
    flexDirection:'row',
    direction:'rtl',
    height:'58px',
    paddingLeft:'30px',
    justifyContent:'space-between'
},
typesGoodHeaderRight:{ 
width:'19%',
display:'flex',
flexDirection:'column',
justifyContent:'center',
borderBottom:'1px solid red'
},
typesGoodHeaderLeft:{
    width:'78%',
    borderBottom:'1px solid #ebebeb'
},
typesGoodBody:{
    display:'flex',
    flexDirection:'row',
    height:'100%',
    flexWrap:'nowrap',
    maxWidth:'1306px',
    position:'relative'
},
innerCarousel:{
width:'100%',
overflow:'hidden',
height:'100%'

},
track:{
display:'inline-flex',
transition:'transform 0.2s ease-in-out',
height:'100%'
},
typesRightNav:{
position:'absolute',
top:'50%',
padding:'30px 12px',
backgroundColor:'white',
border:'1px solid #ebebeb',
right:'0%',
boxShadow:'-1px 0px 2.5px 2.5px #ebebeb',
borderRadius:' 10px 0px 0px 10px ',
zIndex:'10'
},typesLeftNav:{
position:'absolute',
top:'50%',
padding:'30px 12px',
backgroundColor:'white',
border:'1px solid #ebebeb',
left:'0%',
boxShadow:'1px 0px 2.5px 2.5px #ebebeb',
borderRadius:' 0px 10px 10px 0px ',
zIndex:'10'
}

});
export default useStyles;