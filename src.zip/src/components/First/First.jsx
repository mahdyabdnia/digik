import React,{useRef,useEffect} from 'react'
import useStyles from './styles'
import ArrowBackIosIcon from '@material-ui/icons/ArrowBackIos';
import Button from '@material-ui/core/Button'
import './style.css'
import Carousel from 'react-elastic-carousel';
import CardGood from './CardGood/CardGood'
import Typography from '@material-ui/core/Typography'
import CardGoodPluse from './CardGoodPluse/CardGoodPluse';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import LaptopChromebookOutlinedIcon  from '@material-ui/icons/LaptopChromebookOutlined';
import { Icon } from '@material-ui/core';
import CardGoodTwo from './CardGoodTwo/CardGoodTwo';
import CardType from './CardType/CardType'
import classnames from 'classnames'
import {Link } from 'react-router-dom'

export default function First() {  
  const carousel = useRef('slider')
  const classes=useStyles();

  useEffect(() => {
    
    return () => {
    
    }
  }, [])
  

  useEffect(() => { 
    var slideIndex = 0;
    const showSlide=setInterval(function(){
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";  
        }
        slideIndex++;
        if (slideIndex > slides.length) {slideIndex = 1}    
        for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }
        if(typeof(slideIndex)!=="undefined"){
        slides[slideIndex-1].style.display = "block";  }
        dots[slideIndex-1].classList.add('active')

    },5000) 
     return () => {
         clearInterval(showSlide)
     }
 }, [])
 
 var slideIndexV2=1;
 function plusSlides(n) {
   showSlidesV2(slideIndexV2 += n);
 }
 
 function currentSlide(n) {
   showSlidesV2(slideIndexV2 = n);
 }

 function showSlidesV2(n) {
   var i;
   var slides = document.getElementsByClassName("mySlides");
   var dots = document.getElementsByClassName("dot");
   if (n > slides.length) {slideIndexV2 = 1}    
   if (n < 1) {slideIndexV2 = slides.length}
   for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
   }
   for (i = 0; i < dots.length; i++) {
       dots[i].className = dots[i].className.replace(" active", "");
   }
   slides[slideIndexV2-1].style.display = "block";  
   dots[slideIndexV2-1].className += " active";
 }
 
 const gOne=[{id:0,name:'کیف کلاسوری لوکسار مدل LFC-260 مناسب برای گوشی موبایل شیائومی Redmi Note 9',src:'images/g11.jpg',price:'62000'},
              {id:1,name:'کاور لوکسار مدل LensPro-222 مناسب برای گوشی موبایل سامسونگ Galaxy A51',src:'images/g12.jpg',price:'10000'},
              {id:2,name:'کیف کلاسوری لوکسار مدل LFC-260 مناسب برای گوشی موبایل شیائومی Redmi Note 9',src:'images/g11.jpg',price:'62000'},
              {id:3,name:'کاور لوکسار مدل LensPro-222 مناسب برای گوشی موبایل سامسونگ Galaxy A51',src:'images/g12.jpg',price:'10000'},
              {id:4,name:'کیف کلاسوری لوکسار مدل LFC-260 مناسب برای گوشی موبایل شیائومی Redmi Note 9',src:'images/g11.jpg',price:'62000'},
              {id:5,name:'کاور لوکسار مدل LensPro-222 مناسب برای گوشی موبایل سامسونگ Galaxy A51',src:'images/g12.jpg',price:'10000'},
              {id:6,name:'کیف کلاسوری لوکسار مدل LFC-260 مناسب برای گوشی موبایل شیائومی Redmi Note 9',src:'images/g11.jpg',price:'62000'},
              {id:7,name:'کاور لوکسار مدل LensPro-222 مناسب برای گوشی موبایل سامسونگ Galaxy A51',src:'images/g12.jpg',price:'10000'},
              {id:8,name:'کیف کلاسوری لوکسار مدل LFC-260 مناسب برای گوشی موبایل شیائومی Redmi Note 9',src:'images/g11.jpg',price:'62000'},
              {id:9,name:'کاور لوکسار مدل LensPro-222 مناسب برای گوشی موبایل سامسونگ Galaxy A51',src:'images/g12.jpg',price:'10000'},
            ]

  const gTwo=[{id:0,name:'کتال پاستیل های بنفش',src:'images/g21.jpg',price:'65000'},
    
    {id:1,name:'کتاب اثر مرکب اثر دارن هاردی انتشارات نگین ایران',src:'images/g22.jpg',price:'55000'},
    {id:2,name:'کتاب خودت باش دختر اثر ریچل هالیس',src:'images/g23.jpg',price:'40000'},
    {id:3,name:'کتاب بیشعوری اثر خاویر کرمنت نشر ندای معاصر',src:'images/g24.jpg',price:'32000'},
    {id:4,name:'کتاب کیمیاگر اثر پائولو کوئیلو انتشارات پرثوآ',src:'images/g25.jpg',price:'54000'},
    {id:5,name:'کتال پاستیل های بنفش',src:'images/g21.jpg',price:'65000'},
    
    {id:6,name:'کتاب اثر مرکب اثر دارن هاردی انتشارات نگین ایران',src:'images/g22.jpg',price:'55000'},
    {id:7,name:'کتاب خودت باش دختر اثر ریچل هالیس',src:'images/g23.jpg',price:'40000'},
    {id:8,name:'کتاب بیشعوری اثر خاویر کرمنت نشر ندای معاصر',src:'images/g24.jpg',price:'32000'},
    {id:9,name:'کتاب کیمیاگر اثر پائولو کوئیلو انتشارات پرثوآ',src:'images/g25.jpg',price:'54000'}

  
  ]

  const gThree=[{id:0,name:'هدفون بیبوشی مدل H5',src:'images/g31.jpg',price:'50000'},
    {id:1,name:'هندزفری مدل P1',src:'images/g32.jpg',price:'40000'},
    {id:2,name:'هندزفری مدل K-38',src:'images/g33.jpg',price:'60000'},
    {id:3,name:'هدفون بیبوشی مدل H5',src:'images/g31.jpg',price:'50000'},
    {id:4,name:'هندزفری مدل P1',src:'images/g32.jpg',price:'40000'},
    {id:5,name:'هندزفری مدل K-38',src:'images/g33.jpg',price:'60000'},
    {id:6,name:'هدفون بیبوشی مدل H5',src:'images/g31.jpg',price:'50000'},
    {id:7,name:'هندزفری مدل P1',src:'images/g32.jpg',price:'40000'},
    {id:8,name:'هندزفری مدل K-38',src:'images/g33.jpg',price:'60000'},
  
  ]
  const gFour=[{id:0,name:'هدفون بیبوشی مدل H5',src:'images/g31.jpg',price:'50000'},
  {id:1,name:'هندزفری مدل P1',src:'images/g32.jpg',price:'40000'},
  {id:2,name:'هندزفری مدل K-38',src:'images/g33.jpg',price:'60000'},
  {id:4,name:'کتاب کیمیاگر اثر پائولو کوئیلو انتشارات پرثوآ',src:'images/g25.jpg',price:'54000'},
  {id:5,name:'کتال پاستیل های بنفش',src:'images/g21.jpg',price:'65000'},
  
  {id:6,name:'کتاب اثر مرکب اثر دارن هاردی انتشارات نگین ایران',src:'images/g22.jpg',price:'55000'},
  {id:7,name:'کتاب خودت باش دختر اثر ریچل هالیس',src:'images/g23.jpg',price:'40000'},
  {id:8,name:'کتاب بیشعوری اثر خاویر کرمنت نشر ندای معاصر',src:'images/g24.jpg',price:'32000'},
  {id:9,name:'کتاب کیمیاگر اثر پائولو کوئیلو انتشارات پرثوآ',src:'images/g25.jpg',price:'54000'}]
 
  let car = useRef()
  let car2 = useRef()
  let car3 = useRef()
  let car4 = useRef()
  let car5= useRef()
  let car6 = useRef()
  let car7 = useRef()
  let car8 = useRef()
  let car9 = useRef()
  let car10 = useRef()
  useEffect(() => {
    showSlidesV2(slideIndexV2);
  }, []);
  return (
    <div className={classes.container}>
      <div className={classes.firstBanner}>
          <div className={classes.firstBannerCarousel}> 
          <div className={classnames(classes.mySlides,'mySlides')}>
           <img src="images/sl1.jpg" className={classes.imgCr} alt="" />
          </div>
          <div className={classnames(classes.mySlides,'mySlides')}>
           <img src="images/sl2.jpg" className={classes.imgCr} alt="" />
          </div>
          <div className={classnames(classes.mySlides,'mySlides')}>
           <img src="images/sl3.jpg" className={classes.imgCr} alt="" />
          </div>
          <div className={classnames(classes.mySlides,'mySlides')}>
           <img src="images/sl4.jpg" className={classes.imgCr} alt="" />
          </div>
          <div className={classnames(classes.mySlides,'mySlides')}>
           <img src="images/sl5.jpg" className={classes.imgCr} alt="" />
          </div>
          <a className="prev" onClick={()=>{plusSlides(-1)}}> &#10095; </a>
<a className="next" onClick={()=>{plusSlides(1)}}> &#10094; </a>
          <div className={classes.dotBox}>
            <span className={classnames(classes.dot,'dot')} onClick={()=>{currentSlide(1)}}></span>
            <span className={classnames(classes.dot,'dot')} onClick={()=>{currentSlide(2)}}></span>
            <span className={classnames(classes.dot,'dot')} onClick={()=>{currentSlide(3)}}></span>
            <span className={classnames(classes.dot,'dot')} onClick={()=>{currentSlide(4)}}></span> 
             <span className={classnames(classes.dot,'dot')} onClick={()=>{currentSlide(5)}}></span> 
          </div>
          
          </div>
          <div className={classes.firstBannerDiv}>
            <div className={classes.firstBannerAd}> <img src="images/one.gif" className={classes.imgGif}  /> </div>
            <div className={classes.firstBannerAd}> <img src="images/two.gif" className={classes.imgGif} /> </div>
            </div>   

      </div>

      <div className={classes.supriseBox}>
         <div className={classes.suprise}>
           <div className={classes.supriseEnter}>
             <div className={classes.supriseImg}>
               <img src="images/supr.png" alt="" style={{ width:'100%',height:'100%' }} />
             </div>
             <div className={classes.supriseButtonBox}>
             <Link to="/goodOrder"><button className={classes.btn}>مشاهده همه</button></Link>  
             </div>
           </div>
           <div className={classes.supriseCarousel}>
             <Carousel itemsToShow={4} itemsToScroll={4}>
               <CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/>
 
               
             </Carousel>
           </div>
         </div>

      </div>
     <div className={classes.adOne}>
     <div className={classes.ad}>
<img src="images/firstAd (1).jpg" className={classes.adImg} alt="" />
     </div>
     <div className={classes.ad}>
<img src="images/firstAd (2).jpg" className={classes.adImg} alt="" />
     </div>
     <div className={classes.ad}>
<img src="images/firstAd (3).jpg" className={classes.adImg} alt="" />
     </div>
     <div className={classes.ad}>
     <img src="images/firstAd (4).jpg" className={classes.adImg} alt="" />  
     </div>

     </div>

     <div className={classes.supriseBox2}>
         <div className={classes.suprise}>
           <div className={classes.supriseEnter}>
             <div className={classes.supriseImg}>
               <img src="images/supr.png" alt="" style={{ width:'100%',height:'100%' }} />
             </div>
             <div className={classes.supriseButtonBox}>
            <Link to="/superOrder"><button className={classes.btn}>مشاهده همه</button></Link>   
             </div>
           </div>
           <div className={classes.supriseCarousel}>
             <Carousel itemsToShow={4} itemsToScroll={4}>
               <CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/><CardGood/>
 
               
             </Carousel>
           </div>
         </div>

      </div>
     <div style={{ width:'1366px',margin:'auto' }}>
      <div className={classes.mobileBox}>
      <div className={classes.rightBox}>
        <div className={classes.rightBoxHeader}>
          <div className={classes.rightBoxHeaderTag}>
            <Typography variant="h6" color="initial">گوشی موبایل</Typography>
            <Typography variant="body1" color="textSecondary">براساس بازدید های شما</Typography>
          </div>
          <div className={classes.rightBoxHeaderRight}></div>
        </div>
        <div className={classes.rightBoxBody}>
      <Carousel itemsToShow={5} itemsToShow={5}  showArrows={false} ref={ref=>{car9=ref}}>
      <CardGoodPluse/><CardGoodPluse/><CardGoodPluse/><CardGoodPluse/><CardGoodPluse/><CardGoodPluse/><CardGoodPluse/>
      <CardGoodPluse/>
      </Carousel>
      <a className={classes.right} onClick={()=>car9.slideNext()}><ChevronRightIcon/></a>
      <a className={classes.left} onClick={()=>car9.slidePrev()}><ChevronLeftIcon/></a>
         
        </div>
      </div>
       <div className={classes.leftBox}>
           <div  className={classes.leftBoxHeader}>
             <Typography variant="body1" color="initial">پیشنهاد های لحظه ای برای شما</Typography>
           </div>
           <hr style={{width:'90%',margin:'0px auto'}}/>
           <div className={classes.card}>
             <CardGoodPluse/>
           </div>

       </div>
    
      </div>

      <div className={classes.categories}>
      <div className={classes.categoriesHeader}>
            <Typography variant="h5" color="textSecondary">بیش از 4,000,000 کالا در دسته بندی های مختلق</Typography>
          </div>
          <div className={classes.categoriesBody}>
            <div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div>
            <div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div>
            <div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div><div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div><div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div><div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div><div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div><div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div><div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div><div className={classes.category}>
             <span className={classes.icon} fontSize="large"><LaptopChromebookOutlinedIcon className={classes.icon} /></span>
             <Typography variant="body1" color="initial">کالای دیجیتال</Typography>
             <Typography className={classes.count} variant="body1" color="initial">+870000 کالا</Typography>
            </div>
          </div>
      </div>



      <div className={classes.customize}>
        <div className={classes.rightCustomize}> 
       <img src="images/va.jpg" style={{width:'25%',display:'block',margin:'40px auto 0px auto',}}/>
        <h3>شخصی سازی پیشنهادها !</h3>
        <Typography variant="h6" color="textSecondary" style={{ margin:'0px 10px' }}>برای مشاهده پیشنهادهای مناسب خود و همچنین داشتن تجربه بهتر لطفا وارد حساب کاربری شوید.</Typography>
        <Link to="/login" style={{ textDecoration:'none' }}><button className={classes.lgBtn}>ورود به حساب دیجی کالا</button></Link>
        </div>
        <div className={classes.leftCustomize}>
          <div className={classes.leftCustomizeHeader}>
            <div className={classes.leftCustomizeHeaderRight}>
              <Typography variant="h5" color="initial">کیف و کاور گوشی</Typography>
              <Typography variant="body1" color="textSecondary">براساس بازدید های شما</Typography>
              </div> 
            <div className={classes.leftCustomizeHeaderLeft}>
              



            </div>
          </div>
          <div className={classes.leftCustomizeBody}>
            <Carousel itemsToScroll={4} itemsToShow={5} showArrows={false} ref={ref=>{car10=ref}}>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            <CardGoodPluse/>
            </Carousel>
            
            <a className={classnames(classes.leftNav,classes.leftArrow)} onClick={()=>car10.slidePrev()}><ChevronLeftIcon /></a>
            <a className={classes.rightNav} onClick={()=>car10.slideNext()}><ChevronRightIcon /></a>
          </div>
        </div>
      </div>

      <div className={classes.adTwo}>
        <div className={classes.adTwoBlock}><img src="images/artc1.jpg" className={classes.adTwoImg} /></div>
        <div className={classes.adTwoBlock}><img src="images/artc.jpg" className={classes.adTwoImg} /></div>
      </div>

      
      <div className={classes.typesGood}>
        <div className={classes.typesGoodHeader}>
          <div className={classes.typesGoodHeaderRight}>
            <Typography variant="h6" color="initial"> هدفون هندزفری </Typography>
            <Typography variant="body1" color="textSecondary">براساس بازدید های شما </Typography>
          </div>
          <div className={classes.typesGoodHeaderLeft}> </div>
        </div>
     <Carousel itemsToShow={5} itemsToScroll={5}showArrows={false} ref={ref=>{car=ref}}>
     {gThree.map((item)=>{
       return(<><CardType  name={item.name} src={item.src} price={item.price}/></>)
     })}

     </Carousel>
     <a className={classes.typesRightNav} onClick={()=>car.slideNext()}><ChevronRightIcon/></a>
     <a className={classes.typesLeftNav} onClick={()=>car.slidePrev()}><ChevronLeftIcon/></a>
      </div>

      <div className={classes.typesGood}>
        <div className={classes.typesGoodHeader}>
          <div className={classes.typesGoodHeaderRight}>
            <Typography variant="h6" color="initial"> کتاب چاپی </Typography>
            <Typography variant="body1" color="textSecondary">براساس بازدید های شما </Typography>
          </div>
          <div className={classes.typesGoodHeaderLeft}> </div>
        </div>
        <Carousel itemsToShow={5} itemsToScroll={5}showArrows={false} ref={ref=>{car2=ref}}>
        {gTwo.map((item)=>{
       return(<><CardType  name={item.name} src={item.src} price={item.price}/></>)
     })}

     </Carousel>
     <a className={classes.typesRightNav} onClick={()=>car2.slideNext()}><ChevronRightIcon/></a>
     <a className={classes.typesLeftNav} onClick={()=>car2.slidePrev()}><ChevronLeftIcon/></a>
      </div>

      <div className={classes.adTwo}>
        <div className={classes.adTwoBlock}><img src="images/artc1.jpg" className={classes.adTwoImg} /></div>
        <div className={classes.adTwoBlock}><img src="images/artc.jpg" className={classes.adTwoImg} /></div>
      </div>

     


    


      <div className={classes.typesGoodTwo}>
        <div className={classes.typesGoodHeaderTwo}>
          <div className={classes.typesGoodHeaderRight}>
            <Typography variant="h6" color="initial"> محصولات پر بازدید اخیر </Typography>
        
          </div>
          <div className={classes.typesGoodHeaderLeft}> </div>
        </div>
        <Carousel className={classes.typesGoodBody} itemsToShow={5} itemsToScroll={5} showArrows={false} ref={ref=>{car5=ref}}>
        {gFour.map((item)=>{
       return(<><CardType  name={item.name} src={item.src} price={item.price}/></>)
     })}

     </Carousel>
     <a className={classes.typesRightNav} onClick={()=>car5.slideNext()}><ChevronRightIcon/></a>
     <a className={classes.typesLeftNav} onClick={()=>car5.slidePrev()}><ChevronLeftIcon/></a>
      </div>

      <div className={classes.typesGoodTwo}>
        <div className={classes.typesGoodHeaderTwo}>
          <div className={classes.typesGoodHeaderRight}>
            <Typography variant="h6" color="initial"> منتخب جدید ترین کالاها </Typography>
        
          </div>
          <div className={classes.typesGoodHeaderLeft}> </div>
        </div>
        <Carousel className={classes.typesGoodBody} itemsToShow={5} itemsToScroll={5} showArrows={false} ref={ref=>{car6=ref}}>
        {gFour.map((item)=>{
       return(<><CardType  name={item.name} src={item.src} price={item.price}/></>)
     })}

     </Carousel>
     <a className={classes.typesRightNav} onClick={()=>car6.slideNext()}><ChevronRightIcon/></a>
     <a className={classes.typesLeftNav} onClick={()=>car6.slidePrev()}><ChevronLeftIcon/></a>
      </div>

       <div className={classes.typesGoodTwo}>
        <div className={classes.typesGoodHeaderTwo}>
          <div className={classes.typesGoodHeaderRight}>
            <Typography variant="h6" color="initial">  محصولات پر فروش اخیر </Typography>
        
          </div>
          <div className={classes.typesGoodHeaderLeft}> </div>
        </div>
        <Carousel className={classes.typesGoodBody} itemsToShow={5} itemsToScroll={5} showArrows={false} ref={ref=>{car7=ref}}>
        {gFour.map((item)=>{
       return(<><CardType  name={item.name} src={item.src} price={item.price}/></>)
     })}

     </Carousel>
     <a className={classes.typesRightNav} onClick={()=>car7.slideNext()}><ChevronRightIcon/></a>
     <a className={classes.typesLeftNav} onClick={()=>car7.slidePrev()}><ChevronLeftIcon/></a>
      </div>

      <div className={classes.typesGoodTwo}>
        <div className={classes.typesGoodHeaderTwo}>
          <div className={classes.typesGoodHeaderRight}>
            <Typography variant="h6" color="initial">    منتخب محصولات تخفیف و حراج </Typography> 
        
          </div>
          <div className={classes.typesGoodHeaderLeft}> </div>
        </div>
        <Carousel className={classes.typesGoodBody} itemsToShow={5} itemsToScroll={5} showArrows={false} ref={ref=>{car8=ref}}>
        {gFour.map((item)=>{
       return(<><CardType  name={item.name} src={item.src} price={item.price}/></>)
     })}

     </Carousel>
     <a className={classes.typesRightNav} onClick={()=>car8.slideNext()}><ChevronRightIcon/></a>
     <a className={classes.typesLeftNav} onClick={()=>car8.slidePrev()}><ChevronLeftIcon/></a>
      </div>



         

      </div>
     
    </div>
  )
}
