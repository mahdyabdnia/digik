import {makeStyles} from '@material-ui/core'
const useStyles= makeStyles({
card:{
    width:'279px !important ',
    height:'394px',
    backgroundColor:'white',
    display:'flex',
    flexDirection:'column',
    paddingTop:'50px',
    paddingRight:'10px',
    paddingLeft:'10px',
    borderRadius:'10px',
    marginRight:'10px',
    marginLeft:'10px',
    direction:'rtl'

},
img:{
    display:'block',
    margin:'40px auto 0px auto',
    width:'180px',
    height:'180px',
    margin:'auto',
},
imgBox:{
    height:'50%'
},
box:{
    height:'50%'
},
name:{
    color:'#5d5d5d',
    fontSize:'15px',
    textAlign:'right',
    marginRight:'20px',
    direction:'rtl'

},
offBox:{
    display:'flex',
    flexDirection:'row',
    direction:'ltr',
    alignItems:'center'
},
off:{
    color:'white',
    backgroundColor:'red',
    width:'fit-content',
    height:'fit-content',
    padding:'5px 10px',
    borderRadius:'40px',
    marginRight:'10px'


},
beforeOff:{
    color:'#d2d2d2',
    textDecoration:'#d2d2d2',
    textDecorationLine:'line-through'
},
price:{
    textAlign:'left',
    fontSize:'20px',
    fontWeight:'bold',
    direction:'ltr',
    margin:'5px 0px '
},
timer:{
    textAlign:'left',
    direction:'ltr',
    display:'flex',
    alignItems: 'center',
    height:'26px'


}
});

export default useStyles;