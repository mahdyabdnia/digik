import React,{useEffect} from 'react' 
import useStyles from './styles'
import classnames from 'classnames'
export default function CardGood() {
    useEffect(() => {
        var countDownDate = new Date("Oct 6, 2021 18:45:00").getTime();
       
        var x=setInterval(function(){
            var now = new Date().getTime();
            var distance = countDownDate - now;
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
           var time= document.getElementsByClassName('time');
           var i;
           for(i=0;i<time.length;i++){
               time[i].innerHTML=hours+':'+minutes+":"+seconds;
           }
            if (distance < 0) {
                clearInterval(x);
                
              }
        },1000);
          return () => {
            clearInterval(x);
          }
      }, [])
    const classes=useStyles();
    return (
        <div className={classes.card}>
          <div className={classes.imgBox}>
          <img src="images/book.jpg" alt="" className={classes.img} />
          </div>
          <div className={classes.box}>
              <span style={{ display:'flex',alignItems:'center',paddingBottom:'40px' }}><p className={classes.name}>کتاب پاستیل های بنفش</p></span>
              <span className={classes.offBox}>
                  <span className={classes.off}>24%</span>
                  <span className={classes.beforeOff}>70000</span>

              </span>
              <span className={classes.price}> <p className={classes.price}> 21000 تومان </p></span>
              <span className={classes.timer}><img src='images/clock.jpg'/><p className={classnames(classes.timer,'time')}></p></span>
          </div>
          

            
        </div>
    )
}
