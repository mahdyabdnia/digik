import React,{useRef} from 'react'
import Carousel from 'react-elastic-carousel'

export default function Car() {
   let carousel  = useRef()
    return (
        <div>
            <button onClick={() => carousel.slidePrev()}>Prev</button>
          <button onClick={() => carousel.slideNext()}>Next</button>
          <hr />
          <Carousel ref={ref => (carousel = ref)} showArrows={false}>
            <div>1</div>
            <div>2</div>
            <div>3</div>
            <div>4</div>
            <div>5</div>
            <div>6</div>
          </Carousel>
        </div>
    )
}
