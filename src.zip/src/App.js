import React,{useState} from 'react'
import First from './components/First/First'
import Category from './components/Category/Category'
import Navbar from './components/Navbar/Navbar'
import {Route,Switch,BrowserRouter} from 'react-router-dom'
import Good from './components/Good/Good'
import Fotter from './components/Fotter/Fotter'
import Login from './components/Login/Login'
import LoginSec from './components/Login/LoginSec'
import Layout from './Layout'
import Cart from './components/Cart/Cart'

import {Provider} from 'react-redux'
import store from '../src/redux/Store'
import AdminLayout from './AdminLayout'
import Home from './Admin/Home/Home'
import Add from './Admin/ManageGood/Add'
import Edit from './Admin/ManageGood/Edit'
import EditPage from './Admin/ManageGood/EditPage'
import Whole from './Admin/ManageCategory/Whole'
import WholeList from './Admin/ManageCategory/WholeList'
import EditWhole from './Admin/ManageCategory/EditWhole'
import Middle from './Admin/MangeMiddleCategory/Middle'
import MiddleList from './Admin/MangeMiddleCategory/MiddleList'
import EditMiddle from './Admin/MangeMiddleCategory/EditMiddle'
import Minor from './Admin/ManageMInorCategory/Minor'
import MinorList from './Admin/ManageMInorCategory/MinorList'
import EditMinor from './Admin/ManageMInorCategory/EditMinor'
import SellersPanel from './components/SellersPanel/SellersPanel'
import SellersLogin from './components/SellersPanel/SellersLogin/SellersLogin'
import SellersSignup from './components/SellersPanel/SellersSignup/SellersSignup'
import CategoryPage2 from './components/Category/CategoryPage2'
import CategoryPage3 from './components/Category/CategoryPage3'
import SuperMarket from './SuperMarket/SuperMarket'
import Car from './components/Car'
import GoodOrder from './components/SurpriseOrder/GoodOrder'
import SuperOrder from './SupermarketOrder/SuperOrder'
import SupermarketGood from './SupermarketGood/SupermarketGood'
export default function App() {
  const [addCart, setAddCart] = useState(2);
  return (
     
    <BrowserRouter>
    <Switch>
    <Route path="/admin" render={()=>{
          return(<AdminLayout>
           <Switch>
             <Route component={Home} path="/admin/home" exact />
             <Route path="/admin/add" component={Add} exact />
             <Route path="/admin/edit" component={Edit} exact />
             <Route path="/admin/editpage" component={EditPage}  />
             <Route path="/admin/addWholeCategory" component={Whole}/>
             <Route path="/admin/editWholeCategory" component={WholeList}/>
             <Route path="/admin/editWhole" component={EditWhole}/>
             <Route path="/admin/addMiddleCategory" component={Middle}/>
             <Route path="/admin/editMiddleCategory" component={MiddleList}/>
             <Route path="/admin/editMiddle" component={EditMiddle}/>
             <Route path="/admin/addMinorCategory" component={Minor}/>
             <Route path="/admin/editMinorCategory" component={MinorList}/>
             <Route path="/admin/editMinor" component={EditMinor}/>
             
          
           </Switch>

          </AdminLayout>);
    }}/>
    <Route path="/sellersPanel" exact component={SellersPanel} />
    <Route path="/sellersPanel/login" exact component={SellersLogin} />
    <Route path="/sellersPanel/signup" exact component={SellersSignup}  />
    <Route path="/login" component={Login} />
    <Route path="/loginSec" component={LoginSec} />
    <Route path="/car" component={Car}/>
     <Route path="/"  render={()=>{
       return(<Layout >
         <Switch>
       <Route path="/" exact component={First}/>
       <Route path="/category" exact component={Category}/>
       <Route path="/categorytwo" exact component={CategoryPage2}/>
       <Route path="/categorythree" exact component={CategoryPage3}/>
       <Route path="/cart" exact component={Cart}/>
       <Route path="/good" exact component={Good} setAddCart={setAddCart} addCart={addCart}/>
       <Route path="/supermarket" component={SuperMarket}  />
       <Route path="/goodOrder" component={GoodOrder}/>
       <Route path="/superOrder" component={SuperOrder} />
       <Route path="/supergood"  component={SupermarketGood}/>



      </Switch>
       </Layout>)
     }} />

     

    </Switch>
    
      
     
     
    
    
    
    
    </BrowserRouter>
  
  )
}

